@echo off
title RakshaGrid 2.0 Local Server
echo ========================================================
echo   RAKSHAGRID 2.0 - TOURIST SAFETY & EMERGENCY PLATFORM
echo ========================================================
echo.
echo Starting local server on port 5000...
echo.
node server.js
pause
