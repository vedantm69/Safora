
(function() {
    var React = window.React;
    var ReactDOM = window.ReactDOM;
    if (!React || !ReactDOM) {
        console.error("React or ReactDOM not loaded.");
        return;
    }
    const { useState, useEffect, useRef, useMemo } = React;
    const e = React.createElement;

    // --- COUNTRIES LIST ---
    const COUNTRIES_LIST = [
        "Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Argentina", "Armenia", "Australia", 
        "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", 
        "Belize", "Benin", "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana", "Brazil", "Brunei", 
        "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Chile", "China", 
        "Colombia", "Costa Rica", "Croatia", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Dominican Republic", 
        "Ecuador", "Egypt", "El Salvador", "Estonia", "Ethiopia", "Fiji", "Finland", "France", 
        "Georgia", "Germany", "Ghana", "Greece", "Guatemala", "Honduras", "Hong Kong", "Hungary", 
        "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland", "Israel", "Italy", 
        "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kuwait", "Kyrgyzstan", "Laos", 
        "Latvia", "Lebanon", "Lithuania", "Luxembourg", "Malaysia", "Maldives", "Malta", "Mauritius", 
        "Mexico", "Moldova", "Monaco", "Mongolia", "Montenegro", "Morocco", "Myanmar", "Nepal", 
        "Netherlands", "New Zealand", "Nicaragua", "Nigeria", "North Korea", "Norway", "Oman", "Pakistan", 
        "Palestine", "Panama", "Paraguay", "Peru", "Philippines", "Poland", "Portugal", "Qatar", 
        "Romania", "Russia", "Saudi Arabia", "Senegal", "Serbia", "Singapore", "Slovakia", "Slovenia", 
        "South Africa", "South Korea", "Spain", "Sri Lanka", "Sudan", "Sweden", "Switzerland", "Syria", 
        "Taiwan", "Tajikistan", "Tanzania", "Thailand", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", 
        "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "Uruguay", "Uzbekistan", 
        "Vatican City", "Venezuela", "Vietnam", "Yemen", "Zambia", "Zimbabwe"
    ];

    // --- COMPREHENSIVE LIVE UI TRANSLATIONS (EN, HI, MR) ---
    const UI_I18N = {
        "English": {
            appTitle: "RakshaGrid 2.0",
            byDietCode: "by Diet Code",
            statusLinked: "POLICE + EMS LINKED • LIVE GPS SECURED",
            radarAlert: "RADAR ALERT",
            tabSafety: "Safety",
            tabAi: "AI Assist",
            tabTranslate: "Translate",
            tabGroup: "Group",
            tabLost: "Lost",
            tabProfile: "Profile",
            emergencyDispatch: "Emergency Dispatch",
            selectDistress: "SELECT DISTRESS REASON",
            sosButton: "SOS EMERGENCY DISPATCH",
            sosSubtext: "Instant police & hospital dispatch with live GPS",
            southMumbaiMap: "South Mumbai Coastal Safety Map",
            liveGpsMap: "● LIVE GPS MAP",
            liveShorelineHazard: "Live GPS telemetry & interactive safety corridor",
            emergencyActive: "EMERGENCY ACTIVE",
            emergencyActiveSub: "Your live GPS is being shared with responders.",
            dispatchStatus: "DISPATCH STATUS",
            distressType: "Distress type:",
            location: "Location:",
            dispatched: "Dispatched:",
            callEmergency: "CALL EMERGENCY LINE",
            cancelEmergency: "CANCEL EMERGENCY",
            aiTitle: "AI Safety Assistant",
            aiOnline: "● Online • Ready to assist",
            askLocation: "Ask about any location...",
            safetyRating: "SAFETY RATING",
            lostTitle: "Lost & Found",
            securedBadge: "SECURED",
            reportLostTab: "Report Lost",
            foundItemsTab: "Found Items",
            recentLostReports: "RECENT LOST REPORTS",
            verifiedFoundItems: "VERIFIED FOUND ITEMS",
            clearMyReports: "Clear My Reports",
            reportLostButton: "REPORT LOST ITEM",
            fileClaim: "File Official Lost Property Claim",
            fileClaimSub: "Direct broadcast to Tourism Police & Authority Desk",
            itemCategory: "Item Category *",
            itemName: "Item Name / Description *",
            lastSeenLocation: "Last Seen Location *",
            contactReturn: "Contact for Return *",
            submitClaim: "Submit Claim",
            cancel: "Cancel",
            identityPass: "Identity Pass",
            editPass: "Edit Pass",
            touristFullName: "TOURIST FULL NAME",
            currentStaying: "CURRENT STAYING ACCOMMODATION",
            activeReservation: "Active Reservation",
            checkout: "Check-out: 24 Oct",
            passportId: "PASSPORT / GOVT ID",
            emergencyPhone: "EMERGENCY PHONE",
            bloodGroup: "BLOOD GROUP",
            tourismHelpdesk: "TOURISM HELPDESK",
            digitalQr: "Digital Identity Pass QR",
            digitalQrSub: "Tap to show official boarding & verification QR"
        },
        "Hindi": {
            appTitle: "रक्षाग्रिड 2.0",
            byDietCode: "द्वारा डाइट कोड (Diet Code)",
            statusLinked: "पुलिस + एम्बुलेंस लिंक • लाइव GPS सुरक्षित",
            radarAlert: "अलर्ट सूचना",
            tabSafety: "सुरक्षा",
            tabAi: "AI सहायक",
            tabTranslate: "अनुवाद",
            tabGroup: "समूह",
            tabLost: "खोया-पाया",
            tabProfile: "प्रोफ़ाइल",
            emergencyDispatch: "आपातकालीन सहायता (SOS)",
            selectDistress: "आपातकाल का कारण चुनें",
            sosButton: "SOS आपातकालीन सहायता भेजें",
            sosSubtext: "लाइव GPS के साथ तत्काल पुलिस और अस्पताल सहायता",
            southMumbaiMap: "दक्षिण मुंबई तटीय सुरक्षा नक्शा",
            liveGpsMap: "● लाइव GPS मैप",
            liveShorelineHazard: "लाइव GPS टेलीमेट्री और इंटरैक्टिव सुरक्षा कॉरिडोर",
            emergencyActive: "आपातकाल सक्रिय है",
            emergencyActiveSub: "आपका लाइव GPS पुलिस और अस्पताल के साथ साझा हो रहा है।",
            dispatchStatus: "भेजने की स्थिति",
            distressType: "समस्या का प्रकार:",
            location: "स्थान:",
            dispatched: "भेजी गई टीम:",
            callEmergency: "हेल्पलाइन 112 पर कॉल करें",
            cancelEmergency: "आपातकाल रद्द करें",
            aiTitle: "AI सुरक्षा सहायक",
            aiOnline: "● ऑनलाइन • सहायता के लिए तैयार",
            askLocation: "किसी भी स्थान या सुरक्षा के बारे में पूछें...",
            safetyRating: "सुरक्षा रेटिंग",
            lostTitle: "खोया और पाया",
            securedBadge: "सुरक्षित",
            reportLostTab: "खोई वस्तु रिपोर्ट करें",
            foundItemsTab: "मिली वस्तुएं",
            recentLostReports: "हाल की खोई रिपोर्टें",
            verifiedFoundItems: "सत्यापित मिली वस्तुएं",
            clearMyReports: "मेरी रिपोर्ट हटाएं",
            reportLostButton: "खोई वस्तु दर्ज करें",
            fileClaim: "आधिकारिक खोई संपत्ति रिपोर्ट दर्ज करें",
            fileClaimSub: "पर्यटन पुलिस और प्राधिकरण डेस्क को सीधा प्रसारण",
            itemCategory: "वस्तु की श्रेणी *",
            itemName: "वस्तु का नाम / विवरण *",
            lastSeenLocation: "अंतिम बार देखा गया स्थान *",
            contactReturn: "वापसी के लिए संपर्क नंबर *",
            submitClaim: "रिपोर्ट सबमिट करें",
            cancel: "रद्द करें",
            identityPass: "पहचान पास (ID)",
            editPass: "विवरण बदलें",
            touristFullName: "पर्यटक का पूरा नाम",
            currentStaying: "वर्तमान ठहरने का स्थान / होटल",
            activeReservation: "सक्रिय आरक्षण",
            checkout: "चेक-आउट: 24 अक्टूबर",
            passportId: "पासपोर्ट / सरकारी ID",
            emergencyPhone: "आपातकालीन फोन",
            bloodGroup: "ब्लड ग्रुप",
            tourismHelpdesk: "पर्यटन हेल्पडेस्क",
            digitalQr: "डिजिटल पहचान पास QR",
            digitalQrSub: "आधिकारिक सत्यापन QR देखने के लिए टैप करें"
        },
        "Marathi": {
            appTitle: "रक्षाग्रिड 2.0",
            byDietCode: "डाइट कोड (Diet Code) निर्मित",
            statusLinked: "पोलीस + रुग्णवाहिका लिंक • थेट GPS सुरक्षित",
            radarAlert: "सतर्कता सूचना",
            tabSafety: "सुरक्षा",
            tabAi: "AI मदतनीस",
            tabTranslate: "भाषांतर",
            tabGroup: "ग्रुप",
            tabLost: "हरवले-सापडले",
            tabProfile: "प्रोफाइल",
            emergencyDispatch: "आपत्कालीन साहाय्य (SOS)",
            selectDistress: "आपत्कालीन कारण निवडा",
            sosButton: "SOS आपत्कालीन मदत बोलवा",
            sosSubtext: "थेट GPS सह तात्काळ पोलीस आणि रुग्णालय मदत",
            southMumbaiMap: "दक्षिण मुंबई किनारपट्टी सुरक्षा नकाशा",
            liveGpsMap: "● थेट GPS नकाशा",
            liveShorelineHazard: "थेट GPS आणि परस्परसंवादी सुरक्षा मार्ग",
            emergencyActive: "आपत्कालीन साहाय्य सक्रिय",
            emergencyActiveSub: "आपले थेट GPS लोकेशन मदत पथकासोबत शेअर केले जात आहे.",
            dispatchStatus: "मदत स्थिती",
            distressType: "समस्येचा प्रकार:",
            location: "ठिकाण:",
            dispatched: "पाठवलेले पथक:",
            callEmergency: "हेल्पलाइन 112 वर कॉल करा",
            cancelEmergency: "मदत रद्द करा",
            aiTitle: "AI सुरक्षा मदतनीस",
            aiOnline: "● ऑनलाइन • मदतीसाठी सज्ज",
            askLocation: "कोणत्याही ठिकाणाबद्दल विचारा...",
            safetyRating: "सुरक्षा मानांकन",
            lostTitle: "हरवले आणि सापडले",
            securedBadge: "सुरक्षित",
            reportLostTab: "हरवलेली वस्तू नोंदवा",
            foundItemsTab: "सापडलेल्या वस्तू",
            recentLostReports: "अलीकडील हरवलेल्या वस्तू",
            verifiedFoundItems: "तपासणी झालेल्या सापडलेल्या वस्तू",
            clearMyReports: "माझ्या नोंदी हटवा",
            reportLostButton: "हरवलेली वस्तू नोंदवा",
            fileClaim: "अधिकृत हरवलेली मालमत्ता नोंदणी",
            fileClaimSub: "पर्यटन पोलीस व नियंत्रण कक्षाकडे थेट नोंद",
            itemCategory: "वस्तूचा प्रकार *",
            itemName: "वस्तूचे नाव / वर्णन *",
            lastSeenLocation: "शेवटचे पाहिलेले ठिकाण *",
            contactReturn: "परतीसाठी संपर्क क्रमांक *",
            submitClaim: "नोंदणी सबमिट करा",
            cancel: "रद्द करा",
            identityPass: "ओळखपत्र पास (ID)",
            editPass: "माहिती बदला",
            touristFullName: "पर्यटकाचे पूर्ण नाव",
            currentStaying: "सध्याचे मुक्कामाचे ठिकाण / हॉटेल",
            activeReservation: "सक्रिय आरक्षण",
            checkout: "चेक-आउट: 24 ऑक्टोबर",
            passportId: "पासपोर्ट / शासकीय ID",
            emergencyPhone: "आपत्कालीन फोन",
            bloodGroup: "रक्तगट",
            tourismHelpdesk: "पर्यटन हेल्पडेस्क",
            digitalQr: "डिजिटल ओळख पास QR",
            digitalQrSub: "सत्यापन QR पाहण्यासाठी टॅप करा"
        }
    };

    // --- AUDIO SYNTHESIS HELPER ---
    let globalActiveAudio = null;
    const speakText = (text, lang = "en-US", onEndCallback = null) => {
        try {
            const cleanText = (text || "").replace(/[*#_]/g, '').trim().slice(0, 300);
            if (!cleanText) return;
            window.speechSynthesis.cancel();
            const utterance = new SpeechSynthesisUtterance(cleanText);
            utterance.lang = lang;
            utterance.rate = 0.95;
            utterance.pitch = 1.0;
            if (onEndCallback) {
                utterance.onend = onEndCallback;
                utterance.onerror = onEndCallback;
            }
            window.speechSynthesis.speak(utterance);
        } catch (err) {
            console.warn("SpeechSynthesis error:", err);
            if (onEndCallback) onEndCallback();
        }
    };

    // --- TRANSLATION DATA & HELPERS ---
    const phrasebook = {
        emergency: [
            { en: "Please help me! Call the police!", hi: "कृपया मेरी मदद कीजिए! पुलिस को बुलाइए!", mr: "कृपया मला मदत करा! पोलिसांना बोलवा!", pronHi: "Krupaya meri madad kijiye! Police ko bulaiye!", pronMr: "Krupaya malaa madat karaa! Polisaanna बोलwaa!" },
            { en: "Where is the nearest hospital?", hi: "पास में सबसे नजदीकी अस्पताल कहाँ है?", mr: "जवळचे सर्वात जवळचे रुग्णालय कुठे आहे?", pronHi: "Paas mein sabse nazdeeki aspatal kahan hai?", pronMr: "Javalche sarvaat javalche rugnaalay kuthe aahe?" },
            { en: "Someone stole my bag / wallet!", hi: "किसी ने मेरा बैग / पर्स चुरा लिया!", mr: "कोणीतरी माझी बॅग / पाकीट चोरले!", pronHi: "Kisi ne mera bag / purse churaa liya!", pronMr: "Konitari maajhi bag / paakit chorle!" },
            { en: "I am feeling unwell / need medical help.", hi: "मेरी तबीयत ठीक नहीं लग रही है, डॉक्टर चाहिए।", mr: "माझी प्रकृती बरी नाहीये, डॉक्टर हवे आहेत.", pronHi: "Meri tabiyat theek nahi lag rahi hai, doctor chahiye.", pronMr: "Maajhi prakruti bari naahiye, doctor havey aahet." }
        ],
        transport: [
            { en: "Bhaiya, will you go by meter?", hi: "भैया, मीटर से चलोगे क्या?", mr: "दादा, मीटरने चालणार का?", pronHi: "Bhaiya, meter se chaloge kya?", pronMr: "Dada, meter-ne chaalnaar ka?" },
            { en: "How much to Gateway of India?", hi: "गेटवे ऑफ इंडिया का कितना लोगे?", mr: "गेटवे ऑफ इंडियाचे किती घेणार?", pronHi: "Gateway of India ka kitna loge?", pronMr: "Gateway of India-che kiti ghenaar?" },
            { en: "Please turn on the AC.", hi: "भैया, AC चालू कर दीजिए ना।", mr: "दादा, कृपया AC चालू करा ना.", pronHi: "Bhaiya, AC chaaloo kar deejiye na.", pronMr: "Dada, krupaya AC chaaloo karaa na." },
            { en: "Please stop here on the left side.", hi: "भैया, यहाँ लेफ्ट साइड में रोक दीजिए।", mr: "दादा, इथे डाव्या बाजूला थांबवा.", pronHi: "Bhaiya, yahan left side mein rok dijiye.", pronMr: "Dada, ithe daavya baajula thaambwa." }
        ],
        food: [
            { en: "Please don't make it too spicy.", hi: "भैया, ज्यादा तीखा मत बनाना, कम मिर्च रखना।", mr: "दादा, जास्त तिखट करू नका, कमी तिखट ठेवा.", pronHi: "Bhaiya, zyada teekha mat banana, kam mirch rakhna.", pronMr: "Dada, jaast tikhat karu naka, kami tikhat theva." },
            { en: "Is this pure veg (no eggs / meat)?", hi: "ये प्योर वेज है ना? इसमें अंडा या मीट तो नहीं है?", mr: "हे पूर्ण शाकाहारी (व्हेज) आहे ना? यात अंडी किंवा मटण नाही ना?", pronHi: "Yeh pure veg hai na? Isme anda ya meat toh nahi hai?", pronMr: "He poorna shakahari aahe na? Yaat andi kiva meat naahi na?" },
            { en: "Bhaiya, the bill please.", hi: "भैया, बिल देना / कितने पैसे हुए?", mr: "दादा, बिल द्या / किती झाले?", pronHi: "Bhaiya, bill dena / kitne paise hue?", pronMr: "Dada, bill dya / kiti jhaale?" },
            { en: "Please bring a bottle of mineral water.", hi: "एक बोतल मिनरल वाटर (पानी) देना।", mr: "एक बाटली मिनरल वॉटर (पाणी) द्या.", pronHi: "Ek botal mineral water dena.", pronMr: "Ek baatli mineral water dya." }
        ],
        shopping: [
            { en: "How much does this cost?", hi: "भैया, ये कितने का है?", mr: "दादा, हे किती रुपयांचे आहे?", pronHi: "Bhaiya, yeh kitne ka hai?", pronMr: "Dada, he kiti rupyānche aahe?" },
            { en: "Can you give a little discount?", hi: "थोड़ा कम कर दीजिए ना / कुछ डिस्काउंट मिलेगा?", mr: "थोडे कमी करा ना / काही डिस्काउंट मिळेल का?", pronHi: "Thoda kam kar dijiye na / discount milega?", pronMr: "Thode kami kara na / discount milel ka?" },
            { en: "Do you accept online UPI (GPay/PhonePe)?", hi: "ऑनलाइन पेमेंट / UPI (GPay, PhonePe, Paytm) चलेगा?", mr: "ऑनलाइन पेमेंट / UPI (GPay, PhonePe) चालेल का?", pronHi: "Online payment / UPI chalega?", pronMr: "Online payment / UPI chaalel ka?" }
        ]
    };

    const langCodeMap = {
        "English": "en", "Hindi": "hi", "Marathi": "mr", "Gujarati": "gu", "Tamil": "ta", "Bengali": "bn", "Spanish": "es", "French": "fr", "German": "de", "Japanese": "ja", "Russian": "ru", "Arabic": "ar"
    };

    const getLocalWord = (word, target = "Hindi") => {
        const w = (word || "").toLowerCase().trim();
        const isMr = target === "Marathi";

        const dict = {
            "hello": { hi: "नमस्ते", mr: "नमस्कार", pronHi: "Namaste", pronMr: "Namaskar" },
            "hi": { hi: "नमस्ते", mr: "नमस्कार", pronHi: "Namaste", pronMr: "Namaskar" },
            "thank you": { hi: "धन्यवाद / थैंक यू", mr: "धन्यवाद / थँक्यू", pronHi: "Dhanyawad", pronMr: "Dhanyawad" },
            "thanks": { hi: "थैंक यू", mr: "थँक्यू", pronHi: "Thank you", pronMr: "Thank you" },
            "please": { hi: "प्लीज", mr: "कृपया / प्लीज", pronHi: "Please", pronMr: "Krupaya" },
            "yes": { hi: "हाँ", mr: "हो", pronHi: "Haan", pronMr: "Ho" },
            "no": { hi: "नहीं", mr: "नाही", pronHi: "Nahi", pronMr: "Naahi" },
            "help": { hi: "मदद / हेल्प", mr: "मदत", pronHi: "Madad", pronMr: "Madat" },
            "hospital": { hi: "हॉस्पिटल / अस्पताल", mr: "हॉस्पिटल / रुग्णालय", pronHi: "Hospital / Aspatal", pronMr: "Hospital / Rugnalaya" },
            "doctor": { hi: "डॉक्टर", mr: "डॉक्टर", pronHi: "Doctor", pronMr: "Doctor" },
            "medicine": { hi: "दवाई", mr: "औषध", pronHi: "Dawai", pronMr: "Aushadh" },
            "medical": { hi: "मेडिकल स्टोर", mr: "मेडिकल", pronHi: "Medical Store", pronMr: "Medical" },
            "police": { hi: "पुलिस", mr: "पोलीस", pronHi: "Police", pronMr: "Police" },
            "station": { hi: "स्टेशन", mr: "स्टेशन", pronHi: "Station", pronMr: "Station" },
            "hotel": { hi: "होटल", mr: "हॉटेल", pronHi: "Hotel", pronMr: "Hotel" },
            "water": { hi: "पानी", mr: "पाणी", pronHi: "Paani", pronMr: "Paani" },
            "food": { hi: "खाना", mr: "जेवण / खाणे", pronHi: "Khaana", pronMr: "Jevan" },
            "taxi": { hi: "टैक्सी", mr: "टॅक्सी", pronHi: "Taxi", pronMr: "Taxi" },
            "airport": { hi: "एयरपोर्ट", mr: "विमानतळ / एअरपोर्ट", pronHi: "Airport", pronMr: "Airport / Vimantal" },
            "bill": { hi: "बिल / कितने पैसे हुए", mr: "बिल / किती झाले", pronHi: "Bill", pronMr: "Bill" },
            "price": { hi: "कितने का है", mr: "किती रुपयांचे आहे", pronHi: "Kitne ka hai", pronMr: "Kiti rupyānche aahe" },
            "discount": { hi: "डिस्काउंट / थोड़ा कम", mr: "कमी करा / सवलत", pronHi: "Discount", pronMr: "Kami kara" }
        };

        if (dict[w]) {
            return {
                text: isMr ? dict[w].mr : dict[w].hi,
                pron: isMr ? dict[w].pronMr : dict[w].pronHi
            };
        }
        return { text: word, pron: word };
    };

    const translateViaLocalEngine = (text, target) => {
        const lower = text.toLowerCase().trim();
        const isMr = target === "Marathi";
        
        for (let cat in phrasebook) {
            const hit = phrasebook[cat].find(p => p.en.toLowerCase() === lower || lower.includes(p.en.toLowerCase().slice(0, 15)));
            if (hit) {
                return {
                    translated: isMr ? (hit.mr || hit.hi) : hit.hi,
                    phonetic: isMr ? (hit.pronMr || hit.pronHi) : hit.pronHi
                };
            }
        }

        if (/i want to go (to|near|nearby|near by|to the|to a)?\s*(.+)/i.test(lower)) {
            const m = lower.match(/i want to go (to|near|nearby|near by|to the|to a)?\s*(.+)/i)[2].replace(/[?.]/g, '').trim();
            const obj = getLocalWord(m, target);
            const isNear = /near|nearby|near by/i.test(lower);
            if (isMr) {
                return {
                    translated: isNear ? `दादा, मला जवळच्या ${obj.text} ला जायचे आहे / घेऊन चला.` : `दादा, मला ${obj.text} ला जायचे आहे / घेऊन चला.`,
                    phonetic: isNear ? `Dada, mala javalchya ${obj.pron} la jaayche aahe.` : `Dada, mala ${obj.pron} la jaayche aahe.`
                };
            }
            return {
                translated: isNear ? `भैया, मुझे पास के ${obj.text} जाना है / छोड़ दीजिए।` : `भैया, मुझे ${obj.text} जाना है / छोड़ दीजिए।`,
                phonetic: isNear ? `Bhaiya, mujhe paas ke ${obj.pron} jaana hai.` : `Bhaiya, mujhe ${obj.pron} jaana hai.`
            };
        }

        if (/how much (is|for) (the )?(.+)/i.test(lower) || /what is the (price|cost) of (.+)/i.test(lower)) {
            const matchArr = lower.match(/how much (is|for) (the )?(.+)/i) || lower.match(/what is the (price|cost) of (.+)/i);
            const item = matchArr ? matchArr[3].replace(/[?.]/g, '').trim() : "this";
            const obj = getLocalWord(item, target);
            if (isMr) {
                return {
                    translated: `दादा, हे ${obj.text} किती रुपयांचे आहे? / किती झाले?`,
                    phonetic: `Dada, he ${obj.pron} kiti rupyānche aahe?`
                };
            }
            return {
                translated: `भैया, ${obj.text} कितने का है?`,
                phonetic: `Bhaiya, ${obj.pron} kitne ka hai?`
            };
        }

        const words = lower.split(/\s+/);
        const outWords = [];
        const pronWords = [];
        for (let w of words) {
            const cleaned = w.replace(/[^a-zA-Z0-9]/g, '');
            const obj = getLocalWord(cleaned, target);
            outWords.push(obj.text);
            pronWords.push(obj.pron);
        }

        return {
            translated: outWords.join(' '),
            phonetic: pronWords.join(' ')
        };
    };

    const makeNaturalHindustani = (text, target = "Hindi") => {
        if (target === "Marathi") {
            return text
                .replace(/रुग्णालय/g, 'हॉस्पिटल / रुग्णालय')
                .replace(/वैद्य/g, 'डॉक्टर')
                .replace(/औषधालय/g, 'मेडिकल स्टोर')
                .replace(/आरक्षक/g, 'पोलीस')
                .replace(/स्थानक/g, 'स्टेशन')
                .replace(/विमानतळ/g, 'एअरपोर्ट / विमानतळ')
                .replace(/कृपया मला/g, 'दादा मला');
        }
        return text
            .replace(/चिकित्सालय/g, 'हॉस्पिटल / अस्पताल')
            .replace(/चिकित्सक/g, 'डॉक्टर')
            .replace(/औषधालय/g, 'मेडिकल स्टोर')
            .replace(/आरक्षी/g, 'पुलिस')
            .replace(/स्थानक/g, 'स्टेशन')
            .replace(/मूल्य क्या है/g, 'कितने का है')
            .replace(/कृपया मुझे/g, 'भैया मुझे')
            .replace(/धन्यवाद सहित/g, 'थैंक यू');
    };

                    // =========================================================================
    // NEXT-LEVEL COMPREHENSIVE MULTILINGUAL OFFLINE AI BRAIN (V3.0 HYPER-TRAINED)
    // =========================================================================
    function generateOfflineAIResponse(query, lang = "English", latLong = { lat: 18.9242, lng: 72.8310 }, userProfile = {}, placeName = "Your GPS Location", isUsingRealGps = false) {
        const q = (query || "").toLowerCase().trim();
        const isHi = lang === "Hindi";
        const isMr = lang === "Marathi";
        const loc = (en, hi, mr) => isMr ? mr : (isHi ? hi : en);
        const currentLat = latLong && latLong.lat ? latLong.lat : 18.9242;
        const currentLng = latLong && latLong.lng ? latLong.lng : 72.8310;
        const resolvedPlace = (placeName && !placeName.includes("Acquiring")) ? placeName : (isUsingRealGps ? `${Number(currentLat).toFixed(4)}° N, ${Number(currentLng).toFixed(4)}° E` : "Gateway of India, Colaba");

        // 1. DYNAMIC REAL-TIME CURRENT LOCATION & GPS TELEMETRY
        if (
            q.includes("location") || q.includes("where am i") || q.includes("where i am") || 
            q.includes("my place") || q.includes("which place") || q.includes("current spot") || 
            q.includes("kahan hoon") || q.includes("kahan hu") || q.includes("jagah") || 
            q.includes("kuthe aahe") || q.includes("kuthe ahe") || q.includes("sthan")
        ) {
            return {
                intro: loc(
                    `📍 Your Live GPS Location Telemetry:`,
                    `📍 आपकी लाइव GPS लोकेशन और सुरक्षा स्थिति:`,
                    `📍 आपले थेट GPS लोकेशन व सुरक्षा स्थिती:`
                ),
                rating: loc("GPS Locked • High Precision", "GPS लॉक • सटीक स्थिति", "GPS अचूक लॉक"),
                ratingType: "safe",
                points: [
                    { 
                        color: "green", 
                        text: loc(
                            `Current Coordinates: ${Number(currentLat).toFixed(4)}° N, ${Number(currentLng).toFixed(4)}° E`,
                            `वर्तमान निर्देशांक: ${Number(currentLat).toFixed(4)}° N, ${Number(currentLng).toFixed(4)}° E`,
                            `सध्याचे निर्देशांक: ${Number(currentLat).toFixed(4)}° N, ${Number(currentLng).toFixed(4)}° E`
                        ) 
                    },
                    { 
                        color: "green", 
                        text: loc(
                            `Acquired Area / Landmark: ${resolvedPlace}`,
                            `प्राप्त स्थल / क्षेत्र: ${resolvedPlace}`,
                            `प्राप्त ठिकाण / परिसर: ${resolvedPlace}`
                        ) 
                    },
                    { 
                        color: "green", 
                        text: loc(
                            "Jurisdiction Emergency Hotline: Dial 112 for integrated Police/Ambulance dispatch",
                            "क्षेत्रीय आपातकालीन हेल्पलाइन: पुलिस/एम्बुलेंस तत्काल सहायता के लिए 112 डायल करें",
                            "स्थानिक आपत्कालीन हेल्पलाइन: पोलीस/रुग्णवाहिका तात्काळ मदतीसाठी 112 डायल करा"
                        ) 
                    },
                    { 
                        color: "orange", 
                        text: loc(
                            "Safety Status: Live Telemetry Monitored • Real-Time Beacon Active",
                            "सुरक्षा स्थिति: लाइव टेलीमेट्री सक्रिय • रियल-टाइम बीकन चालू",
                            "सुरक्षा स्थिती: थेट टेलीमेट्री सक्रिय • रिअल-टाइम बीकन सुरू"
                        ) 
                    }
                ],
                summary: loc(
                    "You can view your real-time moving blue dot and route corridors in the 'Safety' map tab of RakshaGrid.",
                    "आप रक्षाग्रिड के 'Safety' मैप टैब में अपनी लाइव स्थिति देख सकते हैं।",
                    "आपण रक्षाग्रिडच्या 'Safety' नकाशा टॅबमध्ये आपले थेट लोकेशन पाहू शकता."
                )
            };
        }

        // 2. CRITICAL DISTRESS / EMERGENCY / THREAT TO LIFE
        if (
            q.includes("emergency") || q.includes("help me") || q.includes("save me") || 
            q.includes("danger") || q.includes("threat") || q.includes("trouble") || 
            q.includes("scared") || q.includes("following me") || q.includes("stalking") || 
            q.includes("attack") || q.includes("assault") || q.includes("trapped") || 
            q.includes("harassment") || q.includes("madad karo") || q.includes("bachao") || 
            q.includes("khatre mein") || q.includes("madat kara") || q.includes("vachva") || 
            q.includes("sankat")
        ) {
            return {
                intro: loc(
                    "🚨 IMMEDIATE EMERGENCY ASSISTANCE PROTOCOL ACTIVATED:",
                    "🚨 तत्काल आपातकालीन सहायता प्रोटोकॉल सक्रिय:",
                    "🚨 तातडीची आपत्कालीन साहाय्य यंत्रणा सक्रिय:"
                ),
                rating: loc("CRITICAL EMERGENCY — ACT NOW", "गंभीर आपातकाल — तुरंत कार्रवाई करें", "गंभीर आपत्कालीन स्थिती — त्वरित कृती करा"),
                ratingType: "warning",
                points: [
                    { 
                        color: "red", 
                        text: loc(
                            "🔴 STEP 1: Slide the RED 'SLIDE TO DISPATCH SOS' button in the Safety tab to broadcast your live GPS coordinates to Police & EMS control desks.",
                            "🔴 कदम 1: पुलिस और एम्बुलेंस नियंत्रण कक्ष को अपनी लाइव GPS लोकेशन भेजने के लिए सेफ्टी टैब में लाल 'SOS' स्लाइडर तुरंत चलाएं।",
                            "🔴 पायरी 1: पोलीस व रुग्णवाहिका नियंत्रण कक्षाला आपले थेट GPS लोकेशन पाठवण्यासाठी सेफ्टी टॅबमधील लाल 'SOS' स्लाइडर त्वरित वापरा."
                        ) 
                    },
                    { 
                        color: "red", 
                        text: loc(
                            "📞 STEP 2: Dial 112 immediately for Police/Ambulance/Fire all-in-one emergency dispatch.",
                            "📞 कदम 2: तत्काल पुलिस/एम्बुलेंस सहायता के लिए तुरंत 112 डायल करें।",
                            "📞 पायरी 2: तात्काळ पोलीस/रुग्णवाहिका मदतीसाठी 112 डायल करा."
                        ) 
                    },
                    { 
                        color: "orange", 
                        text: loc(
                            `🏃 STEP 3: Move immediately into a well-lit area, open shop, hotel lobby, or toward crowds in ${resolvedPlace}. If inside a cab, tell the driver to pull over near a police checkpoint.`,
                            `🏃 कदम 3: ${resolvedPlace} में तुरंत रोशनी वाले क्षेत्र, खुली दुकान, होटल लॉबी या भीड़ की तरफ जाएं। यदि टैक्सी में हैं, तो पुलिस चौकी के पास रुकने को कहें।`,
                            `🏃 पायरी 3: ${resolvedPlace} मध्ये त्वरित उजेड असलेल्या ठिकाणी, दुकानात, हॉटेलच्या लॉबीमध्ये किंवा गर्दीकडे जा. टॅक्सीत असल्यास पोलीस चौकीजवळ थांबण्यास सांगा.`
                        ) 
                    },
                    { 
                        color: "green", 
                        text: loc(
                            "👩 Women's Dedicated Helpline: Dial 103 (Immediate specialized mobile female police patrol).",
                            "👩 महिला विशेष हेल्पलाइन: 103 डायल करें (तत्काल विशेष महिला पुलिस गश्ती दल)।",
                            "👩 महिला विशेष हेल्पलाइन: 103 डायल करा (तातडीचे विशेष महिला पोलीस पथक)."
                        ) 
                    }
                ],
                summary: loc(
                    `DO NOT PANIC. Stay on the line with 112. RakshaGrid GPS telemetry is tracking your location at ${resolvedPlace}.`,
                    `घबराएं नहीं। 112 हेल्पलाइन पर कॉल चालू रखें। रक्षाग्रिड आपकी लोकेशन (${resolvedPlace}) ट्रैक कर रहा है।`,
                    `घाबरू नका. 112 हेल्पलाइनशी संपर्कात राहा. रक्षाग्रिड आपले लोकेशन (${resolvedPlace}) ट्रॅक करत आहे.`
                )
            };
        }

        // 3A. HOSPITALS, CLINICS, MEDICAL & AMBULANCE (ONLY HOSPITALS)
        if (
            q.includes("hospital") || q.includes("doctor") || q.includes("medical") || 
            q.includes("clinic") || q.includes("ambulance") || q.includes("dawakhana") || 
            q.includes("ill") || q.includes("injury") || q.includes("sick") || 
            q.includes("upchar") || q.includes("aspatal") || q.includes("rujnalay")
        ) {
            return {
                intro: loc(
                    `🏥 24/7 Verified Emergency Hospitals & Medical Care near ${resolvedPlace} (${Number(currentLat).toFixed(4)}° N, ${Number(currentLng).toFixed(4)}° E):`,
                    `🏥 ${resolvedPlace} (${Number(currentLat).toFixed(4)}° N, ${Number(currentLng).toFixed(4)}° E) के निकटतम 24/7 आपातकालीन अस्पताल और ट्रॉमा सेंटर:`,
                    `🏥 ${resolvedPlace} (${Number(currentLat).toFixed(4)}° N, ${Number(currentLng).toFixed(4)}° E) जवळील 24/7 आपत्कालीन रुग्णालये व ट्रॉमा सेंटर:`
                ),
                rating: loc("Emergency Medical Care Active", "आपातकालीन चिकित्सा सक्रिय", "आपत्कालीन वैद्यकीय सेवा सक्रिय"),
                ratingType: "safe",
                points: [
                    { color: "red", text: loc(`🚨 Free Govt 24/7 Ambulance: Dial 108 for Advanced Life Support (ALS) with oxygen & paramedics dispatched to ${resolvedPlace}`, `🚨 24 घंटे मुफ्त सरकारी एम्बुलेंस: 108 डायल करें (${resolvedPlace} पर तत्काल एम्बुलेंस आगमन)`, `🚨 मोफत शासकीय रुग्णवाहिका: 108 डायल करा (${resolvedPlace} येथे तातडीने रुग्णवाहिका उपलब्ध)`) },
                    { color: "red", text: loc(`🏥 24/7 Emergency Casualty & Trauma Wards: Direct admission available at nearest multi-speciality medical centers in ${resolvedPlace}`, `🏥 24/7 इमरजेंसी ट्रॉमा वार्ड: ${resolvedPlace} के निकटतम सुपर-स्पेशियलिटी अस्पतालों में तत्काल भर्ती`, `🏥 24/7 आपत्कालीन विभाग: ${resolvedPlace} परिसरातील मल्टि-स्पेशालिटी रुग्णालयांमध्ये तातडीचे उपचार`) },
                    { color: "orange", text: loc(`🩺 Integrated Police-EMS Dispatch: Dial 112 for synchronized emergency medical response and green corridor escort`, `🩺 एकीकृत इमरजेंसी हेल्पलाइन: 112 डायल करें (एम्बुलेंस के लिए पुलिस सुरक्षा एस्कॉर्ट)`, `🩺 एकात्मिक आपत्कालीन सेवा: 112 डायल करा (रुग्णवाहिका व पोलीस सहकार्य)`) },
                    { color: "green", text: loc(`📍 Live GPS Telemetry: Your coordinates (${Number(currentLat).toFixed(4)}° N, ${Number(currentLng).toFixed(4)}° E) are ready for paramedic navigation`, `📍 लाइव GPS नेविगेशन: आपके निर्देशांक (${Number(currentLat).toFixed(4)}° N, ${Number(currentLng).toFixed(4)}° E) एम्बुलेंस रूटिंग के लिए सक्रिय हैं`, `📍 थेट GPS लोकेशन: आपले निर्देशांक (${Number(currentLat).toFixed(4)}° N, ${Number(currentLng).toFixed(4)}° E) रुग्णवाहिका मार्गदर्शनासाठी तयार आहेत`) }
                ],
                summary: loc(
                    "Click the button below to navigate directly to the nearest hospital via Google Maps.",
                    "गूगल मैप्स पर निकटतम अस्पताल देखने और जाने के लिए नीचे दिए गए बटन पर क्लिक करें।",
                    "गुगल मॅप्सवर जवळचे रुग्णालय पाहण्यासाठी आणि जाण्यासाठी खालील बटणावर क्लिक करा."
                ),
                mapsLink: `https://www.google.com/maps/search/hospitals+emergency/@${currentLat},${currentLng},15z`,
                mapsLabel: loc("📍 Open Hospitals on Google Maps (Directions)", "📍 गूगल मैप्स पर अस्पताल देखें (दिशा-निर्देश)", "📍 गुगल मॅप्सवर रुग्णालये उघडा (मार्गदर्शन)")
            };
        }

        // 3B. POLICE STATIONS, BEAT CHOWKIS & COPS (ONLY POLICE)
        if (
            q.includes("police") || q.includes("cops") || q.includes("chowki") || 
            q.includes("thana") || q.includes("thanedar") || q.includes("police post") || 
            q.includes("patrol") || q.includes("marshal")
        ) {
            return {
                intro: loc(
                    `👮 Verified Police Stations & Security Posts serving ${resolvedPlace} (${Number(currentLat).toFixed(4)}° N, ${Number(currentLng).toFixed(4)}° E):`,
                    `👮 ${resolvedPlace} (${Number(currentLat).toFixed(4)}° N, ${Number(currentLng).toFixed(4)}° E) के लिए अधिकृत पुलिस स्टेशन और सहायता चौकियां:`,
                    `👮 ${resolvedPlace} (${Number(currentLat).toFixed(4)}° N, ${Number(currentLng).toFixed(4)}° E) परिसरातील अधिकृत पोलीस ठाणी व पोलीस चौकिया:`
                ),
                rating: loc("Police Patrol Active", "पुलिस सुरक्षा ग्रिड सक्रिय", "पोलीस बंदोबस्त कार्यरत"),
                ratingType: "safe",
                points: [
                    { color: "green", text: loc(`🚨 Local Police Jurisdiction: Dial 112 for immediate motorcycle / patrol car response to ${resolvedPlace}`, `🚨 स्थानीय पुलिस स्टेशन: ${resolvedPlace} में तत्काल बाइक/कार पुलिस सहायता के लिए 112 डायल करें`, `🚨 स्थानिक पोलीस ठाणे: ${resolvedPlace} मध्ये तात्काळ पोलीस मदतीसाठी 112 डायल करा`) },
                    { color: "green", text: loc(`🛡️ Tourist Police Multilingual Helpdesk: Dial 1363 (24/7 Toll-Free assistance for domestic & foreign tourists)`, `🛡️ पर्यटन पुलिस सहायता केंद्र: 1363 डायल करें (24 घंटे बहुभाषी सहायता)`, `🛡️ पर्यटन पोलीस मदत केंद्र: 1363 डायल करा (24 तास बहुभाषिक मदत)`) },
                    { color: "orange", text: loc(`👩 Women's Safety Rapid Response Squad: Dial 103 (Specialized female mobile patrol squad)`, `👩 महिला सुरक्षा त्वरित प्रतिसाद दल: 103 डायल करें (महिला सुरक्षा विशेष हेल्पलाइन)`, `👩 महिला सुरक्षा विशेष पथक: 103 डायल करा (महिला सुरक्षेसाठी तातडीची मदत)`) },
                    { color: "green", text: loc(`📋 Instant FIR & Lost Property NC: Local police stations in ${resolvedPlace} assist tourists with official claims`, `📋 त्वरित FIR व लॉस्ट रिपोर्ट: ${resolvedPlace} के सभी पुलिस स्टेशन पर्यटकों की रिपोर्ट दर्ज करते हैं`, `📋 त्वरित तक्रार नोंदणी: ${resolvedPlace} मधील सर्व पोलीस ठाणी पर्यटकांना सहकार्य करतात`) }
                ],
                summary: loc(
                    "Click the button below to view nearby police stations on Google Maps and get turn-by-turn directions.",
                    "गूगल मैप्स पर निकटतम पुलिस स्टेशन देखने और जाने के लिए नीचे दिए गए बटन पर क्लिक करें।",
                    "गुगल मॅप्सवर जवळचे पोलीस ठाणे पाहण्यासाठी व जाण्यासाठी खालील बटणावर क्लिक करा."
                ),
                mapsLink: `https://www.google.com/maps/search/police+station/@${currentLat},${currentLng},15z`,
                mapsLabel: loc("📍 Open Police Stations on Google Maps (Directions)", "📍 गूगल मैप्स पर पुलिस स्टेशन देखें (दिशा-निर्देश)", "📍 गुगल मॅप्सवर पोलीस ठाणी उघडा (मार्गदर्शन)")
            };
        }

        // 3C. PHARMACIES & CHEMISTS (ONLY PHARMACY)
        if (
            q.includes("pharmacy") || q.includes("chemist") || q.includes("medicine") || 
            q.includes("dawa") || q.includes("aushadh")
        ) {
            return {
                intro: loc(
                    `💊 24/7 Verified Pharmacies & Chemist Stores near ${resolvedPlace} (${Number(currentLat).toFixed(4)}° N, ${Number(currentLng).toFixed(4)}° E):`,
                    `💊 ${resolvedPlace} (${Number(currentLat).toFixed(4)}° N, ${Number(currentLng).toFixed(4)}° E) के आसपास के 24/7 मेडिकल स्टोर व फार्मेसी:`,
                    `💊 ${resolvedPlace} (${Number(currentLat).toFixed(4)}° N, ${Number(currentLng).toFixed(4)}° E) परिसरातील 24/7 औषधालये व मेडिकल स्टोअर्स:`
                ),
                rating: loc("24/7 Medicine Delivery Active", "24/7 दवा आपूर्ति सक्रिय", "24/7 औषध पुरवठा उपलब्ध"),
                ratingType: "safe",
                points: [
                    { color: "green", text: loc(`💊 24/7 Emergency Medicine Helpline: Apollo 24/7 (1860 500 0101) & MedPlus emergency chemist network`, `💊 24 घंटे दवा आपूर्ति हेल्पलाइन: अपोलो 24/7 (1860 500 0101) व मेडप्लस नेटवर्क`, `💊 24 तास औषध हेल्पलाइन: अपोलो 24/7 (1860 500 0101) व मेडप्लस नेटवर्क`) },
                    { color: "green", text: loc(`🏪 Round-the-clock Chemist Shops: Mapped medical stores open 24 hours in and around ${resolvedPlace}`, `🏪 24 घंटे खुले मेडिकल स्टोर: ${resolvedPlace} में स्थित 24 घंटे खुली दवा दुकानें`, `🏪 24 तास सुरू असणारी औषध दुकाने: ${resolvedPlace} परिसरातील मेडिकल दुकाने`) },
                    { color: "orange", text: loc(`🩺 Essential Medical Kit: Keep ORS, antiseptic band-aids, paracetamol, and antacids handy`, `🩺 प्राथमिक चिकित्सा: ओआरएस (ORS), बैंड-एड, पैरासिटामोल व एंटासिड अपने पास रखें`, `🩺 प्रथमोपचार साहित्य: ओआरएस (ORS), बँड-एड, पॅरासिटामॉल सोबत ठेवा`) }
                ],
                summary: loc(
                    "Click the button below to find 24/7 open pharmacies and chemists on Google Maps.",
                    "गूगल मैप्स पर 24 घंटे खुले मेडिकल स्टोर देखने के लिए नीचे दिए गए बटन पर क्लिक करें।",
                    "गुगल मॅप्सवर 24 तास सुरू असणारी औषध दुकाने पाहण्यासाठी खालील बटणावर क्लिक करा."
                ),
                mapsLink: `https://www.google.com/maps/search/pharmacy+chemist/@${currentLat},${currentLng},15z`,
                mapsLabel: loc("📍 Open Pharmacies on Google Maps (Directions)", "📍 गूगल मैप्स पर मेडिकल स्टोर देखें (दिशा-निर्देश)", "📍 गुगल मॅप्सवर औषधालये उघडा (मार्गदर्शन)")
            };
        }

        // 3D. COMPLETE NEARBY SURROUNDINGS & FACILITIES DIRECTORY ("EVERYTHING AROUND ME")
        if (
            q.includes("around") || q.includes("near me") || q.includes("nearby") || 
            q.includes("surrounding") || q.includes("facilities") || q.includes("everything") || 
            q.includes("aas paas") || q.includes("as pas") || q.includes("javal") || 
            q.includes("parisarat") || q.includes("area")
        ) {
            return {
                intro: loc(
                    `📍 Complete Facilities & Emergency Directory around ${resolvedPlace} (${Number(currentLat).toFixed(4)}° N, ${Number(currentLng).toFixed(4)}° E):`,
                    `📍 ${resolvedPlace} (${Number(currentLat).toFixed(4)}° N, ${Number(currentLng).toFixed(4)}° E) के आसपास की सभी सत्यापित आपातकालीन व सार्वजनिक सुविधाएं:`,
                    `📍 ${resolvedPlace} (${Number(currentLat).toFixed(4)}° N, ${Number(currentLng).toFixed(4)}° E) परिसरातील सर्व अधिकृत सेवा व सुविधा:`
                ),
                rating: loc("Local Emergency Grid Connected", "स्थानीय आपातकालीन ग्रिड कनेक्टेड", "स्थानिक आपत्कालीन सेवा उपलब्ध"),
                ratingType: "safe",
                points: [
                    { color: "green", text: loc(`👮 Police Station Jurisdiction: Dial 112 for immediate dispatch to ${resolvedPlace} (24/7 Police Flying Squad & Beat Patrol)`, `👮 पुलिस सहायता: ${resolvedPlace} के लिए 112 डायल करें (24/7 पुलिस बाइक व कार गश्ती दल)`, `👮 पोलीस मदत: ${resolvedPlace}साठी 112 डायल करा (24/7 पोलीस पथक)`) },
                    { color: "red", text: loc(`🏥 Hospitals & 24/7 Trauma Care: Dial 108 for Free Govt Emergency Life-Support Ambulance directly to ${resolvedPlace}`, `🏥 अस्पताल व ट्रॉमा केयर: ${resolvedPlace} पर मुफ्त सरकारी एम्बुलेंस के लिए 108 डायल करें`, `🏥 रुग्णालय व आपत्कालीन कक्ष: मोफत शासकीय रुग्णवाहिकेसाठी 108 डायल करा`) },
                    { color: "orange", text: loc(`💊 24/7 Pharmacy & Medicines: Call National 24hr Chemist Network (1860 500 0101) in ${resolvedPlace}`, `💊 24/7 मेडिकल स्टोर: ${resolvedPlace} में 24 घंटे खुली फार्मेसी (1860 500 0101)`, `💊 24/7 औषधालय: ${resolvedPlace} मधील 24 तास सुरू असणारी औषध दुकाने`) },
                    { color: "green", text: loc(`🚕 Safe Transit & Escort: Regulated local taxis/autos in ${resolvedPlace}; Dial 112 if stranded at night`, `🚕 सुरक्षित परिवहन: ${resolvedPlace} में स्थानीय टैक्सी/ऑटो; रात में फंसे होने पर 112 डायल करें`, `🚕 सुरक्षित वाहतूक: ${resolvedPlace} मध्ये स्थानिक टॅक्सी/रिक्षा; रात्री मदतीसाठी 112 डायल करा`) },
                    { color: "green", text: loc(`🛡️ Tourist Safety Support: 24/7 Toll-Free Multilingual Tourist Helpline: 1363`, `🛡️ पर्यटक सुरक्षा सहायता: 24/7 टोल-फ्री बहुभाषी पर्यटन हेल्पलाइन: 1363`, `🛡️ पर्यटक सुरक्षा साहाय्य: 24/7 टोल-फ्री बहुभाषिक पर्यटन हेल्पलाइन: 1363`) }
                ],
                summary: loc(
                    "Click the button below to view all surrounding amenities and emergency services on Google Maps.",
                    "गूगल मैप्स पर आसपास की सभी सुविधाएं देखने के लिए नीचे दिए गए बटन पर क्लिक करें।",
                    "गुगल मॅप्सवर परिसरातील सर्व सुविधा पाहण्यासाठी खालील बटणावर क्लिक करा."
                ),
                mapsLink: `https://www.google.com/maps/search/emergency+services+and+facilities/@${currentLat},${currentLng},15z`,
                mapsLabel: loc("📍 Open All Facilities on Google Maps", "📍 गूगल मैप्स पर सभी सुविधाएं देखें", "📍 गुगल मॅप्सवर सर्व सुविधा उघडा")
            };
        }

        // 4. TOP PLACES TO VISIT & SIGHTSEEING ITINERARY
        if (
            q.includes("places to visit") || q.includes("sightseeing") || q.includes("tourist attractions") || 
            q.includes("what to see") || q.includes("best places") || q.includes("ghumne ki jagah") || 
            q.includes("kahan ghumu") || q.includes("firnyachi thikane") || q.includes("itinerary")
        ) {
            return {
                intro: loc(
                    "Top Must-Visit Tourist Attractions in South Mumbai (Safe Heritage Circuit):",
                    "दक्षिण मुंबई में शीर्ष दर्शनीय स्थल (सुरक्षित हेरिटेज सर्किट):",
                    "दक्षिण मुंबईतील प्रमुख प्रेक्षणीय स्थळे (सुरक्षित हेरिटेज मार्ग):"
                ),
                rating: loc("Safe Heritage Zone", "सुरक्षित हेरिटेज क्षेत्र", "सुरक्षित ऐतिहासिक परिसर"),
                ratingType: "safe",
                points: [
                    { color: "green", text: loc("1. Gateway of India & Taj Mahal Palace: Iconic waterfront arch & luxury heritage architecture.", "1. गेटवे ऑफ इंडिया और ताज महल पैलेस: ऐतिहासिक समुद्री तोरण और हेरिटेज वास्तुकला।", "1. गेटवे ऑफ इंडिया आणि ताजमहाल पॅलेस: ऐतिहासिक स्मारक व हेरिटेज सौंदर्य.") },
                    { color: "green", text: loc("2. Marine Drive (Queen's Necklace): 3.6km coastal promenade, best for sunset walks until 11 PM.", "2. मरीन ड्राइव (क्वींस नेकलेस): 3.6 किमी लंबा तटीय प्रोमेनेड, सूर्यास्त के समय घूमने के लिए सर्वश्रेष्ठ।", "2. मरीन ड्राईव्ह (क्वीन्स नेकलेस): 3.6 किमी किनारपट्टीचा रस्ता, संध्याकाळी फिरण्यासाठी उत्तम.") },
                    { color: "green", text: loc("3. Chhatrapati Shivaji Maharaj Terminus (CSMT): UNESCO World Heritage Gothic Victorian railway station.", "3. छत्रपति शिवाजी महाराज टर्मिनस (CSMT): यूनेस्को विश्व धरोहर गोथिक विक्टोरियन स्टेशन।", "3. छत्रपती शिवाजी महाराज टर्मिनस (CSMT): युनेस्को जागतिक वारसा असलेले भव्य स्टेशन.") },
                    { color: "orange", text: loc("4. Elephanta Island Caves: Ancient 5th-century rock-cut Shiva caves (Ferry from Gateway, closed Mondays).", "4. एलिफेंटा गुफाएं: प्राचीन 5वीं शताब्दी की पाषाण-निर्मित शिव गुफाएं (गेटवे से नाव, सोमवार बंद)।", "4. एलिफंटा लेणी: प्राचीन 5व्या शतकातील लेण्या (गेटवेवरून बोट, सोमवारी बंद).") },
                    { color: "green", text: loc("5. Colaba Causeway Market: Vibrant street shopping for antiques, clothes, and heritage cafes (Leopold/Mondegar).", "5. कोलाबा कॉजवे मार्केट: कपड़े, प्राचीन वस्तुएं और प्रसिद्ध कैफे (लियोपोल्ड/मोंडेगर)।", "5. कुलाबा कॉजवे मार्केट: कपडे, शोभेच्या वस्तू आणि प्रसिद्ध कॅफे (लिओपोल्ड/मोंडेगर).") }
                ],
                summary: loc(
                    "All these attractions are within a 3km radius of Colaba and connected by black-and-yellow metered taxis.",
                    "ये सभी दर्शनीय स्थल कोलाबा से 3 किमी के दायरे में हैं और मीटर वाली टैक्सियों से आसानी से जुड़े हैं।",
                    "ही सर्व ठिकाणे कुलाब्यापासून 3 किमीच्या परिसरात असून मीटर टॅक्सीने सहज पोहोचता येते."
                )
            };
        }

        // 5. WEATHER, RAIN, MONSOON & SWELL SAFETY
        if (
            q.includes("weather") || q.includes("rain") || q.includes("monsoon") || 
            q.includes("flood") || q.includes("waterlog") || q.includes("season") || 
            q.includes("temperature") || q.includes("barish") || q.includes("paus") || q.includes("havaman")
        ) {
            return {
                intro: loc(
                    "Current Weather & Coastal Ocean Swell Advisory for Mumbai:",
                    "मुंबई के लिए वर्तमान मौसम और तटीय लहर सुरक्षा परामर्श:",
                    "मुंबईसाठी हवामान आणि किनारपट्टी लाटांची सुरक्षा सूचना:"
                ),
                rating: loc("Tropical Coastal Weather", "तटीय मौसम", "किनारपट्टी हवामान"),
                ratingType: "safe",
                points: [
                    { color: "green", text: loc("Climate: Pleasant tropical sea breeze, average temperatures between 24°C and 32°C.", "मौसम: सुखद तटीय हवा, औसत तापमान 24°C से 32°C के बीच रहता है।", "हवामान: आल्हाददायक समुद्राची हवा, तापमान 24°C ते 32°C दरम्यान.") },
                    { color: "orange", text: loc("High Tide Notice: Avoid standing on sea-facing rocks or tetrapods during high tide peaks.", "हाई टाइड सूचना: तेज लहरों के समय समुद्र की चट्टानों या टेट्रापॉड पत्थरों पर न खड़े हों।", "हाय टाईड सूचना: भरतीच्या वेळी समुद्राच्या दगडांवर किंवा काठावर उभे राहू नका.") },
                    { color: "green", text: loc("Rain Season Advice (June-Sept): Carry a sturdy umbrella and check BMC disaster radar.", "मानसून सलाह (जून-सितंबर): मजबूत छाता साथ रखें और BMC जलभराव बुलेटिन देखें।", "पावसाळा सल्ला (जून-सप्टेंबर): सोबत छत्री ठेवा आणि पालिकेचे अलर्ट तपासा.") }
                ],
                summary: loc(
                    "Real-time sea wave alerts are automatically updated in the RakshaGrid radar banner above.",
                    "रियल-टाइम समुद्री लहरों के अलर्ट रक्षाग्रिड के लाइव अलर्ट बैनर में अपडेट होते रहते हैं।",
                    "थेट समुद्राच्या लाटांचे अलर्ट रक्षाग्रिडच्या वरील अलर्ट पट्टीमध्ये सातत्याने अपडेट होतात."
                )
            };
        }

        // 6. EMERGENCY HELPLINE NUMBERS
        if (
            q.includes("112") || q.includes("number") || q.includes("helpline") || 
            q.includes("call") || q.includes("police number") || q.includes("ambulance number") || 
            q.includes("contact police") || q.includes("emergency contact")
        ) {
            return {
                intro: loc(
                    "Official 24/7 Emergency Helpline Directory for Maharashtra & Mumbai:",
                    "महाराष्ट्र और मुंबई के लिए आधिकारिक 24/7 आपातकालीन हेल्पलाइन सूची:",
                    "महाराष्ट्र आणि मुंबईसाठी अधिकृत 24/7 आपत्कालीन हेल्पलाइन सूची:"
                ),
                rating: loc("Emergency Hotlines Active", "आपातकालीन हेल्पलाइन सक्रिय", "आपत्कालीन हेल्पलाइन सक्रिय"),
                ratingType: "safe",
                points: [
                    { color: "red", text: loc("National Emergency Number (All-in-One Police/Fire/Ambulance): Dial 112", "अखिल भारतीय आपातकालीन नंबर (पुलिस/फायर/एम्बुलेंस): 112 डायल करें", "अखिल भारतीय आपत्कालीन नंबर (पोलीस/अग्निशामक/रुग्णवाहिका): 112 डायल करा") },
                    { color: "green", text: loc("Medical & Trauma Ambulance: Dial 108 (Free 24/7 Gov Service)", "मुफ्त सरकारी एम्बुलेंस सेवा: 108 डायल करें", "मोफत शासकीय रुग्णवाहिका सेवा: 108 डायल करा") },
                    { color: "green", text: loc("Women Safety & Anti-Harassment Helpline: Dial 103 or 112", "महिला सुरक्षा एवं हेल्पलाइन: 103 या 112 डायल करें", "महिला सुरक्षा व तक्रार हेल्पलाइन: 103 किंवा 112 डायल करा") },
                    { color: "orange", text: loc("Tourist Police Info Desk: Dial 1363 (Toll-Free Multilingual)", "पर्यटन पुलिस सूचना डेस्क: 1363 डायल करें (टोल-फ्री बहुभाषी)", "पर्यटन पोलीस माहिती कक्ष: 1363 डायल करा (टोल-फ्री)") }
                ],
                summary: loc(
                    "You can also press the SOS button in this app to automatically transmit your GPS coordinates to the nearest dispatch station.",
                    "आप इस ऐप में SOS बटन दबाकर भी अपनी GPS लोकेशन सीधे पुलिस नियंत्रण कक्ष को भेज सकते हैं।",
                    "आपण या ॲपमधील SOS बटण दाबूनही आपले GPS लोकेशन थेट पोलीस नियंत्रण कक्षाला पाठवू शकता."
                )
            };
        }

        // 7. LOST PASSPORT, WALLET, PHONE OR BELONGINGS
        if (
            q.includes("lost") || q.includes("passport") || q.includes("wallet") || 
            q.includes("phone") || q.includes("bag") || q.includes("stolen") || 
            q.includes("theft") || q.includes("purse") || q.includes("robbed") || 
            q.includes("haravle") || q.includes("kho gaya")
        ) {
            return {
                intro: loc(
                    "Action protocol for lost documents, passports, and valuables in Mumbai:",
                    "मुंबई में खोए हुए दस्तावेज, पासपोर्ट या कीमती सामान के लिए तत्काल कार्रवाई गाइड:",
                    "मुंबईत हरवलेली कागदपत्रे, पासपोर्ट किंवा मौल्यवान वस्तूंसाठी तातडीची कृती योजना:"
                ),
                rating: loc("Assistance Protocol Active", "सहायता प्रोटोकॉल सक्रिय", "मदत प्रोटोकॉल सक्रिय"),
                ratingType: "warning",
                points: [
                    { color: "green", text: loc("Log an official claim in the 'Lost & Found' tab of RakshaGrid to alert the Police Desk", "पुलिस को सूचित करने के लिए रक्षाग्रिड के 'Lost & Found' टैब में रिपोर्ट दर्ज करें", "पोलिसांना अलर्ट करण्यासाठी रक्षाग्रिडच्या 'Lost & Found' टॅबमध्ये नोंदणी करा") },
                    { color: "orange", text: loc("Visit the nearest Police Station (e.g. Colaba Police Station) for a Lost Property Certificate (NC)", "नजदीकी पुलिस स्टेशन जाकर लॉस्ट रिपोर्ट (NC/FIR) की कॉपी प्राप्त करें", "जवळच्या पोलीस ठाण्यात जाऊन हरवल्याची अधिकृत नोंद (NC/FIR) घ्या") },
                    { color: "red", text: loc("For Lost Foreign Passport: Contact your Country Consulate / Embassy in BKC or South Mumbai", "विदेशी पासपोर्ट खोने पर: BKC या दक्षिण मुंबई स्थित अपने दूतावास (Consulate) से संपर्क करें", "परदेशी पासपोर्ट हरवल्यास: BKC किंवा दक्षिण मुंबईतील आपल्या दूतावासाशी संपर्क साधा") },
                    { color: "orange", text: loc("Block stolen credit/debit cards immediately via your bank's emergency hotline", "चोरी हुए बैंक कार्ड को बैंक हेल्पलाइन पर कॉल करके तुरंत ब्लॉक करें", "चोरी झालेले बँक कार्ड बँकेच्या हेल्पलाइनवर कॉल करून त्वरित ब्लॉक करा") }
                ],
                summary: loc(
                    "Colaba Police Station Contact: +91 22 2218 2222. Marine Drive Police Post: +91 22 2281 1845.",
                    "कोलाबा पुलिस स्टेशन फोन: +91 22 2218 2222. मरीन ड्राइव पुलिस: +91 22 2281 1845.",
                    "कुलाबा पोलीस ठाणे फोन: +91 22 2218 2222. मरीन ड्राईव्ह पोलीस: +91 22 2281 1845."
                )
            };
        }

        // 8. JUHU BEACH & MARINE DRIVE
        if (
            q.includes("juhu") || q.includes("beach") || q.includes("chowpatty") || 
            q.includes("night") || q.includes("8 pm") || q.includes("marine drive") || 
            q.includes("water") || q.includes("tide") || q.includes("sea")
        ) {
            return {
                intro: loc(
                    "Shoreline safety and night promenade advisory for Juhu Beach & Marine Drive:",
                    "जुहू बीच और मरीन ड्राइव के लिए तटवर्ती सुरक्षा और रात्रि सैर दिशानिर्देश:",
                    "जुहू बीच आणि मरीन ड्राईव्हसाठी किनारपट्टी सुरक्षा व रात्रीच्या प्रवासाबाबत मार्गदर्शक सूचना:"
                ),
                rating: loc("Generally Safe (Until 11:00 PM)", "सामान्यतः सुरक्षित (रात 11:00 बजे तक)", "सर्वसाधारणपणे सुरक्षित (रात्री 11:00 वाजेपर्यंत)"),
                ratingType: "safe",
                points: [
                    { color: "green", text: loc("Promenades are heavily patrolled by Mumbai Police and active with families until 11 PM", "प्रोमेनेड पर मुंबई पुलिस की नियमित गश्त रहती है और रात 11 बजे तक परिवारों की चहल-पहल रहती है", "प्रोमेनेडवर मुंबई पोलिसांची गस्त असते आणि रात्री 11 वाजेपर्यंत लोकांची गर्दी असते") },
                    { color: "orange", text: loc("Do NOT enter the water after dark or sit on slippery coastal tetrapods during high tide", "अंधेरा होने के बाद समुद्र के पानी में न उतरें और हाई टाइड के दौरान टेट्रापॉड्स पर न बैठें", "अंधार पडल्यानंतर समुद्राच्या पाण्यात उतरू नका आणि हाय टाईडच्या वेळी दगडांवर बसू नका") },
                    { color: "green", text: loc("Lifeguards and Police Booths are stationed every 300 meters along main beaches", "प्रमुख समुद्र तटों पर हर 300 मीटर पर लाइफगार्ड और पुलिस सहायता बूथ उपलब्ध हैं", "मुख्य समुद्रकिनाऱ्यावर दर 300 मीटरवर जीवरक्षक आणि पोलीस मदत कक्ष आहेत") }
                ],
                summary: loc(
                    "Check the Live Radar Map in this app for dynamic swell alerts and high tide warnings.",
                    "लाइव हाई टाइड और लहरों के अलर्ट देखने के लिए इस ऐप के मैप सेक्शन को चेक करें।",
                    "थेट भरती-ओहोटी आणि लाटांचे अलर्ट पाहण्यासाठी या ॲपमधील मॅप तपासा."
                )
            };
        }

        // 11. GATEWAY OF INDIA & COLABA
        if (
            q.includes("gateway") || q.includes("colaba") || q.includes("elephanta") || 
            q.includes("taj mahal") || q.includes("tour") || q.includes("shopping")
        ) {
            return {
                intro: loc(
                    "Visitor security, timings, and transit guide for Gateway of India & Colaba Precinct:",
                    "गेटवे ऑफ इंडिया और कोलाबा हेरिटेज क्षेत्र के लिए सुरक्षा, समय और पर्यटन गाइड:",
                    "गेटवे ऑफ इंडिया आणि कुलाबा हेरिटेज परिसरासाठी सुरक्षा, वेळ व पर्यटन माहिती:"
                ),
                rating: loc("High Security Zone (Safe)", "उच्च सुरक्षा क्षेत्र (सुरक्षित)", "उच्च सुरक्षा क्षेत्र (सुरक्षित)"),
                ratingType: "safe",
                points: [
                    { color: "green", text: loc("Gateway of India promenade is monitored 24/7 by Police, Navy, and CCTV grids", "गेटवे ऑफ इंडिया पर 24/7 पुलिस, नौसेना और सीसीटीवी ग्रिड की कड़ी सुरक्षा है", "गेटवे ऑफ इंडियावर 24/7 पोलीस, नौदल आणि सीसीटीव्हीची चोख सुरक्षा आहे") },
                    { color: "orange", text: loc("Elephanta Island Ferries depart every 30 mins from Gateway Jetty (9:00 AM - 3:30 PM, Closed Mondays)", "एलिफेंटा फेरी हर 30 मिनट में गेटवे जेट्टी से चलती है (सुबह 9:00 से दोपहर 3:30, सोमवार बंद)", "एलिफंटा बोट दर 30 मिनिटांनी गेटवे जेट्टीवरून सुटते (सकाळी 9:00 ते दुपारी 3:30, सोमवारी बंद)") },
                    { color: "green", text: loc("Colaba Causeway Shopping Market is a 3-minute walk away (Bargaining is common)", "कोलाबा कॉजवे शॉपिंग मार्केट 3 मिनट की पैदल दूरी पर है (मोलभाव कर सकते हैं)", "कुलाबा कॉजवे शॉपिंग मार्केट 3 मिनिटांच्या अंतरावर आहे") }
                ],
                summary: loc(
                    "Tourist Police Assistance Booth is located directly opposite the Gateway arch.",
                    "पर्यटक पुलिस सहायता बूथ गेटवे ऑफ इंडिया के प्रवेश द्वार के ठीक सामने स्थित है।",
                    "पर्यटक पोलीस मदत केंद्र गेटवे ऑफ इंडियाच्या अगदी समोर उपलब्ध आहे."
                )
            };
        }

        // 12. FOOD, WATER & RESTAURANTS
        if (
            q.includes("food") || q.includes("water") || q.includes("eat") || 
            q.includes("drink") || q.includes("restaurant") || q.includes("veg") || 
            q.includes("spicy") || q.includes("hygiene") || q.includes("vada pav")
        ) {
            return {
                intro: loc(
                    "Food hygiene, safe drinking water, and restaurant advice in Mumbai:",
                    "मुंबई में भोजन स्वच्छता, सुरक्षित पेयजल और रेस्तरां दिशानिर्देश:",
                    "मुंबईत अन्न स्वच्छता, सुरक्षित पिण्याचे पाणी आणि हॉटेलविषयी मार्गदर्शन:"
                ),
                rating: loc("Healthy Practice Recommended", "स्वच्छता सलाह", "स्वच्छता सल्ला"),
                ratingType: "safe",
                points: [
                    { color: "green", text: loc("Drink ONLY sealed bottled mineral water (Bisleri, Kinley, Aquafina) with intact seal", "हमेशा सीलबंद पैकेज्ड मिनरल वाटर (Bisleri / Kinley) ही पिएं", "नेहमी सीलबंद पॅकेज्ड मिनरल वॉटरच (Bisleri / Kinley) प्या") },
                    { color: "orange", text: loc("Specify 'Kam Teekha' (Less spicy) when ordering Indian cuisine at local cafes", "स्थानीय होटलों में ऑर्डर करते समय 'कम तीखा' (Less spicy) कहें", "स्थानिक हॉटेल्समध्ये ऑर्डर करताना 'कमी तिखट' (Less spicy) सांगा") },
                    { color: "green", text: loc("Famous hygienic food spots: Leopold Cafe, Cafe Mondegar, Bademiya, Shiv Sagar (Pure Veg)", "प्रसिद्ध भोजन स्थल: लियोपोल्ड कैफे, कैफे मोंडेगर, बडेमियां, शिव सागर (प्योर वेज)", "प्रसिद्ध खाण्याची ठिकाणे: लिओपोल्ड कॅफे, कॅफे मोंडेगर, बडेमियाँ, शिव सागर (शाकाहारी)") }
                ],
                summary: loc(
                    "Avoid uncooked raw salads from unshaded roadside carts during hot afternoons.",
                    "दोपहर के समय धूप में खुले रखे सड़क किनारे के कटे हुए फलों या सलाद से बचें।",
                    "दुपारच्या वेळी रस्त्यावरील उघड्यावर ठेवलेली फळे किंवा सलाड खाणे टाळा."
                )
            };
        }

        // 13. WOMEN & SOLO TRAVELER SAFETY
        if (
            q.includes("women") || q.includes("female") || q.includes("solo") || 
            q.includes("alone") || q.includes("girl") || q.includes("safe for women")
        ) {
            return {
                intro: loc(
                    "Dedicated Women's Safety framework & special transport facilities in Mumbai:",
                    "मुंबई में महिला सुरक्षा व्यवस्था और विशेष परिवहन सुविधाएं:",
                    "मुंबईत महिला सुरक्षा यंत्रणा आणि विशेष वाहतूक सुविधा:"
                ),
                rating: loc("Protected Corridor", "संरक्षित कॉरिडोर", "संरक्षित कॉरिडोर"),
                ratingType: "safe",
                points: [
                    { color: "green", text: loc("Mumbai is widely ranked as one of India's safest cities for women and solo travelers", "मुंबई महिलाओं और एकल यात्रियों के लिए भारत के सबसे सुरक्षित शहरों में से एक है", "मुंबई महिला व एकट्या प्रवाशांसाठी भारतातील सर्वात सुरक्षित शहरांपैकी एक आहे") },
                    { color: "green", text: loc("Dedicated Women Police Helpline: Dial 103 or 112 for female officer dispatch", "महिला पुलिस हेल्पलाइन: 103 या 112 डायल करें महिला अधिकारी सहायता के लिए", "महिला पोलीस हेल्पलाइन: महिला पोलीस मदतीसाठी 103 किंवा 112 डायल करा") },
                    { color: "orange", text: loc("All Local Trains & Metro have dedicated Ladies-Only Coaches with security guards", "सभी लोकल ट्रेनों और मेट्रो में सुरक्षा गार्ड वाले विशेष महिला डिब्बे उपलब्ध हैं", "सर्व लोकल ट्रेन आणि मेट्रोमध्ये स्वतंत्र महिला डबे उपलब्ध आहेत") }
                ],
                summary: loc(
                    "If anyone makes you feel uncomfortable, press the SOS button to instantly alert nearby police beat marshals.",
                    "यदि कोई आपको असहज महसूस कराए, तो तत्काल पुलिस गश्ती दल को अलर्ट करने के लिए SOS बटन दबाएं।",
                    "कोणत्याही संशयास्पद प्रसंगी तात्काळ पोलीस मदतीसाठी SOS बटण दाबा."
                )
            };
        }

        // 14. LOCAL TRAINS & METRO
        if (
            q.includes("train") || q.includes("local") || q.includes("metro") || 
            q.includes("cst") || q.includes("station") || q.includes("churchgate") || q.includes("bus")
        ) {
            return {
                intro: loc(
                    "Suburban railway and metro navigation tips for tourists:",
                    "पर्यटकों के लिए मुंबई लोकल ट्रेन और मेट्रो यात्रा मार्गदर्शिका:",
                    "पर्यटकांसाठी मुंबई लोकल ट्रेन आणि मेट्रो प्रवास माहिती:"
                ),
                rating: loc("High Capacity Transit", "तीव्र गति परिवहन", "जलद गती वाहतूक"),
                ratingType: "safe",
                points: [
                    { color: "orange", text: loc("Avoid local trains during peak office hours (8:30-11:00 AM & 5:30-8:30 PM)", "ऑफिस के व्यस्त समय (सुबह 8:30-11:00 और शाम 5:30-8:30) लोकल ट्रेन में यात्रा से बचें", "गर्दीच्या वेळी (सकाळी 8:30-11:00 आणि संध्याकाळी 5:30-8:30) लोकल ट्रेन प्रवास टाळा") },
                    { color: "green", text: loc("Purchase 'First Class' or 'AC Local' tickets for a relaxed and uncrowded journey", "सुखद यात्रा के लिए 'फर्स्ट क्लास' या 'AC लोकल' का टिकट खरीदें", "आरामदायी प्रवासासाठी 'फर्स्ट क्लास' किंवा 'AC लोकल' तिकीट घ्या") },
                    { color: "green", text: loc("Railway Police (GRP) helpdesks are available 24/7 at CST and Churchgate platforms", "CST और चर्चगेट के सभी प्लेटफॉर्म पर रेलवे पुलिस (GRP) डेस्क उपलब्ध हैं", "CST आणि चर्चगेट स्थानकांवर 24/7 रेल्वे पोलीस (GRP) मदत कक्ष उपलब्ध आहेत") }
                ],
                summary: loc(
                    "Download the 'UTS' app for official paperless train ticketing directly on your phone.",
                    "अपने फोन पर पेपरलेस टिकट बुक करने के लिए आधिकारिक 'UTS' ऐप डाउनलोड करें।",
                    "मोबाईलवर तिकीट काढण्यासाठी अधिकृत 'UTS' ॲप वापरा."
                )
            };
        }

        // 15. GREETINGS & INTRO
        if (/^(hi|hello|hey|namaste|namaskar|pranam)/i.test(q)) {
            return {
                intro: loc(
                    "Hello! I am RakshaGrid AI, your dedicated 24/7 tourist safety assistant for Mumbai & Maharashtra.",
                    "नमस्ते! मैं रक्षाग्रिड (RakshaGrid) AI हूँ, मुंबई और महाराष्ट्र में आपका 24/7 समर्पित पर्यटक सुरक्षा सहायक।",
                    "नमस्कार! मी रक्षाग्रिड (RakshaGrid) AI आहे, मुंबई आणि महाराष्ट्रात आपला 24/7 समर्पित पर्यटक सुरक्षा सहाय्यक."
                ),
                rating: loc("Online & Active", "सक्रिय और तैयार", "सक्रिय व सज्ज"),
                ratingType: "safe",
                points: [
                    { color: "green", text: loc("Linked directly with Police Control (112) and EMS Ambulance (108)", "पुलिस नियंत्रण (112) और एम्बुलेंस (108) से सीधे जुड़ा हुआ", "पोलीस नियंत्रण कक्ष (112) आणि रुग्णवाहिका (108) शी थेट जोडलेले") },
                    { color: "green", text: loc("Ask me: 'What is my location?', 'Nearest Police Station', 'Taxi fares', or 'Places to visit'", "मुझसे पूछें: 'मेरी लोकेशन क्या है?', 'निकटतम पुलिस स्टेशन', 'टैक्सी किराया', या 'घूमने की जगहें'", "मला विचारा: 'माझे लोकेशन काय आहे?', 'जवळचे पोलीस ठाणे', 'टॅक्सी भाडे', किंवा 'पर्यटन स्थळे'") }
                ],
                summary: loc(
                    "How can I assist your travels today? Type any question or choose a prompt from above.",
                    "आज मैं आपकी क्या सहायता कर सकता हूँ? कोई भी प्रश्न पूछें या ऊपर दिए गए सुझावों में से चुनें।",
                    "आज मी आपल्याला कशी मदत करू शकतो? कोणताही प्रश्न विचारा किंवा वरील पर्यायांवर टॅप करा."
                )
            };
        }

        // 16. DYNAMIC INTELLIGENT CONTEXTUAL MATCHING
        return {
            intro: loc(
                `RakshaGrid Safety Intelligence Analysis for: "${query}"`,
                `"${query}" के लिए रक्षाग्रिड सुरक्षा विश्लेषण:`,
                `"${query}" साठी रक्षाग्रिड सुरक्षा विश्लेषण:`
            ),
            rating: loc("Safety Grid Active", "सुरक्षा ग्रिड सक्रिय", "सुरक्षा ग्रिड सक्रिय"),
            ratingType: "safe",
            points: [
                { color: "green", text: loc(`Current Live Location: Gateway Promenade (${currentLat}° N, ${currentLng}° E)`, `वर्तमान लाइव लोकेशन: गेटवे प्रोमेनेड (${currentLat}° N, ${currentLng}° E)`, `सध्याचे थेट लोकेशन: गेटवे प्रोमेनेड (${currentLat}° N, ${currentLng}° E)`) },
                { color: "green", text: loc("Police & EMS Coverage: South Mumbai 24/7 Mobile Beat Grid active with 5-min response time", "पुलिस एवं एम्बुलेंस कवरेज: दक्षिण मुंबई 24/7 मोबाइल बीट ग्रिड सक्रिय", "पोलीस व रुग्णवाहिका: दक्षिण मुंबई 24/7 गस्त पथक सक्रिय") },
                { color: "orange", text: loc("Emergency Action: Dial 112 or tap RED SOS in the Safety tab for immediate dispatch", "आपातकालीन सहायता: 112 डायल करें या सेफ्टी टैब में लाल SOS बटन दबाएं", "आपत्कालीन साहाय्य: 112 डायल करा किंवा लाल रंगाचे SOS बटण दाबा") }
            ],
            summary: loc(
                "You can ask me: 'What is my location?', 'Nearby police station', 'Best places to visit', 'Taxi rates', or 'Lost belongings'.",
                "आप मुझसे पूछ सकते हैं: 'मेरी लोकेशन क्या है?', 'निकटतम पुलिस स्टेशन', 'घूमने की जगहें', 'टैक्सी किराया', या 'खोया हुआ सामान'।",
                "आपण विचारू शकता: 'माझे लोकेशन काय आहे?', 'जवळचे पोलीस ठाणे', 'पर्यटन स्थळे', 'टॅक्सी भाडे', किंवा 'हरवलेल्या वस्तू'."
            )
        };
    }

    // =========================================================================
    // SECTION: ULTRA-SMOOTH SLIDE-TO-SOS COMPONENT (SLIDE-ONLY ACTIVATION)
    // =========================================================================
    function SlideToSosButton({ onTrigger, selectedLang }) {
        const trackRef = useRef(null);
        const [dragX, setDragX] = useState(0);
        const [isDragging, setIsDragging] = useState(false);
        const [isCompleted, setIsCompleted] = useState(false);
        const startXRef = useRef(0);

        const labelText = selectedLang === "Hindi" 
            ? "स्लाइड करके SOS भेजें" 
            : selectedLang === "Marathi" 
            ? "स्लाइड करून SOS पाठवा" 
            : "SLIDE TO DISPATCH SOS";

        const handleStart = (clientX) => {
            if (isCompleted) return;
            setIsDragging(true);
            startXRef.current = clientX;
        };

        const handleMove = (clientX, e) => {
            if (!isDragging || !trackRef.current || isCompleted) return;
            if (e && e.cancelable) e.preventDefault();
            const trackWidth = trackRef.current.offsetWidth;
            const thumbWidth = 46;
            const maxDrag = Math.max(0, trackWidth - thumbWidth - 8);
            const currentDelta = Math.max(0, Math.min(clientX - startXRef.current, maxDrag));
            setDragX(currentDelta);

            // Activate ONLY after full deliberate slide (>85% of track)
            if (currentDelta >= maxDrag * 0.85 && !isCompleted) {
                setIsCompleted(true);
                setIsDragging(false);
                setDragX(maxDrag);
                if (navigator.vibrate) navigator.vibrate([120, 60, 120]);
                onTrigger();
                setTimeout(() => {
                    setDragX(0);
                    setIsCompleted(false);
                }, 1500);
            }
        };

        const handleEnd = () => {
            if (!isDragging) return;
            setIsDragging(false);
            if (!isCompleted) {
                setDragX(0);
            }
        };

        useEffect(() => {
            const onMouseMove = (e) => handleMove(e.clientX, e);
            const onMouseUp = () => handleEnd();
            const onTouchMove = (e) => {
                if (e.touches && e.touches[0]) handleMove(e.touches[0].clientX, e);
            };
            const onTouchEnd = () => handleEnd();

            if (isDragging) {
                window.addEventListener('mousemove', onMouseMove);
                window.addEventListener('mouseup', onMouseUp);
                window.addEventListener('touchmove', onTouchMove, { passive: false });
                window.addEventListener('touchend', onTouchEnd);
            }
            return () => {
                window.removeEventListener('mousemove', onMouseMove);
                window.removeEventListener('mouseup', onMouseUp);
                window.removeEventListener('touchmove', onTouchMove);
                window.removeEventListener('touchend', onTouchEnd);
            };
        }, [isDragging, isCompleted]);

        return e("div", {
            ref: trackRef,
            className: "w-full h-14 rounded-full bg-[#0f172a] relative overflow-hidden flex items-center select-none shadow-xl border border-slate-700/50 touch-none"
        },
            // Dynamic Smooth Crimson Fill behind slider thumb
            e("div", {
                className: "absolute left-0 top-0 bottom-0 bg-gradient-to-r from-red-700 via-red-600 to-red-500 rounded-full",
                style: {
                    width: `${dragX + 46}px`,
                    opacity: dragX > 3 ? 0.95 : 0,
                    transition: isDragging ? 'none' : 'width 0.35s cubic-bezier(0.25, 1, 0.5, 1), opacity 0.3s ease'
                }
            }),
            // Centered helper label (Smooth fade on drag)
            e("div", {
                className: "absolute inset-0 flex items-center justify-center pointer-events-none text-center pl-10 pr-3"
            },
                e("span", {
                    className: "font-heading font-black text-xs uppercase tracking-wider text-white text-center drop-shadow-md block",
                    style: {
                        opacity: Math.max(0.1, 1 - (dragX / 110)),
                        transition: isDragging ? 'none' : 'opacity 0.3s ease'
                    }
                }, isCompleted ? "🚨 SOS DISPATCHED!" : labelText)
            ),
            // Smooth Hardware-Accelerated Sliding thumb
            e("div", {
                onMouseDown: (e) => { e.stopPropagation(); handleStart(e.clientX); },
                onTouchStart: (e) => { e.stopPropagation(); if (e.touches && e.touches[0]) handleStart(e.touches[0].clientX); },
                className: "w-11 h-11 rounded-full bg-white text-slate-900 shadow-xl flex items-center justify-center font-black text-base cursor-grab active:cursor-grabbing z-10 select-none",
                style: {
                    transform: `translate3d(${dragX + 4}px, 0, 0)`,
                    boxShadow: '0 4px 18px rgba(0,0,0,0.45)',
                    transition: isDragging ? 'none' : 'transform 0.35s cubic-bezier(0.25, 1, 0.5, 1)',
                    willChange: 'transform'
                }
            },
                isCompleted ? "✓" : "➔"
            )
        );
    }

    // =========================================================================
    // SECTION: ULTRA-MODERN WORKING OPENSTREETMAP LEAFLET COMPONENT WITH REAL GPS
    // =========================================================================
    function WorkingSafetyMap({ touristLatLong, setTouristLatLong, isUsingRealGps, setIsUsingRealGps }) {
        const mapContainerRef = useRef(null);
        const mapInstanceRef = useRef(null);
        const markerRef = useRef(null);
        const circleRef = useRef(null);
        const [isFetchingGps, setIsFetchingGps] = useState(false);

        const fetchRealGps = () => {
            if (!("geolocation" in navigator)) {
                alert("⚠️ Geolocation is not supported by your browser/device.");
                return;
            }
            setIsFetchingGps(true);
            navigator.geolocation.getCurrentPosition(
                (pos) => {
                    const lat = pos.coords.latitude;
                    const lng = pos.coords.longitude;
                    if (setTouristLatLong) setTouristLatLong({ lat, lng });
                    if (setIsUsingRealGps) setIsUsingRealGps(true);
                    setIsFetchingGps(false);
                    if (mapInstanceRef.current) {
                        mapInstanceRef.current.setView([lat, lng], 16);
                    }
                },
                (err) => {
                    setIsFetchingGps(false);
                    console.warn("GPS Geolocation error:", err);
                    alert("📍 Please allow Location / GPS permission in your browser to show your real physical location.");
                },
                { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 }
            );
        };

        useEffect(() => {
            if (!mapContainerRef.current) return;

            function initMap() {
                if (mapInstanceRef.current || !mapContainerRef.current) return;
                const L = window.L;
                if (!L) return;

                const lat = touristLatLong.lat || 18.9242;
                const lng = touristLatLong.lng || 72.8310;

                const map = L.map(mapContainerRef.current, {
                    center: [lat, lng],
                    zoom: 15,
                    zoomControl: false,
                    attributionControl: false
                });

                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    maxZoom: 19
                }).addTo(map);

                const circle = L.circle([lat, lng], {
                    color: '#10b981',
                    fillColor: '#10b981',
                    fillOpacity: 0.14,
                    radius: 350,
                    weight: 2
                }).addTo(map);
                circleRef.current = circle;

                const userIcon = L.divIcon({
                    className: 'custom-user-pin',
                    html: '<div style="width:20px;height:20px;background:#2563eb;border:3px solid #ffffff;border-radius:50%;box-shadow:0 0 12px rgba(37,99,235,0.9);"></div>',
                    iconSize: [20, 20],
                    iconAnchor: [10, 10]
                });
                const marker = L.marker([lat, lng], { icon: userIcon }).addTo(map)
                    .bindPopup(`<b>📍 ${isUsingRealGps ? 'Your Real Physical Location' : 'Live Tourist Location'}</b><br>Lat: ${lat.toFixed(4)}°, Lng: ${lng.toFixed(4)}°`).openPopup();

                const policeIcon = L.divIcon({
                    className: 'custom-police-pin',
                    html: '<div style="background:#0b192c;color:#ffffff;border:2px solid #38bdf8;padding:2px 6px;border-radius:8px;font-size:10px;font-weight:800;white-space:nowrap;box-shadow:0 2px 6px rgba(0,0,0,0.3);">🚔 Police Post</div>',
                    iconSize: [75, 24],
                    iconAnchor: [37, 12]
                });
                L.marker([lat - 0.002, lng + 0.002], { icon: policeIcon }).addTo(map)
                    .bindPopup('<b>🚔 Tourism Police Assistance Unit</b><br>Active 24/7 (Tel: 112)');

                const hospitalIcon = L.divIcon({
                    className: 'custom-ems-pin',
                    html: '<div style="background:#dc2626;color:#ffffff;border:2px solid #ffffff;padding:2px 6px;border-radius:8px;font-size:10px;font-weight:800;white-space:nowrap;box-shadow:0 2px 6px rgba(0,0,0,0.3);">🏥 Trauma EMS</div>',
                    iconSize: [85, 24],
                    iconAnchor: [42, 12]
                });
                L.marker([lat + 0.003, lng + 0.001], { icon: hospitalIcon }).addTo(map)
                    .bindPopup('<b>🏥 Emergency Trauma Centre</b><br>Hospital Grid (400m)');

                mapInstanceRef.current = map;
                markerRef.current = marker;

                setTimeout(() => { map.invalidateSize(); }, 250);
            }

            if (!window.L) {
                const script = document.createElement('script');
                script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
                script.onload = initMap;
                document.head.appendChild(script);
            } else {
                initMap();
            }

            return () => {
                if (mapInstanceRef.current) {
                    mapInstanceRef.current.remove();
                    mapInstanceRef.current = null;
                }
            };
        }, []);

        useEffect(() => {
            if (mapInstanceRef.current && markerRef.current) {
                const lat = touristLatLong.lat || 18.9242;
                const lng = touristLatLong.lng || 72.8310;
                markerRef.current.setLatLng([lat, lng]);
                markerRef.current.setPopupContent(`<b>📍 ${isUsingRealGps ? 'Your Real Physical Location' : 'Live Tourist Location'}</b><br>Lat: ${lat.toFixed(4)}°, Lng: ${lng.toFixed(4)}°`);
                if (circleRef.current) circleRef.current.setLatLng([lat, lng]);
                mapInstanceRef.current.setView([lat, lng], 15);
            }
        }, [touristLatLong, isUsingRealGps]);

        const handleRecenter = () => {
            if (mapInstanceRef.current) {
                mapInstanceRef.current.setView([touristLatLong.lat || 18.9242, touristLatLong.lng || 72.8310], 16);
            }
        };

        return e("div", { className: "flex flex-col gap-3" },
            // Top Filter Pills (SafeZ Style Map Screen with Real GPS Button)
            e("div", { className: "flex items-center gap-2 overflow-x-auto no-scrollbar py-0.5" },
                e("button", {
                    onClick: fetchRealGps,
                    disabled: isFetchingGps,
                    className: `px-3.5 py-1.5 rounded-full ${isUsingRealGps ? 'bg-emerald-600' : 'bg-[#0f172a]'} text-white text-[11px] font-bold shadow-xs whitespace-nowrap active:scale-95 transition-all flex items-center gap-1.5 shrink-0`
                },
                    e("span", { className: `w-2 h-2 rounded-full ${isFetchingGps ? 'bg-amber-400 animate-ping' : 'bg-emerald-400 animate-pulse'}` }),
                    isFetchingGps ? "Acquiring GPS..." : (isUsingRealGps ? "📍 Real GPS Active" : "📍 Use My Real Location")
                ),
                e("button", { onClick: handleRecenter, className: "px-3.5 py-1.5 rounded-full bg-white border border-slate-200 text-slate-700 text-[11px] font-bold shadow-xs whitespace-nowrap active:scale-95 transition-all flex items-center gap-1.5 shrink-0 hover:bg-slate-50" },
                    "🎯 Recenter"
                ),
                e("button", { onClick: () => { if (mapInstanceRef.current) mapInstanceRef.current.setView([(touristLatLong.lat || 18.9242) - 0.002, (touristLatLong.lng || 72.8310) + 0.002], 16); }, className: "px-3.5 py-1.5 rounded-full bg-white border border-slate-200 text-slate-700 text-[11px] font-bold shadow-xs whitespace-nowrap active:scale-95 transition-all flex items-center gap-1.5 shrink-0 hover:bg-slate-50" },
                    "🚔 Police Booth"
                ),
                e("button", { onClick: () => { if (mapInstanceRef.current) mapInstanceRef.current.setView([(touristLatLong.lat || 18.9242) + 0.003, (touristLatLong.lng || 72.8310) + 0.001], 16); }, className: "px-3.5 py-1.5 rounded-full bg-white border border-slate-200 text-slate-700 text-[11px] font-bold shadow-xs whitespace-nowrap active:scale-95 transition-all flex items-center gap-1.5 shrink-0 hover:bg-slate-50" },
                    "🏥 Trauma EMS"
                )
            ),
            // Map Container
            e("div", { className: "relative rounded-3xl overflow-hidden border border-slate-200/90 shadow-sm" },
                e("div", {
                    ref: mapContainerRef,
                    style: { width: '100%', height: '260px', background: '#e2e8f0', zIndex: 1 }
                }),
                e("div", { className: "absolute top-3 left-3 z-10 bg-white/95 backdrop-blur-md px-3 py-1.5 rounded-full border border-slate-200 text-[10px] font-mono-data font-bold text-slate-800 shadow-sm flex items-center gap-1.5" },
                    e("span", { className: "w-2 h-2 rounded-full bg-emerald-500 animate-pulse" }),
                    isUsingRealGps ? "Live Physical GPS Corridor" : "Gateway Heritage Corridor"
                ),
                e("button", {
                    onClick: fetchRealGps,
                    title: "Fetch Real GPS Location",
                    className: "absolute top-3 right-3 z-10 bg-white/95 hover:bg-white backdrop-blur-md p-2 rounded-full border border-slate-200 text-xs font-bold text-slate-800 shadow-sm active:scale-95 transition-all flex items-center justify-center"
                }, isFetchingGps ? "⏳" : "📍"),
                e("div", { className: "absolute bottom-3 left-3 right-3 z-10 bg-white/95 backdrop-blur-md px-3 py-2 rounded-2xl border border-slate-200 flex items-center justify-between text-[11px] font-mono-data text-slate-700 shadow-sm" },
                    e("span", { className: "font-bold text-slate-900" }, `GPS: ${Number(touristLatLong.lat || 18.9242).toFixed(4)}° N, ${Number(touristLatLong.lng || 72.8310).toFixed(4)}° E`),
                    e("span", { className: `font-bold px-2.5 py-0.5 rounded-full border text-[10px] ${isUsingRealGps ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-blue-50 text-blue-700 border-blue-200'}` }, isUsingRealGps ? "Real GPS Active" : "Zone Secured")
                )
            ),
            // Bottom Responder Drawer Card (SafeZ Screen 2)
            e("div", { className: "bg-white rounded-2xl p-3.5 border border-slate-100 shadow-xs flex items-center justify-between" },
                e("div", { className: "flex items-center gap-3" },
                    e("div", { className: "w-10 h-10 rounded-full bg-blue-100 border border-blue-200 flex items-center justify-center text-lg shadow-xs" }, "👮"),
                    e("div", null,
                        e("h4", { className: "font-heading font-black text-xs text-slate-900 leading-tight" }, "Tourism Police & Emergency Unit"),
                        e("p", { className: "text-[10px] text-slate-500" }, isUsingRealGps ? "Linked to Local Emergency Grid • 24/7 Active" : "Colaba Post • 50m away • 24/7 Monitored")
                    )
                ),
                e("div", { className: "flex items-center gap-1.5" },
                    e("button", { onClick: () => { window.location.href = 'tel:112'; }, className: "w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs shadow-xs active:scale-95 transition-all" }, "📞"),
                    e("button", { onClick: fetchRealGps, title: "Locate Me", className: "w-8 h-8 rounded-full bg-slate-100 text-slate-700 flex items-center justify-center text-xs shadow-xs active:scale-95 transition-all" }, "📍")
                )
            )
        );
    }

    // =========================================================================
    // FULL TOURIST TRANSLATOR COMPONENT
    // =========================================================================
    function FullTouristTranslator({ geminiApiKey }) {
        const [sourceLang, setSourceLang] = useState("English");
        const [targetLang, setTargetLang] = useState("Hindi");
        const [inputText, setInputText] = useState("");
        const [translatedText, setTranslatedText] = useState("");
        const [phoneticText, setPhoneticText] = useState("");
        const [isTranslating, setIsTranslating] = useState(false);
        const [isListening, setIsListening] = useState(false);
        const [activeAudioIdx, setActiveAudioIdx] = useState(null);
        const [selectedCategory, setSelectedCategory] = useState("emergency");
        const [copied, setCopied] = useState(false);

        const playPhraseVoice = (text, lang, idx) => {
            setActiveAudioIdx(idx);
            speakText(text, lang, () => setActiveAudioIdx(null));
            setTimeout(() => setActiveAudioIdx(null), 3500);
        };

        const performTranslation = async (textToTranslate = inputText) => {
            const query = textToTranslate.trim();
            if (!query) return;

            setIsTranslating(true);

            if (geminiApiKey && geminiApiKey.trim().length > 10) {
                try {
                    const targetDescriptor = targetLang === "Marathi" 
                        ? "natural, conversational, everyday spoken Marathi as spoken in Mumbai/Maharashtra that local taxi drivers, shopkeepers, and people understand"
                        : "natural, conversational, everyday spoken Indian Hindi (Colloquial Hindustani) that common auto drivers, street vendors, and locals easily understand";

                    const prompt = `You are a real-time tourist translator in Maharashtra, India.
Translate the following text into ${targetDescriptor}.
DO NOT use archaic, textbook Sanskritized words.

Return strictly JSON in this schema:
{"translated": "natural spoken target language text", "phonetic": "pronunciation in Latin letters for English speaker to say out loud"}

Text to translate: "${query}"`;

                    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${geminiApiKey.trim()}`, {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({
                            contents: [{ role: "user", parts: [{ text: prompt }] }]
                        })
                    });
                    const data = await response.json();
                    const raw = data.candidates[0].content.parts[0].text;
                    const cleanJson = raw.replace(/\`\`\`json/g, '').replace(/\`\`\`/g, '').trim();
                    const parsed = JSON.parse(cleanJson);
                    if (parsed.translated) {
                        setTranslatedText(makeNaturalHindustani(parsed.translated, targetLang));
                        setPhoneticText(parsed.phonetic || "");
                        setIsTranslating(false);
                        return;
                    }
                } catch (e) {
                    console.warn("Gemini translate error:", e);
                }
            }

            try {
                const sCode = langCodeMap[sourceLang] || "en";
                const tCode = langCodeMap[targetLang] || (targetLang === "Marathi" ? "mr" : "hi");
                const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(query)}&langpair=${sCode}|${tCode}`;
                
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 2500);
                const res = await fetch(url, { signal: controller.signal });
                clearTimeout(timeoutId);
                
                const data = await res.json();
                if (data && data.responseData && data.responseData.translatedText) {
                    let apiResult = makeNaturalHindustani(data.responseData.translatedText.trim(), targetLang);
                    if (sCode !== tCode && apiResult.toLowerCase() !== query.toLowerCase() && !apiResult.includes("MYMEMORY WARNING")) {
                        setTranslatedText(apiResult);
                        const localRule = translateViaLocalEngine(query, targetLang);
                        setPhoneticText(localRule.phonetic || `"${apiResult}"`);
                        setIsTranslating(false);
                        return;
                    }
                }
            } catch (err) {
                console.warn("Web API error:", err);
            }

            const localResult = translateViaLocalEngine(query, targetLang);
            setTranslatedText(localResult.translated);
            setPhoneticText(localResult.phonetic);
            setIsTranslating(false);
        };

        const startVoiceInput = () => {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            if (!SpeechRecognition) {
                alert("Voice input is not supported in this browser.");
                return;
            }
            const rec = new SpeechRecognition();
            rec.lang = sourceLang === "Hindi" ? "hi-IN" : sourceLang === "Spanish" ? "es-ES" : sourceLang === "French" ? "fr-FR" : "en-US";
            setIsListening(true);
            rec.start();
            rec.onresult = (e) => {
                const text = e.results[0][0].transcript;
                setInputText(text);
                setIsListening(false);
                performTranslation(text);
            };
            rec.onerror = () => setIsListening(false);
            rec.onend = () => setIsListening(false);
        };

        const speakTranslated = () => {
            if (!translatedText) return;
            const lang = targetLang === "Hindi" ? "hi-IN" : targetLang === "Marathi" ? "mr-IN" : "en-US";
            playPhraseVoice(translatedText, lang, "custom-result");
        };

        const swapLanguages = () => {
            const temp = sourceLang;
            setSourceLang(targetLang === "Marathi" ? "Hindi" : targetLang);
            setTargetLang(temp === "English" ? "Hindi" : temp);
            setInputText(translatedText);
            setTranslatedText(inputText);
        };

        const selectPhrase = (p) => {
            setInputText(p.en);
            if (targetLang === "Marathi") {
                setTranslatedText(p.mr || p.hi);
                setPhoneticText(p.pronMr || p.pronHi);
            } else {
                setTranslatedText(p.hi);
                setPhoneticText(p.pronHi);
            }
            const txtToSpeak = targetLang === "Marathi" ? (p.mr || p.hi) : p.hi;
            playPhraseVoice(txtToSpeak, targetLang === "Marathi" ? "mr-IN" : "hi-IN", "phrase-tap");
        };

        const copyToClipboard = () => {
            if (!translatedText) return;
            navigator.clipboard.writeText(translatedText);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        };

        return e("div", { className: "flex flex-col gap-4" },
            // UNIFIED SINGLE BOX TRANSLATOR (All controls & outputs inside 1 modern card)
            e("div", { className: "card-modern p-5 flex flex-col gap-4 relative overflow-hidden" },
                // 1. Language Selector Row
                e("div", { className: "flex items-center justify-between gap-2 bg-slate-50 p-2.5 rounded-2xl border border-slate-200/80" },
                    e("div", { className: "flex-1" },
                        e("span", { className: "text-[9px] text-slate-400 block mb-0.5 font-extrabold uppercase tracking-wider font-mono-data px-1" }, "From"),
                        e("select", {
                            value: sourceLang,
                            onChange: (e) => setSourceLang(e.target.value),
                            className: "w-full bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-900 font-bold focus:outline-none cursor-pointer shadow-xs"
                        },
                            e("option", { value: "English" }, "English (EN)"),
                            e("option", { value: "Spanish" }, "Spanish (ES)"),
                            e("option", { value: "French" }, "French (FR)"),
                            e("option", { value: "German" }, "German (DE)"),
                            e("option", { value: "Japanese" }, "Japanese (JA)"),
                            e("option", { value: "Russian" }, "Russian (RU)"),
                            e("option", { value: "Arabic" }, "Arabic (AR)"),
                            e("option", { value: "Hindi" }, "Hindi (HI)")
                        )
                    ),
                    e("button", {
                        onClick: swapLanguages,
                        title: "Swap Languages",
                        className: "w-9 h-9 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 flex items-center justify-center font-bold text-sm shadow-xs transition-all active:scale-95 shrink-0 mt-3.5"
                    }, "⇄"),
                    e("div", { className: "flex-1" },
                        e("span", { className: "text-[9px] text-rose-600 block mb-0.5 font-extrabold uppercase tracking-wider font-mono-data px-1" }, "To (Local Spoken)"),
                        e("select", {
                            value: targetLang,
                            onChange: (e) => setTargetLang(e.target.value),
                            className: "w-full bg-white border border-rose-200 rounded-xl px-2.5 py-1.5 text-xs text-rose-700 font-bold focus:outline-none cursor-pointer shadow-xs"
                        },
                            e("option", { value: "Hindi" }, "Hindi (हिंदी - Mumbai)"),
                            e("option", { value: "Marathi" }, "Marathi (मराठी - Maharashtra)"),
                            e("option", { value: "English" }, "English (EN)"),
                            e("option", { value: "Gujarati" }, "Gujarati (ગુજરાતી)"),
                            e("option", { value: "Tamil" }, "Tamil (தமிழ்)"),
                            e("option", { value: "Bengali" }, "Bengali (বাংলা)")
                        )
                    )
                ),

                // 2. Tourist Input Area (Typing & Voice Mic)
                e("div", { className: "flex flex-col gap-2 pt-1" },
                    e("div", { className: "flex items-center justify-between text-xs font-bold" },
                        e("span", { className: "uppercase text-[10px] font-extrabold text-slate-400 tracking-wider font-mono-data" }, `Input (${sourceLang})`),
                        e("div", { className: "flex items-center gap-2" },
                            e("button", {
                                type: "button",
                                onClick: startVoiceInput,
                                title: "Speak via Microphone",
                                className: `p-1.5 px-3 rounded-full border transition-all flex items-center gap-1 text-xs font-bold ${
                                    isListening 
                                        ? 'text-rose-700 bg-rose-50 border-rose-400 animate-pulse' 
                                        : 'text-slate-700 bg-slate-50 border-slate-200 hover:bg-slate-100'
                                }`
                            },
                                e("span", null, "🎤"),
                                e("span", { className: "text-[10px] font-mono-data font-bold" }, isListening ? "Listening..." : "Voice")
                            ),
                            inputText && e("button", {
                                onClick: () => { setInputText(""); setTranslatedText(""); setPhoneticText(""); },
                                className: "text-slate-400 hover:text-slate-700 text-xs w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center"
                            }, "✕")
                        )
                    ),
                    e("textarea", {
                        rows: "2",
                        value: inputText,
                        onChange: (e) => {
                            setInputText(e.target.value);
                            if (e.target.value.trim().length > 3) performTranslation(e.target.value);
                        },
                        placeholder: "Type or speak in English (e.g. 'Take me to Gateway of India', 'How much for this?')...",
                        className: "w-full bg-transparent text-sm font-bold text-slate-900 placeholder-slate-400 focus:outline-none resize-none leading-relaxed py-1"
                    }),
                    e("div", { className: "flex justify-end" },
                        e("button", {
                            onClick: () => performTranslation(),
                            disabled: !inputText.trim() || isTranslating,
                            className: "bg-[#0f172a] hover:bg-slate-800 disabled:opacity-40 text-white px-5 py-2.5 rounded-full text-xs font-black font-heading transition-all active:scale-95 shadow-md flex items-center gap-1.5"
                        }, isTranslating ? "Translating..." : "Translate ➔")
                    )
                ),

                // 3. Spoken Output Area (Seamlessly integrated with divider inside the same box)
                e("div", { className: "border-t border-slate-100 pt-3 flex flex-col gap-2.5" },
                    e("div", { className: "flex items-center justify-between text-xs" },
                        e("div", { className: "flex items-center gap-1.5" },
                            e("span", { className: "w-2 h-2 rounded-full bg-emerald-500 animate-pulse" }),
                            e("span", { className: "uppercase text-[10px] font-extrabold text-slate-400 tracking-wider font-mono-data" }, `Spoken Translation (${targetLang})`)
                        ),
                        e("div", { className: "flex items-center gap-2" },
                            e("button", {
                                onClick: speakTranslated,
                                disabled: !translatedText,
                                title: "Play Speech Audio",
                                className: `px-3.5 py-1.5 rounded-full text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs ${
                                    activeAudioIdx === 'custom-result'
                                        ? 'bg-rose-500 text-white font-black animate-pulse'
                                        : 'bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 disabled:opacity-30'
                                }`
                            }, activeAudioIdx === 'custom-result' ? "🔊 Playing..." : "🔊 Play Audio"),
                            e("button", {
                                onClick: copyToClipboard,
                                disabled: !translatedText,
                                title: "Copy Text",
                                className: "text-xs text-slate-600 hover:text-slate-900 transition-colors disabled:opacity-30 bg-slate-50 hover:bg-slate-100 border border-slate-200 px-3 py-1.5 rounded-full font-bold shadow-xs"
                            }, copied ? "✓ Copied" : "Copy")
                        )
                    ),
                    e("p", { className: "text-base sm:text-lg font-black text-slate-900 min-h-[32px] leading-relaxed" },
                        translatedText || e("span", { className: "text-slate-400 font-normal text-xs italic" }, "Translation and voice pronunciation will appear here...")
                    ),
                    phoneticText && e("div", { className: "bg-amber-50/80 border border-amber-200/80 rounded-2xl p-3 mt-0.5 flex flex-col gap-0.5" },
                        e("span", { className: "text-[10px] text-amber-800 uppercase font-mono-data font-extrabold block" }, "How to Say Out Loud:"),
                        e("p", { className: "text-xs sm:text-sm text-amber-900 font-bold italic" }, `"${phoneticText}"`)
                    )
                )
            ),
            e("div", { className: "bg-white rounded-3xl border border-slate-200 p-5 shadow-sm flex flex-col gap-3.5" },
                e("div", { className: "flex items-center justify-between" },
                    e("div", null,
                        e("span", { className: "text-xs font-black uppercase tracking-wider text-slate-900 font-heading block" }, "One-Tap Tourist Phrasebook"),
                        e("span", { className: "text-[11px] text-slate-500" }, "Instant spoken audio & pronunciation guide")
                    ),
                    e("span", { className: "text-[10px] text-emerald-700 font-mono-data font-bold bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full" },
                        "Instant Audio Tap"
                    )
                ),
                e("div", { className: "grid grid-cols-4 bg-slate-100 p-1.5 rounded-2xl border border-slate-200 text-xs font-bold text-center gap-1" },
                    e("button", {
                        onClick: () => setSelectedCategory("emergency"),
                        className: `py-2 rounded-xl transition-all ${selectedCategory === "emergency" ? "bg-red-600 text-white font-black shadow-md" : "text-slate-600 hover:text-slate-900"}`
                    }, "🚨 SOS"),
                    e("button", {
                        onClick: () => setSelectedCategory("transport"),
                        className: `py-2 rounded-xl transition-all ${selectedCategory === "transport" ? "bg-blue-600 text-white font-black shadow-md" : "text-slate-600 hover:text-slate-900"}`
                    }, "🚕 Transit"),
                    e("button", {
                        onClick: () => setSelectedCategory("food"),
                        className: `py-2 rounded-xl transition-all ${selectedCategory === "food" ? "bg-blue-600 text-white font-black shadow-md" : "text-slate-600 hover:text-slate-900"}`
                    }, "🍲 Food"),
                    e("button", {
                        onClick: () => setSelectedCategory("shopping"),
                        className: `py-2 rounded-xl transition-all ${selectedCategory === "shopping" ? "bg-blue-600 text-white font-black shadow-md" : "text-slate-600 hover:text-slate-900"}`
                    }, "🛍️ Shop")
                ),
                e("div", { className: "flex flex-col gap-3 max-h-80 overflow-y-auto pr-1" },
                    (phrasebook[selectedCategory] || []).map((phrase, idx) => {
                        const isPlaying = activeAudioIdx === idx;
                        return e("div", {
                            key: idx,
                            onClick: () => selectPhrase(phrase),
                            className: "bg-slate-900 hover:bg-slate-800 border border-slate-700/80 p-4 rounded-2xl cursor-pointer transition-all flex flex-col gap-2 text-white shadow-md"
                        },
                            e("div", { className: "flex justify-between items-start gap-2" },
                                e("p", { className: "text-xs sm:text-sm font-extrabold text-white leading-snug" }, phrase.en),
                                e("button", {
                                    onClick: (ev) => {
                                        ev.stopPropagation();
                                        const txtToSpeak = targetLang === "Marathi" ? (phrase.mr || phrase.hi) : phrase.hi;
                                        playPhraseVoice(txtToSpeak, targetLang === "Marathi" ? "mr-IN" : "hi-IN", idx);
                                    },
                                    className: `px-2.5 py-1 rounded-xl text-xs font-bold shrink-0 transition-all flex items-center gap-1 shadow ${
                                        isPlaying ? 'bg-emerald-400 text-slate-950 font-black' : 'bg-slate-800 text-emerald-300 border border-slate-700 hover:bg-slate-700'
                                    }`
                                }, isPlaying ? "🔊 Playing..." : "🔊 Play")
                            ),
                            e("div", { className: "flex items-center gap-2" },
                                e("span", { className: "text-[10px] text-slate-400 font-mono-data uppercase font-bold" }, "Local:"),
                                e("p", { className: "text-xs sm:text-sm font-black text-emerald-300" },
                                    targetLang === "Marathi" ? (phrase.mr || phrase.hi) : phrase.hi
                                )
                            ),
                            e("div", { className: "bg-slate-950 rounded-xl px-3 py-1.5 flex items-center gap-2 border border-slate-800 text-xs" },
                                e("span", { className: "text-[10px] text-amber-300 font-mono-data font-bold uppercase" }, "Say:"),
                                e("p", { className: "text-xs text-amber-100 font-bold italic" },
                                    `"${targetLang === "Marathi" ? (phrase.pronMr || phrase.pronHi) : phrase.pronHi}"`
                                )
                            )
                        );
                    })
                )
            )
        );
    }

    // =========================================================================
    // REFERENCE-MATCHING LOST & FOUND COMPONENT
    // =========================================================================
    function ReferenceLostSection({ profile, lostReports, setLostReports, myLocalLostIds, setMyLocalLostIds, handleLostFoundSubmit, handleDismissMyReport, handleClearAllMyReports, isFilingModalOpen: externalIsFilingModalOpen, setIsFilingModalOpen: externalSetIsFilingModalOpen, selectedLang = "English" }) {
        const t = UI_I18N[selectedLang] || UI_I18N["English"];
        const [activeSubTab, setActiveSubTab] = useState("reportLost");
        const [internalIsFilingModalOpen, internalSetIsFilingModalOpen] = useState(false);
        const isFilingModalOpen = externalIsFilingModalOpen !== undefined ? externalIsFilingModalOpen : internalIsFilingModalOpen;
        const setIsFilingModalOpen = externalSetIsFilingModalOpen || internalSetIsFilingModalOpen;
        const [modalCategory, setModalCategory] = useState("Passport");
        const [otherCategoryText, setOtherCategoryText] = useState("");

        // STRICT DEVICE/USER CLAIM ISOLATION: A tourist ONLY sees what THEY personally logged
        const filteredList = useMemo(() => {
            const all = lostReports || [];
            const myIds = Array.isArray(myLocalLostIds) ? myLocalLostIds : [];
            
            // Only reports submitted from THIS device (present in myLocalLostIds)
            const myReports = all.filter(r => r && r.id && myIds.includes(r.id));

            if (activeSubTab === "reportLost") {
                return myReports.map(r => {
                    const isFound = r.status === "Resolved" || r.status === "Found" || r.status === "Item Located" || r.status === "Resolved & Returned";
                    return {
                        id: r.id,
                        item: r.item,
                        location: r.location || "Gateway Promenade",
                        timestamp: r.timestamp || "Just now",
                        status: isFound ? "Found" : "Searching",
                        color: isFound ? "green" : "orange",
                        isUserClaim: true
                    };
                });
            } else {
                // In Found Items, show user's own items that have been located/resolved
                return myReports.filter(r => {
                    return r.status === "Resolved" || r.status === "Found" || r.status === "Item Located" || r.status === "Resolved & Returned";
                }).map(r => ({
                    id: r.id,
                    item: r.item,
                    location: r.location || "Tourism Police Helpdesk",
                    timestamp: r.timestamp || "Today",
                    status: "Found",
                    color: "green",
                    isUserClaim: true
                }));
            }
        }, [lostReports, activeSubTab, myLocalLostIds]);

        return e("div", { className: "flex flex-col gap-4" },
            e("div", { className: "flex items-center justify-between pt-1 pb-1" },
                e("h2", { className: "font-heading font-extrabold text-lg sm:text-xl text-slate-900 tracking-tight" }, t.lostTitle),
                e("span", { className: "text-[11px] font-mono-data font-bold text-slate-400 bg-slate-100 px-3 py-1 rounded-full uppercase tracking-wider" }, t.securedBadge)
            ),
            e("div", { className: "bg-white p-1.5 rounded-2xl border border-slate-200 shadow-xs grid grid-cols-2 gap-1.5 text-center font-heading text-xs font-bold" },
                e("button", {
                    onClick: () => setActiveSubTab("reportLost"),
                    className: `py-2.5 rounded-xl transition-all ${activeSubTab === 'reportLost' ? 'bg-[#0b192c] text-white font-extrabold shadow-sm' : 'text-slate-600 hover:text-slate-900'}`
                }, t.reportLostTab),
                e("button", {
                    onClick: () => setActiveSubTab("foundItems"),
                    className: `py-2.5 rounded-xl transition-all ${activeSubTab === 'foundItems' ? 'bg-[#0b192c] text-white font-extrabold shadow-sm' : 'text-slate-600 hover:text-slate-900'}`
                }, t.foundItemsTab)
            ),
            e("div", { className: "flex items-center justify-between px-1 mt-1" },
                e("span", { className: "text-[11px] font-extrabold uppercase tracking-wider text-slate-400 font-mono-data" },
                    activeSubTab === "reportLost" ? t.recentLostReports : t.verifiedFoundItems
                ),
                lostReports.length > 0 && e("button", {
                    onClick: handleClearAllMyReports,
                    className: "text-[10px] font-bold text-slate-400 hover:text-red-600 transition-colors"
                }, t.clearMyReports)
            ),
            e("div", { className: "flex flex-col gap-3" },
                filteredList.length === 0 ? e("div", { className: "bg-white rounded-3xl p-8 border border-slate-200 text-center text-slate-500 text-xs flex flex-col items-center gap-2 shadow-xs" },
                    e("span", { className: "text-2xl" }, "📦"),
                    e("p", { className: "font-bold text-slate-800" }, selectedLang === "Hindi" ? "अभी तक कोई रिपोर्ट दर्ज नहीं है।" : selectedLang === "Marathi" ? "अद्याप कोणतीही नोंद नाही." : "No reports in this category yet."),
                    e("p", { className: "text-[11px] text-slate-400" }, selectedLang === "Hindi" ? "नई रिपोर्ट दर्ज करने के लिए नीचे बटन दबाएं।" : selectedLang === "Marathi" ? "नवीन नोंदणी करण्यासाठी खालील बटण दाबा." : "Tap '+ REPORT LOST ITEM' below to log a new missing property claim.")
                ) :
                filteredList.map((item, idx) => {
                    const isGreen = item.status === "Found" || item.color === "green";
                    return e("div", {
                        key: idx,
                        className: "bg-white rounded-2xl border border-slate-200/90 p-4 shadow-xs flex items-center justify-between relative overflow-hidden hover:shadow-md transition-shadow"
                    },
                        e("div", {
                            className: `absolute left-0 top-0 bottom-0 w-1.5 ${isGreen ? 'bg-emerald-500' : 'bg-amber-500'}`
                        }),
                        e("div", { className: "pl-2 flex flex-col gap-0.5" },
                            e("h3", { className: "font-heading font-black text-sm sm:text-base text-slate-900 leading-tight" }, item.item),
                            e("p", { className: "text-xs text-slate-500 font-medium mt-0.5" },
                                "Last seen: ",
                                e("span", { className: "text-slate-700 font-semibold" }, item.location)
                            ),
                            e("span", { className: "text-[10px] text-slate-400 font-mono-data mt-0.5" }, item.timestamp)
                        ),
                        e("div", { className: "flex items-center gap-2" },
                            e("span", {
                                className: `px-3 py-1 rounded-xl text-xs font-black tracking-wide font-heading ${
                                    isGreen 
                                        ? 'bg-emerald-50 text-emerald-600 border border-emerald-200/80' 
                                        : 'bg-amber-50 text-amber-600 border border-amber-200/80'
                                }`
                            }, item.status),
                            item.isUserClaim && e("button", {
                                onClick: () => handleDismissMyReport(item.id),
                                title: "Remove report",
                                className: "text-slate-300 hover:text-red-500 text-xs p-1"
                            }, "✕")
                        )
                    );
                })
            ),
            e("button", {
                onClick: () => setIsFilingModalOpen(true),
                className: "w-full py-4 rounded-2xl bg-[#0b192c] hover:bg-slate-800 text-white font-heading font-black text-xs sm:text-sm tracking-wider uppercase shadow-xl flex items-center justify-center gap-2 active:scale-98 transition-all mt-2"
            },
                e("span", { className: "text-base font-bold" }, "+"),
                e("span", null, t.reportLostButton)
            ),
            isFilingModalOpen && e("div", { className: "fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4" },
                e("div", { className: "bg-white border border-slate-200 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl max-h-[90vh] flex flex-col" },
                    e("div", { className: "bg-[#0b192c] p-5 flex justify-between items-center text-white" },
                        e("div", null,
                            e("h3", { className: "font-heading font-black text-base sm:text-lg text-white" }, t.fileClaim),
                            e("p", { className: "text-xs text-slate-300 font-medium" }, t.fileClaimSub)
                        ),
                        e("button", {
                            onClick: () => setIsFilingModalOpen(false),
                            className: "w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center text-sm font-bold"
                        }, "✕")
                    ),
                    e("form", {
                        onSubmit: (e) => {
                            handleLostFoundSubmit(e, modalCategory, otherCategoryText);
                            setIsFilingModalOpen(false);
                            setOtherCategoryText("");
                        },
                        className: "p-5 sm:p-6 overflow-y-auto flex flex-col gap-3.5 text-xs sm:text-sm"
                    },
                        e("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3" },
                            e("div", null,
                                e("label", { className: "text-xs text-slate-800 font-extrabold block mb-1 uppercase tracking-wider" }, t.itemCategory),
                                e("select", {
                                    name: "category",
                                    value: modalCategory,
                                    onChange: (e) => setModalCategory(e.target.value),
                                    className: "w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs sm:text-sm text-slate-900 font-bold focus:outline-none focus:border-blue-500 cursor-pointer shadow-xs"
                                },
                                    e("option", { value: "Passport" }, "🛂 Passport / Official ID"),
                                    e("option", { value: "Wallet" }, "👛 Wallet / Cash / Cards"),
                                    e("option", { value: "Bag" }, "🎒 Backpack / Luggage"),
                                    e("option", { value: "Phone / Electronics" }, "📱 Phone / Camera / Laptop"),
                                    e("option", { value: "Jewelry / Watch" }, "⌚ Jewelry / Watch"),
                                    e("option", { value: "Other" }, "📦 Other (Custom Specification)")
                                )
                            ),
                            modalCategory === "Other" ? e("div", null,
                                e("label", { className: "text-xs text-blue-700 font-extrabold block mb-1 uppercase tracking-wider" }, 'Specify "Other" Category *'),
                                e("input", {
                                    required: true,
                                    name: "otherSpecification",
                                    type: "text",
                                    value: otherCategoryText,
                                    onChange: (e) => setOtherCategoryText(e.target.value),
                                    placeholder: "e.g. Prescription Glasses, Drone...",
                                    className: "w-full bg-slate-50 border border-blue-300 rounded-xl p-3 text-xs sm:text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-500 shadow-xs font-bold"
                                })
                            ) : e("div", null,
                                e("label", { className: "text-xs text-slate-800 font-extrabold block mb-1 uppercase tracking-wider" }, t.itemName),
                                e("input", {
                                    required: true,
                                    name: "item",
                                    type: "text",
                                    placeholder: "e.g. Blue Backpack, Camera",
                                    className: "w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs sm:text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-500 shadow-xs font-bold"
                                })
                            )
                        ),
                        e("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3" },
                            e("div", null,
                                e("label", { className: "text-xs text-slate-800 font-extrabold block mb-1 uppercase tracking-wider" }, t.lastSeenLocation),
                                e("input", {
                                    required: true,
                                    name: "location",
                                    type: "text",
                                    placeholder: "e.g. Churchgate Station, Marine Drive",
                                    className: "w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs sm:text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-500 shadow-xs font-bold"
                                })
                            ),
                            e("div", null,
                                e("label", { className: "text-xs text-slate-800 font-extrabold block mb-1 uppercase tracking-wider" }, t.contactReturn),
                                e("input", {
                                    required: true,
                                    name: "contactInfo",
                                    type: "text",
                                    defaultValue: profile.contact,
                                    placeholder: "Phone or Hotel Room #",
                                    className: "w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs sm:text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-500 shadow-xs font-mono-data font-bold"
                                })
                            )
                        ),
                        e("div", { className: "flex gap-2.5 justify-end mt-3 pt-3 border-t border-slate-200" },
                            e("button", {
                                type: "button",
                                onClick: () => setIsFilingModalOpen(false),
                                className: "bg-slate-200 text-slate-800 px-4 py-2.5 rounded-xl font-bold"
                            }, t.cancel),
                            e("button", {
                                type: "submit",
                                className: "bg-[#0b192c] hover:bg-slate-800 text-white px-6 py-2.5 rounded-xl font-black shadow-md uppercase tracking-wider"
                            }, t.submitClaim)
                        )
                    )
                )
            )
        );
    }

    // =========================================================================
    // REFERENCE-MATCHING PROFILE COMPONENT
    // =========================================================================
    function ReferenceProfileSection({ profile, setProfile, isEditingProfile, setIsEditingProfile, livePlaceName = "Local Stay Accommodation", selectedLang = "English" }) {
        const t = UI_I18N[selectedLang] || UI_I18N["English"];
        const [showQrModal, setShowQrModal] = useState(false);

        const initials = useMemo(() => {
            if (!profile.name || !profile.name.trim()) return "ID";
            return profile.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();
        }, [profile.name]);

        return e("div", { className: "flex flex-col gap-4" },
            e("div", { className: "flex items-center justify-between pt-1 pb-1" },
                e("h2", { className: "font-heading font-extrabold text-lg sm:text-xl text-slate-900 tracking-tight" }, t.identityPass),
                e("button", {
                    onClick: () => setIsEditingProfile(true),
                    className: "flex items-center gap-1.5 bg-blue-50 hover:bg-blue-100 text-blue-600 px-3.5 py-1.5 rounded-2xl text-xs font-heading font-black tracking-wide shadow-xs active:scale-95 transition-all"
                },
                    e("span", null, "✏️"),
                    e("span", null, t.editPass)
                )
            ),
            // Unified Name & Accommodation Pass Card (One Single Box - Clickable to Edit)
            e("div", { 
                className: "card-modern p-5 flex flex-col gap-4 shadow-xs relative group cursor-pointer hover:border-blue-300 transition-all",
                onClick: () => setIsEditingProfile(true),
                title: "Click anywhere to edit details"
            },
                // Top: Tourist Name & Verification
                e("div", { className: "flex items-center justify-between" },
                    e("div", { className: "flex items-center gap-3.5" },
                        e("div", {
                            className: "w-14 h-14 rounded-full bg-[#0f172a] text-white flex items-center justify-center font-heading font-black text-lg shadow-md shrink-0 aspect-square",
                            style: { width: '56px', height: '56px', minWidth: '56px', minHeight: '56px', borderRadius: '9999px', flexShrink: 0, aspectRatio: '1/1' }
                        },
                            initials
                        ),
                        e("div", { className: "flex flex-col" },
                            e("div", { className: "flex items-center gap-2" },
                                e("span", { className: "text-[10px] text-slate-400 font-extrabold uppercase font-mono-data tracking-wider" }, t.touristFullName),
                                e("span", { className: "text-[10px] text-blue-500 font-bold" }, "✎ Edit")
                            ),
                            e("h3", { className: "font-heading font-black text-base sm:text-lg text-slate-900 leading-tight mt-0.5" }, profile.name || "Tourist Name"),
                            e("span", { className: "text-xs text-slate-500 font-medium flex items-center gap-1 mt-0.5" },
                                e("span", null, "📍"),
                                e("span", null, `${profile.nationality || 'India'} • ${profile.gender || 'Male'}`)
                            )
                        )
                    ),
                    e("div", { className: "w-8 h-8 rounded-full border border-emerald-300 bg-emerald-50 flex items-center justify-center text-emerald-600 font-black text-sm shadow-xs shrink-0" },
                        "✓"
                    )
                ),

                // Divider & Accommodation Details inside the same box
                e("div", { className: "border-t border-slate-100 pt-3 flex flex-col gap-2" },
                    e("div", { className: "flex items-center justify-between" },
                        e("div", { className: "flex items-center gap-1.5 text-slate-600 text-xs font-bold" },
                            e("span", null, "🏠"),
                            e("span", { className: "text-[10px] text-slate-400 uppercase font-extrabold tracking-wider font-mono-data" }, t.currentStaying)
                        ),
                        e("span", { className: `text-[10px] font-mono-data font-black px-2.5 py-0.5 rounded-full uppercase ${profile.roomNumber ? 'text-amber-700 bg-amber-100/80' : 'text-slate-500 bg-slate-100'}` },
                            profile.roomNumber ? (profile.roomNumber.toUpperCase().startsWith("ROOM") ? profile.roomNumber.toUpperCase() : `ROOM ${profile.roomNumber}`) : "Room No. Not Set"
                        )
                    ),
                    e("h4", { className: "font-heading font-black text-sm sm:text-base text-slate-900 leading-snug" },
                        profile.hotel || "Hotel Name"
                    ),
                    e("p", { className: `text-xs leading-relaxed font-medium ${profile.hotelAddress ? 'text-slate-600' : 'text-slate-400 italic'}` },
                        profile.hotelAddress || "Hotel Address"
                    ),
                    e("div", { className: "border-t border-slate-100/80 pt-2 flex items-center justify-between text-xs" },
                        e("div", { className: "flex items-center gap-1.5 text-emerald-600 font-bold text-xs" },
                            e("span", { className: "w-2 h-2 rounded-full bg-emerald-500 animate-pulse" }),
                            e("span", null, t.activeReservation)
                        ),
                        e("span", { className: "text-slate-400 text-[11px] font-medium" }, t.checkout)
                    )
                )
            ),
            e("div", { className: "grid grid-cols-2 gap-3" },
                e("div", { 
                    className: "bg-white rounded-2xl p-4 border border-slate-200/90 shadow-xs flex flex-col gap-1 cursor-pointer hover:border-blue-300 transition-all",
                    onClick: () => setIsEditingProfile(true)
                },
                    e("span", { className: "text-[10px] text-slate-400 font-extrabold uppercase tracking-wider font-mono-data" }, t.passportId),
                    e("p", { className: "font-heading font-black text-slate-900 text-sm sm:text-base tracking-wide" },
                        profile.passportNumber || "IN84712093"
                    )
                ),
                e("div", { 
                    className: "bg-white rounded-2xl p-4 border border-slate-200/90 shadow-xs flex flex-col gap-1 cursor-pointer hover:border-blue-300 transition-all",
                    onClick: () => setIsEditingProfile(true)
                },
                    e("span", { className: "text-[10px] text-slate-400 font-extrabold uppercase tracking-wider font-mono-data" }, t.emergencyPhone),
                    e("p", { className: "font-heading font-black text-slate-900 text-sm sm:text-base tracking-wide font-mono-data" },
                        profile.contact || "+91 9820 112233"
                    )
                ),
                e("div", { 
                    className: "bg-white rounded-2xl p-4 border border-slate-200/90 shadow-xs flex flex-col gap-1 cursor-pointer hover:border-blue-300 transition-all",
                    onClick: () => setIsEditingProfile(true)
                },
                    e("span", { className: "text-[10px] text-slate-400 font-extrabold uppercase tracking-wider font-mono-data" }, t.bloodGroup),
                    e("p", { className: "font-heading font-black text-rose-600 text-sm sm:text-base" },
                        profile.bloodGroup || "O+ Positive"
                    )
                ),
                e("div", { className: "bg-white rounded-2xl p-4 border border-slate-200/90 shadow-xs flex flex-col gap-1" },
                    e("span", { className: "text-[10px] text-slate-400 font-extrabold uppercase tracking-wider font-mono-data" }, t.tourismHelpdesk),
                    e("p", { className: "font-heading font-black text-blue-600 text-xs sm:text-sm leading-tight mt-0.5" },
                        "1363 (24/7 Toll-Free)"
                    )
                )
            ),
            // SafeZ Screen 3: My Emergency Contacts List
            e("div", { className: "flex flex-col gap-2.5 mt-1" },
                e("div", { className: "flex items-center justify-between px-1" },
                    e("h4", { className: "font-heading font-black text-sm text-slate-900" }, "My Emergency Contacts"),
                    e("span", { className: "text-[11px] font-bold text-slate-400" }, "Linked to SOS")
                ),
                [
                    { name: "Police Emergency Desk", phone: "112 (National Helpline)", icon: "👮", color: "bg-blue-100 text-blue-700", call: "112" },
                    { name: "Medical Trauma Ambulance", phone: "108 (EMS Dispatch)", icon: "🚑", color: "bg-rose-100 text-rose-700", call: "108" },
                    { name: "Tourism Police Helpdesk", phone: "1363 (Toll-Free)", icon: "🛡️", color: "bg-emerald-100 text-emerald-700", call: "1363" },
                    { name: profile.emergencyContactName || "Family / Buddy Contact", phone: profile.contact || "+91 9820 112233", icon: "👤", color: "bg-amber-100 text-amber-700", call: profile.contact }
                ].map((ct, ctIdx) =>
                    e("div", { key: ctIdx, className: "bg-white rounded-2xl p-3.5 border border-slate-100 shadow-xs flex items-center justify-between" },
                        e("div", { className: "flex items-center gap-3" },
                            e("div", { className: `w-10 h-10 rounded-full flex items-center justify-center text-base shadow-xs ${ct.color}` }, ct.icon),
                            e("div", null,
                                e("h5", { className: "font-heading font-black text-xs text-slate-900 leading-tight" }, ct.name),
                                e("span", { className: "text-[10px] text-slate-400 font-mono-data font-semibold block mt-0.5" }, ct.phone)
                            )
                        ),
                        e("button", {
                            onClick: () => { if (ct.call) window.location.href = `tel:${ct.call}`; },
                            className: "w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center text-xs active:scale-95 transition-all shadow-xs"
                        }, "📞")
                    )
                )
            ),
            // SafeZ Screen 3: My Communities Hub
            e("div", { className: "flex flex-col gap-2.5 mt-1" },
                e("div", { className: "flex items-center justify-between px-1" },
                    e("h4", { className: "font-heading font-black text-sm text-slate-900" }, "My Communities"),
                    e("span", { className: "text-[11px] font-bold text-slate-400 cursor-pointer hover:text-slate-900" }, "View all")
                ),
                e("div", { className: "grid grid-cols-2 gap-3" },
                    e("div", { className: "bg-white rounded-2xl p-3.5 border border-slate-100 shadow-xs flex flex-col gap-2.5" },
                        e("div", { className: "w-9 h-9 rounded-full bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-600 text-sm shadow-xs" }, "👨‍👩‍👦"),
                        e("div", null,
                            e("h5", { className: "font-heading font-black text-xs text-slate-900" }, "Family Tour Group"),
                            e("div", { className: "flex items-center gap-1 mt-1 text-[10px] text-slate-400 font-bold" },
                                e("span", { className: "text-emerald-600" }, "● Active"),
                                e("span", null, "• +5 members")
                            )
                        )
                    ),
                    e("div", { className: "bg-white rounded-2xl p-3.5 border border-slate-100 shadow-xs flex flex-col gap-2.5" },
                        e("div", { className: "w-9 h-9 rounded-full bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600 text-sm shadow-xs" }, "🏢"),
                        e("div", null,
                            e("h5", { className: "font-heading font-black text-xs text-slate-900" }, "Travel Crew Gang"),
                            e("div", { className: "flex items-center gap-1 mt-1 text-[10px] text-slate-400 font-bold" },
                                e("span", { className: "text-blue-600" }, "● Radar On"),
                                e("span", null, "• +21 members")
                            )
                        )
                    )
                )
            ),
            e("div", {
                onClick: () => setShowQrModal(true),
                className: "bg-white rounded-2xl p-4 border border-slate-200/90 shadow-xs flex items-center justify-between cursor-pointer hover:shadow-md transition-shadow active:scale-99"
            },
                e("div", { className: "flex items-center gap-3.5" },
                    e("div", { className: "w-11 h-11 rounded-2xl bg-blue-50 border border-blue-200/60 text-blue-600 flex items-center justify-center font-bold text-xl shrink-0" },
                        "▣"
                    ),
                    e("div", { className: "flex flex-col" },
                        e("h4", { className: "font-heading font-black text-sm text-slate-900 leading-tight" }, t.digitalQr),
                        e("p", { className: "text-xs text-slate-400 mt-0.5" }, t.digitalQrSub)
                    )
                ),
                e("span", { className: "text-slate-400 text-lg font-bold" }, "›")
            ),
            showQrModal && e("div", { className: "fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4" },
                e("div", { className: "bg-white rounded-3xl p-6 max-w-sm w-full flex flex-col items-center text-center gap-3.5 shadow-2xl" },
                    e("div", { className: "w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center text-2xl" }, "▣"),
                    e("h3", { className: "font-heading font-black text-lg text-slate-900" }, "Official Tourist QR Pass"),
                    e("p", { className: "text-xs text-slate-500" }, `Scan for Ministry of Tourism verification of ${profile.name || ""}`),
                    e("div", { className: "w-48 h-48 bg-slate-900 rounded-2xl p-3 flex items-center justify-center border-4 border-blue-500/20 shadow-inner my-2" },
                        e("div", { className: "w-full h-full bg-white rounded-xl flex flex-col items-center justify-center p-3 text-slate-900 font-mono-data font-black text-center" },
                            e("span", { className: "text-3xl mb-1" }, "▦"),
                            e("span", { className: "text-[9px] text-slate-500 font-bold" }, "SECURE GOV-ID-PASS"),
                            e("span", { className: "text-[10px] text-blue-600 mt-0.5" }, profile.passportNumber || "IN84712093")
                        )
                    ),
                    e("button", {
                        onClick: () => setShowQrModal(false),
                        className: "w-full py-3 rounded-xl bg-slate-900 text-white font-bold text-xs uppercase"
                    }, "Close QR Pass")
                )
            ),
            isEditingProfile && e("div", { className: "fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4" },
                e("div", { className: "bg-white border border-slate-200 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl max-h-[90vh] flex flex-col" },
                    e("div", { className: "bg-[#0b192c] p-5 flex justify-between items-center text-white" },
                        e("div", null,
                            e("h3", { className: "font-heading font-black text-base sm:text-lg text-white" }, "Edit Tourist Identity Pass"),
                            e("p", { className: "text-xs text-slate-300 font-medium" }, "Update your personal profile, staying accommodation & emergency contact")
                        ),
                        e("button", { onClick: () => setIsEditingProfile(false), className: "w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center text-sm font-bold" }, "✕")
                    ),
                    e("form", {
                        onSubmit: (e) => {
                            e.preventDefault();
                            const f = e.target;
                            const updated = {
                                ...profile,
                                name: f.name.value.trim(),
                                gender: f.gender.value,
                                nationality: f.nationality.value,
                                passportNumber: f.passportNumber.value.trim(),
                                hotel: f.hotel.value.trim(),
                                hotelAddress: f.hotelAddress.value.trim(),
                                roomNumber: f.roomNumber.value.trim(),
                                contact: f.contact.value.trim(),
                                bloodGroup: f.bloodGroup.value,
                                emergencyContactName: f.emergencyContactName ? f.emergencyContactName.value.trim() : profile.emergencyContactName
                            };
                            setProfile(updated);
                            setIsEditingProfile(false);
                        },
                        className: "p-5 sm:p-6 overflow-y-auto flex flex-col gap-3.5 text-xs sm:text-sm"
                    },
                        e("div", { className: "grid grid-cols-2 gap-3" },
                            e("div", null,
                                e("label", { className: "text-xs text-slate-800 font-bold block mb-1 uppercase font-mono-data" }, "Full Name *"),
                                e("input", { required: true, name: "name", type: "text", defaultValue: profile.name || "", placeholder: "e.g. Rahul Sharma", className: "w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-slate-900 font-bold focus:outline-none focus:border-blue-500 shadow-xs" })
                            ),
                            e("div", null,
                                e("label", { className: "text-xs text-slate-800 font-bold block mb-1 uppercase font-mono-data" }, "Gender *"),
                                e("select", { name: "gender", defaultValue: profile.gender || "Male", className: "w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-slate-900 font-bold focus:outline-none focus:border-blue-500 cursor-pointer shadow-xs" },
                                    e("option", { value: "Male" }, "Male"),
                                    e("option", { value: "Female" }, "Female"),
                                    e("option", { value: "Non-Binary" }, "Non-Binary"),
                                    e("option", { value: "Prefer not to say" }, "Prefer not to say")
                                )
                            )
                        ),
                        e("div", { className: "grid grid-cols-2 gap-3" },
                            e("div", null,
                                e("label", { className: "text-xs text-slate-800 font-bold block mb-1 uppercase font-mono-data" }, "Nationality *"),
                                e("input", { required: true, name: "nationality", type: "text", defaultValue: profile.nationality || "India", placeholder: "e.g. India, USA", className: "w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-slate-900 font-bold focus:outline-none focus:border-blue-500 shadow-xs" })
                            ),
                            e("div", null,
                                e("label", { className: "text-xs text-slate-800 font-bold block mb-1 uppercase font-mono-data" }, "Passport / Govt ID #"),
                                e("input", { name: "passportNumber", type: "text", defaultValue: profile.passportNumber || "IN84712093", placeholder: "Aadhaar / Passport / ID", className: "w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-slate-900 font-mono-data font-bold focus:outline-none focus:border-blue-500 shadow-xs" })
                            )
                        ),
                        e("div", { className: "grid grid-cols-3 gap-3" },
                            e("div", { className: "col-span-2" },
                                e("label", { className: "text-xs text-slate-800 font-bold block mb-1 uppercase font-mono-data" }, "Hotel / Stay Place Name"),
                                e("input", { name: "hotel", type: "text", defaultValue: profile.hotel || "", placeholder: "Hotel Name", className: "w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-slate-900 font-bold focus:outline-none focus:border-blue-500 shadow-xs" })
                            ),
                            e("div", null,
                                e("label", { className: "text-xs text-slate-800 font-bold block mb-1 uppercase font-mono-data" }, "Room #"),
                                e("input", { name: "roomNumber", type: "text", defaultValue: profile.roomNumber || "", placeholder: "e.g. 412", className: "w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-slate-900 font-bold focus:outline-none focus:border-blue-500 shadow-xs" })
                            )
                        ),
                        e("div", null,
                            e("label", { className: "text-xs text-slate-800 font-bold block mb-1 uppercase font-mono-data" }, "Hotel Address"),
                            e("input", { 
                                name: "hotelAddress", 
                                type: "text", 
                                defaultValue: profile.hotelAddress || "", 
                                placeholder: "Hotel Address", 
                                className: "w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-slate-900 font-bold focus:outline-none focus:border-blue-500 shadow-xs" 
                            })
                        ),
                        e("div", { className: "grid grid-cols-2 gap-3" },
                            e("div", null,
                                e("label", { className: "text-xs text-slate-800 font-bold block mb-1 uppercase font-mono-data" }, "Emergency Mobile Number *"),
                                e("input", { required: true, name: "contact", type: "tel", defaultValue: profile.contact || "", placeholder: "10-digit mobile number", className: "w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-slate-900 font-mono-data font-bold focus:outline-none focus:border-blue-500 shadow-xs" })
                            ),
                            e("div", null,
                                e("label", { className: "text-xs text-slate-800 font-bold block mb-1 uppercase font-mono-data" }, "Blood Group"),
                                e("select", { name: "bloodGroup", defaultValue: profile.bloodGroup || "O+ Positive", className: "w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-slate-900 font-bold focus:outline-none focus:border-blue-500 cursor-pointer shadow-xs" },
                                    e("option", { value: "O+ Positive" }, "O+ Positive"),
                                    e("option", { value: "A+ Positive" }, "A+ Positive"),
                                    e("option", { value: "B+ Positive" }, "B+ Positive"),
                                    e("option", { value: "AB+ Positive" }, "AB+ Positive"),
                                    e("option", { value: "O- Negative" }, "O- Negative"),
                                    e("option", { value: "A- Negative" }, "A- Negative"),
                                    e("option", { value: "B- Negative" }, "B- Negative"),
                                    e("option", { value: "AB- Negative" }, "AB- Negative")
                                )
                            )
                        ),
                        e("div", { className: "flex gap-2.5 justify-end mt-3 pt-3 border-t border-slate-200" },
                            e("button", { type: "button", onClick: () => setIsEditingProfile(false), className: "bg-slate-200 hover:bg-slate-300 text-slate-800 px-4 py-2.5 rounded-xl font-bold transition-all" }, "Cancel"),
                            e("button", { type: "submit", className: "bg-[#0b192c] hover:bg-slate-800 text-white px-6 py-2.5 rounded-xl font-black shadow-md transition-all active:scale-95" }, "Save Profile Pass ➔")
                        )
                    )
                )
            )
        );
    }

    // --- MAIN RAKSHAGRID ROOT APP ---
    
    // --- LOUD DUAL-TONE EMERGENCY SOS SIREN SOUND ---
    const playEmergencySosSound = () => {
        try {
            const AudioCtx = window.AudioContext || window.webkitAudioContext;
            if (!AudioCtx) return;
            const ctx = new AudioCtx();
            if (ctx.state === 'suspended') ctx.resume();

            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sawtooth';

            const now = ctx.currentTime;
            // 2.5 second rapid emergency siren sweep (700Hz to 1300Hz)
            osc.frequency.setValueAtTime(750, now);
            osc.frequency.linearRampToValueAtTime(1300, now + 0.25);
            osc.frequency.linearRampToValueAtTime(750, now + 0.5);
            osc.frequency.linearRampToValueAtTime(1300, now + 0.75);
            osc.frequency.linearRampToValueAtTime(750, now + 1.0);
            osc.frequency.linearRampToValueAtTime(1300, now + 1.25);
            osc.frequency.linearRampToValueAtTime(750, now + 1.5);
            osc.frequency.linearRampToValueAtTime(1300, now + 1.75);
            osc.frequency.linearRampToValueAtTime(750, now + 2.0);
            osc.frequency.linearRampToValueAtTime(1300, now + 2.25);
            osc.frequency.linearRampToValueAtTime(750, now + 2.5);

            gain.gain.setValueAtTime(0.4, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 2.6);

            osc.connect(gain);
            gain.connect(ctx.destination);

            osc.start(now);
            osc.stop(now + 2.6);
        } catch (e) {
            console.warn('AudioContext SOS siren error:', e);
        }
    };

    // =========================================================================
    // SECTION: HIGH-END MATURE SVG NAVIGATION ICONS
    // =========================================================================
    function NavTabIcon({ tab, isActive }) {
        const stroke = isActive ? "#2563eb" : "#64748b";
        const strokeWidth = isActive ? "2.3" : "1.9";

        switch(tab) {
            case 'safety':
                return e("svg", { width: 22, height: 22, viewBox: "0 0 24 24", fill: "none", stroke: stroke, strokeWidth: strokeWidth, strokeLinecap: "round", strokeLinejoin: "round", className: "transition-transform group-active:scale-95" },
                    e("path", { d: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" })
                );
            case 'ai':
                return e("svg", { width: 22, height: 22, viewBox: "0 0 24 24", fill: "none", stroke: stroke, strokeWidth: strokeWidth, strokeLinecap: "round", strokeLinejoin: "round", className: "transition-transform group-active:scale-95" },
                    e("path", { d: "M12 3v3m6.366 1.634l-2.12 2.12M21 12h-3m1.634 6.366l-2.12-2.12M12 21v-3m-6.366 1.634l2.12-2.12M3 12h3m-1.634-6.366l2.12 2.12" }),
                    e("circle", { cx: "12", cy: "12", r: "3" })
                );
            case 'translate':
                return e("svg", { width: 22, height: 22, viewBox: "0 0 24 24", fill: "none", stroke: stroke, strokeWidth: strokeWidth, strokeLinecap: "round", strokeLinejoin: "round", className: "transition-transform group-active:scale-95" },
                    e("path", { d: "m5 8 6 6" }),
                    e("path", { d: "m4 14 6-6 2-3" }),
                    e("path", { d: "M2 5h12" }),
                    e("path", { d: "M7 2h1" }),
                    e("path", { d: "m22 22-5-10-5 10" }),
                    e("path", { d: "M14 18h6" })
                );
            case 'group':
                return e("svg", { width: 22, height: 22, viewBox: "0 0 24 24", fill: "none", stroke: stroke, strokeWidth: strokeWidth, strokeLinecap: "round", strokeLinejoin: "round", className: "transition-transform group-active:scale-95" },
                    e("path", { d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" }),
                    e("circle", { cx: "9", cy: "7", r: "4" }),
                    e("path", { d: "M22 21v-2a4 4 0 0 0-3-3.87" }),
                    e("path", { d: "M16 3.13a4 4 0 0 1 0 7.75" })
                );
            case 'lost':
                return e("svg", { width: 22, height: 22, viewBox: "0 0 24 24", fill: "none", stroke: stroke, strokeWidth: strokeWidth, strokeLinecap: "round", strokeLinejoin: "round", className: "transition-transform group-active:scale-95" },
                    e("path", { d: "M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" }),
                    e("path", { d: "m3.3 7 8.7 5 8.7-5" }),
                    e("path", { d: "M12 22V12" })
                );
            case 'profile':
                return e("svg", { width: 22, height: 22, viewBox: "0 0 24 24", fill: "none", stroke: stroke, strokeWidth: strokeWidth, strokeLinecap: "round", strokeLinejoin: "round", className: "transition-transform group-active:scale-95" },
                    e("path", { d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" }),
                    e("circle", { cx: "12", cy: "7", r: "4" })
                );
            default:
                return null;
        }
    }

    function TouristApp() {
        useEffect(() => {
            // Ensure no old profile or old group code is cached so everything resets cleanly on refresh
            try {
                localStorage.removeItem("rakshagrid_profile_v3");
                localStorage.removeItem("rg_active_group_code");
                localStorage.removeItem("rg_active_group_name");
            } catch (e) {}
        }, []);

        const [showStartModal, setShowStartModal] = useState(true);
        const [touristTab, setTouristTab] = useState("safety");
        const [selectedLang, setSelectedLang] = useState("English");
        const t = UI_I18N[selectedLang] || UI_I18N["English"];

        const [isSosActive, setIsSosActive] = useState(false);
        const [selectedCategory, setSelectedCategory] = useState("Medical Emergency");
        
        const [profile, setProfile] = useState({
            name: "",
            gender: "Male",
            nationality: "India",
            passportNumber: "IN84712093",
            hotel: "",
            hotelAddress: "",
            roomNumber: "",
            contact: "",
            bloodGroup: "O+ Positive",
            localGuide: "Tourism Police Post (+91-22-2204-4040)",
            medicalNotes: "None",
            isVerified: true
        });

        const [isEditingProfile, setIsEditingProfile] = useState(false);
        const [isFilingLostModalOpen, setIsFilingLostModalOpen] = useState(false);
        const [touristCoords, setTouristCoords] = useState({ x: 190, y: 140 });
        const [touristLatLong, setTouristLatLong] = useState({ lat: 18.9242, lng: 72.8310 });
        const [isUsingRealGps, setIsUsingRealGps] = useState(false);
        const [livePlaceName, setLivePlaceName] = useState("Gateway Corridor, Colaba");

        // Reverse geocode whenever touristLatLong changes (from device GPS or marker drag)
        useEffect(() => {
            if (touristLatLong && touristLatLong.lat && touristLatLong.lng) {
                fetch(`/api/reverse-geocode?lat=${touristLatLong.lat}&lng=${touristLatLong.lng}`)
                    .then(r => r.json())
                    .then(data => {
                        if (data && data.displayName) {
                            setLivePlaceName(data.displayName);
                        }
                    })
                    .catch(e => console.warn("Reverse geocode sync:", e));
            }
        }, [touristLatLong]);

        // Optional auto-locate on initial app launch if browser allows
        useEffect(() => {
            if ("geolocation" in navigator) {
                navigator.geolocation.getCurrentPosition(
                    (pos) => {
                        setTouristLatLong({ lat: pos.coords.latitude, lng: pos.coords.longitude });
                        setIsUsingRealGps(true);
                    },
                    (err) => {
                        console.log("Using default corridor:", err.message);
                    },
                    { enableHighAccuracy: true, timeout: 8000, maximumAge: 60000 }
                );
            }
        }, []);
        const [broadcastAlerts, setBroadcastAlerts] = useState([
            "Wave heights exceeding 3.5m expected near Apollo Bunder after 18:00.",
            "Police safety booths operational 24/7 along Colaba Heritage Corridor.",
            "Emergency Helpline 112 linked with GPS telemetry."
        ]);

        const [chatMessages, setChatMessages] = useState([
            {
                sender: "user",
                text: "Is it safe to visit Juhu Beach after 8 PM?",
                time: "08:14 PM"
            },
            {
                sender: "bot",
                structured: {
                    intro: "I have analyzed current local safety corridor streams for Juhu Beach, Mumbai (8:15 PM telemetry):",
                    rating: "Generally Safe",
                    ratingType: "safe",
                    points: [
                        { color: "orange", text: "Stay in well-lit areas near main promenade" },
                        { color: "orange", text: "Avoid isolated stretches near the water line" },
                        { color: "green", text: "Emergency services: 2 active police stations within 1km" }
                    ],
                    summary: "Juhu Beach promenade is active and guarded till 11:00 PM."
                },
                time: "08:15 PM"
            }
        ]);
        const [chatInput, setChatInput] = useState("");
        const [isAiThinking, setIsAiThinking] = useState(false);
        const [geminiApiKey, setGeminiApiKey] = useState("");
        const [showKeyModal, setShowKeyModal] = useState(false);

        const [activeGroupCode, setActiveGroupCode] = useState("");
        const [activeGroupName, setActiveGroupName] = useState("");
        const [isCreatingGroup, setIsCreatingGroup] = useState(false);
        const [newGroupNameInput, setNewGroupNameInput] = useState("");
        const [joinCodeInput, setJoinCodeInput] = useState("");
        const [groupMembers, setGroupMembers] = useState([]);
        const [groupChat, setGroupChat] = useState([]);
        const [groupChatInput, setGroupChatInput] = useState("");
        const groupChatBoxRef = useRef(null);

        // Auto-scroll group chat to bottom when new messages arrive
        useEffect(() => {
            if (groupChatBoxRef.current) {
                groupChatBoxRef.current.scrollTop = groupChatBoxRef.current.scrollHeight;
            }
        }, [groupChat, touristTab]);

        const [myLocalLostIds, setMyLocalLostIds] = useState(() => {
            const saved = localStorage.getItem("rakshagrid_my_lost_ids");
            if (saved) {
                try { return JSON.parse(saved); } catch (e) {}
            }
            return [];
        });
        const [lostReports, setLostReports] = useState([]);

        // --- REAL-TIME BACKEND SYNC (AUTHORITY <-> TOURIST) ---
        const [activeSosIncidentId, setActiveSosIncidentId] = useState(null);
        const [sosLiveStatus, setSosLiveStatus] = useState("Dispatched");

        useEffect(() => {
            let isMounted = true;
            const syncWithBackend = () => {
                fetch('/api/broadcasts', { cache: 'no-store' })
                    .then(r => r.json())
                    .then(data => {
                        if (isMounted && Array.isArray(data) && data.length > 0) {
                            setBroadcastAlerts(data);
                        }
                    })
                    .catch(e => console.warn('Broadcast sync:', e));

                fetch('/api/lost', { cache: 'no-store' })
                    .then(r => r.json())
                    .then(data => {
                        if (isMounted && Array.isArray(data)) {
                            setLostReports(data);
                        }
                    })
                    .catch(e => console.warn('Lost sync:', e));

                if (activeSosIncidentId) {
                    fetch('/api/incidents', { cache: 'no-store' })
                        .then(r => r.json())
                        .then(data => {
                            if (isMounted && Array.isArray(data)) {
                                const myInc = data.find(i => i.id === activeSosIncidentId);
                                if (myInc && myInc.status) {
                                    setSosLiveStatus(myInc.status);
                                }
                            }
                        })
                        .catch(e => console.warn('SOS sync:', e));
                }
            };

            syncWithBackend();
            const interval = setInterval(syncWithBackend, 1500);
            return () => {
                isMounted = false;
                clearInterval(interval);
            };
        }, [activeSosIncidentId]);

                                                const handleOnboardingSubmit = (e) => {
            e.preventDefault();
            const form = e.target;
            const cleanName = (form.userName ? form.userName.value : '').trim();
            const cleanMobile = (form.userMobile ? form.userMobile.value : '').trim();
            const cleanNat = (form.userNationality ? form.userNationality.value : 'India').trim();
            const cleanGen = (form.userGender ? form.userGender.value : 'Male').trim();

            console.log('Setting live profile:', { cleanName, cleanMobile, cleanNat, cleanGen });

            const updatedProfile = {
                ...profile,
                name: cleanName,
                contact: cleanMobile,
                nationality: cleanNat || 'India',
                gender: cleanGen || 'Male'
            };

            setProfile(updatedProfile);
            setShowOnboardingForm(false);
            setHasStarted(true);
            setTouristTab("safety");
        };

        
        
        // --- HIGH FREQUENCY (800ms) REAL-TIME LIVE GROUP SYNC HOOK ---
        useEffect(() => {
            if (!activeGroupCode) return;
            let isMounted = true;

            const syncGroupData = () => {
                fetch(`/api/group/room?code=${encodeURIComponent(activeGroupCode)}`, { cache: 'no-store' })
                    .then(r => r.json())
                    .then(data => {
                        if (isMounted && data.success && data.group) {
                            if (Array.isArray(data.group.members) && data.group.members.length > 0) {
                                setGroupMembers(data.group.members);
                            }
                            if (Array.isArray(data.group.chat)) {
                                setGroupChat(data.group.chat);
                            }
                            if (data.group.name) {
                                setActiveGroupName(data.group.name);
                            }
                        }
                    })
                    .catch(e => console.warn('Group sync error:', e));
            };

            syncGroupData();
            const groupInterval = setInterval(syncGroupData, 800);
            return () => {
                isMounted = false;
                clearInterval(groupInterval);
            };
        }, [activeGroupCode]);


        // --- GROUP HANDLERS ---
                const handleCreateGroup = (e) => {
            e.preventDefault();
            const letters = "ABCDEFGHJKLMNPQRSTUVWXYZ";
            const digits = "23456789";
            let code = "";
            for (let i = 0; i < 3; i++) code += letters[Math.floor(Math.random() * letters.length)];
            code += "-";
            for (let i = 0; i < 3; i++) code += digits[Math.floor(Math.random() * digits.length)];
            
            const gName = newGroupNameInput.trim() || "Mumbai Trip Gang";
            const myName = (profile.name && profile.name.trim()) ? profile.name.trim() : "Host (You)";
            
            setActiveGroupCode(code);
            setActiveGroupName(gName);
            localStorage.setItem("rg_active_group_code", code);
            localStorage.setItem("rg_active_group_name", gName);
            setIsCreatingGroup(false);
            setNewGroupNameInput("");
            
            const selfMember = {
                id: `M-${Math.floor(100 + Math.random() * 900)}`,
                name: myName,
                distanceMeters: 0,
                battery: "100%",
                role: "Group Leader (Host)",
                latLong: `${touristLatLong.lat}° N, ${touristLatLong.lng}° E`,
                status: "Safe & Active",
                landmark: "Gateway Promenade"
            };
            setGroupMembers([selfMember]);

            fetch('/api/group/create', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    groupCode: code,
                    groupName: gName,
                    creator: selfMember
                })
            })
            .then(r => r.json())
            .then(data => {
                if (data.success && data.group) {
                    setGroupMembers(data.group.members);
                    setGroupChat(data.group.chat);
                }
            })
            .catch(err => console.warn(err));

            alert(`🎉 New Group Created!
Group Name: ${gName}
Invite Code: ${code}
Share this code with your friend to join live!`);
        };

        const handleJoinGroup = (e) => {
            e.preventDefault();
            const code = joinCodeInput.trim().toUpperCase();
            if (!code) return;
            
            const myName = (profile.name && profile.name.trim()) ? profile.name.trim() : "Friend (You)";
            const selfMember = {
                id: `M-${Math.floor(100 + Math.random() * 900)}`,
                name: myName,
                distanceMeters: Math.floor(10 + Math.random() * 30),
                battery: "98%",
                role: "Group Member",
                latLong: `${touristLatLong.lat}° N, ${touristLatLong.lng}° E`,
                status: "Safe & Active",
                landmark: "Gateway Promenade"
            };

            setActiveGroupCode(code);
            setActiveGroupName(`Room ${code}`);
            localStorage.setItem("rg_active_group_code", code);
            localStorage.setItem("rg_active_group_name", `Room ${code}`);
            setJoinCodeInput("");

            fetch('/api/group/join', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ groupCode: code, member: selfMember })
            })
            .then(r => r.json())
            .then(data => {
                if (data.success && data.group) {
                    setGroupMembers(data.group.members);
                    setGroupChat(data.group.chat);
                    if (data.group.name) {
                        setActiveGroupName(data.group.name);
                        localStorage.setItem("rg_active_group_name", data.group.name);
                    }
                    alert(`✅ Joined "${data.group.name || code}"!
Connected members: ${data.group.members.length}`);
                }
            })
            .catch(err => console.warn(err));
        };

        const handleLeaveGroup = () => {
            if (window.confirm("Are you sure you want to leave this group room?")) {
                const codeToLeave = activeGroupCode;
                const myName = (profile.name && profile.name.trim()) ? profile.name.trim() : "Host (You)";
                
                fetch('/api/group/leave', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        groupCode: codeToLeave,
                        memberName: myName
                    })
                }).catch(err => console.warn('Leave group sync:', err));

                setActiveGroupCode("");
                setActiveGroupName("");
                localStorage.removeItem("rg_active_group_code");
                localStorage.removeItem("rg_active_group_name");
                setGroupMembers([]);
                setGroupChat([]);
            }
        };

        const handleSendGroupChat = (e) => {
            e.preventDefault();
            if (!groupChatInput.trim()) return;
            const chatMsg = {
                sender: profile.name,
                text: groupChatInput.trim(),
                time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            };
            setGroupChat(prev => [...prev, chatMsg]);
            setGroupChatInput("");
            fetch('/api/group/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ...chatMsg, groupCode: activeGroupCode })
            }).catch(err => console.warn(err));
        };

        // --- LOST & FOUND HANDLERS ---
        const handleLostFoundSubmit = (e, cat, otherText) => {
            e.preventDefault();
            const form = e.target;
            const finalCategory = cat === "Other" && otherText.trim() ? `Other (${otherText.trim()})` : (cat || "General Item");
            const itemDescription = form.item ? form.item.value : "Item";
            const lastLocation = form.location ? form.location.value : "Gateway Promenade";
            const contactForReturn = (form.contactInfo && form.contactInfo.value) ? form.contactInfo.value : profile.contact;
            const timeNow = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            const newId = `LST-${Math.floor(100 + Math.random() * 900)}`;

            const newReport = {
                id: newId,
                timestamp: `Today, ${timeNow}`,
                touristName: profile.name || "",
                nationality: profile.nationality || "India",
                contact: contactForReturn,
                hotel: `${profile.hotel || 'Hotel'}, ${profile.roomNumber || ''}`,
                category: finalCategory,
                item: itemDescription,
                location: lastLocation,
                status: "Searching",
                assignedOfficer: "Tourism Police Helpdesk (Gateway Post)"
            };

            setMyLocalLostIds(prev => {
                const updated = [newId, ...prev.filter(id => id !== newId)];
                localStorage.setItem("rakshagrid_my_lost_ids", JSON.stringify(updated));
                return updated;
            });

            setLostReports(prev => [newReport, ...prev.filter(r => r.id !== newId)]);
            
            fetch('/api/lost', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newReport)
            }).catch(err => console.warn('Lost report sync:', err));

            alert(`✅ Lost Property Claim Logged!
Claim ID: ${newReport.id}
Item: ${newReport.item}
Your report is registered with the Police & Authority Command Desk.`);
            form.reset();
        };

        const handleDismissMyReport = (reportId) => {
            setMyLocalLostIds(prev => {
                const updated = prev.filter(id => id !== reportId);
                localStorage.setItem("rakshagrid_my_lost_ids", JSON.stringify(updated));
                return updated;
            });
            setLostReports(prev => prev.filter(r => r.id !== reportId));
        };

        const handleClearAllMyReports = () => {
            if (window.confirm("Clear all your logged lost reports from this screen?")) {
                setMyLocalLostIds([]);
                setLostReports([]);
                localStorage.setItem("rakshagrid_my_lost_ids", "[]");
            }
        };

        // SOS Trigger function with Instant Backend Push
        const handleTriggerSos = () => {
            playEmergencySosSound();
            const newIncId = `INC-${Math.floor(1000 + Math.random() * 9000)}`;
            setIsSosActive(true);
            setActiveSosIncidentId(newIncId);
            setSosLiveStatus("Dispatched");

            const placeName = isUsingRealGps 
                ? `Live Device Location (${Number(touristLatLong.lat).toFixed(4)}° N, ${Number(touristLatLong.lng).toFixed(4)}° E)`
                : "Gateway of India Promenade, Apollo Bunder, Colaba";
            const landmarkName = isUsingRealGps 
                ? "Physical Device GPS Position"
                : "Gateway Heritage Corridor, opposite Taj Mahal Palace, Colaba";

            const sosAlert = {
                id: newIncId,
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                name: (profile.name && profile.name.trim()) ? profile.name.trim() : "Tourist",
                nationality: profile.nationality || "India",
                contact: profile.contact || "+91-9820-112233",
                bloodGroup: profile.bloodGroup || "O+ Positive",
                hotel: profile.hotel || "Hotel Accommodation",
                category: selectedCategory,
                severity: "Critical",
                locationName: placeName,
                landmark: landmarkName,
                coordinates: touristLatLong,
                agency: selectedCategory.includes("Medical") ? "Hospital / EMS Desk" : "Police Control Room",
                status: "Dispatched",
                note: `Direct SOS Beacon triggered by ${profile.name || 'Tourist'} at ${placeName} (${landmarkName})`
            };

            fetch('/api/incidents', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(sosAlert)
            }).catch(e => console.warn('API sync:', e));

            // Update local group members status to Emergency SOS
            setGroupMembers(prev => prev.map(m => {
                const isSelf = m.id === "M-YOU" || (profile.name && m.name && profile.name.toLowerCase() === m.name.toLowerCase());
                if (isSelf) return { ...m, status: "🚨 EMERGENCY SOS ACTIVE", isSos: true };
                return m;
            }));

            // Immediately broadcast critical emergency alert & status to Group Room
            if (activeGroupCode) {
                const groupSosMsg = {
                    sender: "🚨 EMERGENCY ALERT",
                    text: `🚨 SOS TRIGGERED by ${profile.name || 'Group Member'}! Category: "${selectedCategory}". Location: Gateway Corridor (${touristLatLong.lat.toFixed(4)}° N, ${touristLatLong.lng.toFixed(4)}° E). Authorities alerted!`,
                    time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                    isAlert: true
                };
                setGroupChat(prev => [...prev, groupSosMsg]);
                fetch('/api/group/chat', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ ...groupSosMsg, groupCode: activeGroupCode })
                }).catch(e => console.warn('Group SOS broadcast error:', e));

                fetch('/api/group/status', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        groupCode: activeGroupCode,
                        memberName: profile.name || 'Tourist',
                        status: "🚨 EMERGENCY SOS ACTIVE",
                        isSos: true
                    })
                }).catch(e => console.warn('Group status sync:', e));
            }
        };

        const handleCancelSos = () => {
            setIsSosActive(false);
            setGroupMembers(prev => prev.map(m => {
                const isSelf = m.id === "M-YOU" || (profile.name && m.name && profile.name.toLowerCase() === m.name.toLowerCase());
                if (isSelf) return { ...m, status: "Safe & Active", isSos: false };
                return m;
            }));
            if (activeGroupCode) {
                fetch('/api/group/status', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        groupCode: activeGroupCode,
                        memberName: profile.name || 'Tourist',
                        status: "Safe & Active",
                        isSos: false
                    })
                }).catch(e => console.warn('Group status sync:', e));
            }
        };

        // AI Chat Query Submission (Multilingual + Gemini / Offline fallback)
        const handleSendAiQuery = async (e, forcedQuery = null) => {
            if (e) e.preventDefault();
            const query = forcedQuery || chatInput;
            if (!query.trim() || isAiThinking) return;

            const timeNow = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            setChatMessages(prev => [...prev, { sender: "user", text: query, time: timeNow }]);
            setChatInput("");
            setIsAiThinking(true);

            if (geminiApiKey && geminiApiKey.trim().length > 10) {
                try {
                    const liveLocName = isUsingRealGps 
                        ? `Live GPS (${Number(touristLatLong.lat).toFixed(4)}° N, ${Number(touristLatLong.lng).toFixed(4)}° E)`
                        : `Gateway of India, Apollo Bunder, Colaba, Mumbai (18.9242° N, 72.8310° E)`;

                    const prompt = `You are RakshaGrid AI, an expert tourist safety assistant in Maharashtra, India.
User Current Location: "${liveLocName}"
User Query: "${query}"
Respond in language: ${selectedLang} (English, Hindi or Marathi).

IMPORTANT: If the user asks about police stations, hospitals, clinics, medical services, pharmacies, emergency facilities, or what is around them, provide complete, detailed information for their surrounding area including verified place names, distances (e.g. 350m, 1.2km), addresses, and 24/7 emergency phone numbers.

Return strictly JSON in this schema:
{
  "intro": "Brief introductory sentence in ${selectedLang}",
  "rating": "Safety status in ${selectedLang} (e.g. Generally Safe / 24/7 Emergency Grid Active)",
  "ratingType": "safe or warning or critical",
  "points": [
    {"color": "green or orange or red", "text": "detailed facility/service with distance and contact in ${selectedLang}"},
    {"color": "green or orange or red", "text": "detailed facility/service with distance and contact in ${selectedLang}"},
    {"color": "green or orange or red", "text": "detailed facility/service with distance and contact in ${selectedLang}"}
  ],
  "summary": "Practical emergency tip / navigation recommendation in ${selectedLang}"
}`;

                    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${geminiApiKey.trim()}`, {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({
                            contents: [{ role: "user", parts: [{ text: prompt }] }]
                        })
                    });
                    const data = await response.json();
                    const raw = data.candidates[0].content.parts[0].text;
                    const cleanJson = raw.replace(/\`\`\`json/g, '').replace(/\`\`\`/g, '').trim();
                    const parsed = JSON.parse(cleanJson);
                    if (parsed.intro && parsed.points) {
                        const qLower = query.toLowerCase();
                        const isLocationQuery = qLower.includes("hospital") || qLower.includes("police") || 
                            qLower.includes("doctor") || qLower.includes("clinic") || qLower.includes("pharmacy") || 
                            qLower.includes("chemist") || qLower.includes("station") || qLower.includes("place") || 
                            qLower.includes("hotel") || qLower.includes("restaurant") || qLower.includes("attraction") || 
                            qLower.includes("facilities") || qLower.includes("near") || qLower.includes("where") || 
                            qLower.includes("kahan") || qLower.includes("kuthe") || qLower.includes("around");

                        if (isLocationQuery && !parsed.mapsLink) {
                            parsed.mapsLink = `https://www.google.com/maps/search/${encodeURIComponent(query)}/@${touristLatLong.lat},${touristLatLong.lng},16z`;
                            parsed.mapsLabel = selectedLang === "Hindi" ? "📍 गूगल मैप्स पर सटीक स्थान देखें" : selectedLang === "Marathi" ? "📍 गुगल मॅप्सवर अचूक स्थान पहा" : "📍 View Exact Location on Google Maps";
                        }
                        setChatMessages(prev => [...prev, {
                            sender: "bot",
                            structured: parsed,
                            userQuery: query,
                            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                        }]);
                        setIsAiThinking(false);
                        return;
                    }
                } catch (err) {
                    console.warn("Gemini query error, falling back to offline engine:", err);
                }
            }

            setTimeout(() => {
                const response = generateOfflineAIResponse(query, selectedLang, touristLatLong, profile, livePlaceName, isUsingRealGps);
                setChatMessages(prev => [...prev, {
                    sender: "bot",
                    structured: response,
                    userQuery: query,
                    time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                }]);
                setIsAiThinking(false);
            }, 400);
        };



        // =========================================================================
        // VIEW 2: MAIN DASHBOARD & TABS (SafeZ Ultra-Modern Clean Theme)
        // =========================================================================
        return e("div", { className: "min-h-screen bg-slate-100 flex justify-center items-start sm:py-6 selection:bg-rose-500 selection:text-white" },
            e("div", { className: "mobile-container w-full min-h-screen flex flex-col bg-[#f8fafc] text-slate-900 pb-28 shadow-2xl relative" },
                
                // Top Header (Absolute Dead-Centered Title, Balanced Language Pill)
                e("header", { className: "px-5 py-3.5 bg-white/95 backdrop-blur-md border-b border-slate-100/80 flex items-center justify-between shrink-0 sticky top-0 z-40 relative min-h-[56px]" },
                    // Left: Subtle Authority Access
                    e("a", {
                        href: "/authority",
                        title: "Open Authority Console",
                        className: "w-8 h-8 rounded-full bg-slate-50 hover:bg-slate-100 border border-slate-200/80 text-slate-600 text-xs flex items-center justify-center shadow-xs transition-colors shrink-0 z-10"
                    }, "🔒"),

                    // Center: Pure Website Name (Absolute 100% Horizontal Center with India Flag)
                    e("div", { className: "absolute inset-0 flex items-center justify-center pointer-events-none" },
                        e("h1", { className: "font-heading font-black text-lg text-slate-900 tracking-tight leading-none pointer-events-auto select-none flex items-center gap-1.5" },
                            e("span", null, "RakshaGrid"),
                            e("span", { className: "text-base" }, "🇮🇳")
                        )
                    ),

                    // Right: Modern Language Switcher Pill (Fits Cleanly & Elegantly)
                    e("div", { className: "flex items-center shrink-0 z-10" },
                        e("select", {
                            value: selectedLang,
                            onChange: (e) => setSelectedLang(e.target.value),
                            className: "bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-full px-3 py-1 text-xs font-bold text-slate-800 cursor-pointer focus:outline-none shadow-xs transition-colors"
                        },
                            e("option", { value: "English" }, "EN"),
                            e("option", { value: "Hindi" }, "HI"),
                            e("option", { value: "Marathi" }, "MR")
                        )
                    )
                ),

                // Amber Live Radar Ticker
                e("div", { className: "bg-amber-50/80 border-b border-amber-100 px-4 py-1 text-xs flex items-center gap-2 overflow-hidden shrink-0" },
                    e("span", { className: "bg-amber-500 text-white px-2 py-0.5 rounded-full text-[9px] font-black uppercase shrink-0 font-heading" }, t.radarAlert),
                    e("div", { className: "ticker-container flex-1 overflow-hidden" },
                        e("div", { className: "ticker-content text-amber-900 font-bold text-[11px]" },
                            broadcastAlerts.join('   ✦   ')
                        )
                    )
                ),

                // =================================================================
                // TAB CONTENT BODY
                // =================================================================
                e("main", { className: "flex-1 p-5 pb-24 overflow-y-auto" },

                    // -------------------------------------------------------------
                    // TAB: SAFETY (SafeZ Hero SOS & Responders Layout)
                    // -------------------------------------------------------------
                    touristTab === "safety" && e("div", { className: "flex flex-col gap-5" },
                        isSosActive ? e("div", { className: "flex flex-col gap-4" },
                            e("div", { className: "flex items-center gap-2 text-rose-600 text-xs font-black font-mono-data uppercase tracking-wider bg-rose-50 border border-rose-200 px-3 py-2 rounded-2xl" },
                                e("span", { className: "w-2.5 h-2.5 rounded-full bg-rose-600 animate-ping" }),
                                e("span", null, "EMERGENCY DISPATCH BROADCAST ACTIVE")
                            ),
                            e("div", { className: "card-modern p-6 flex flex-col items-center text-center gap-2" },
                                e("div", { className: "w-20 h-20 rounded-full border-4 border-rose-100 bg-rose-50 flex items-center justify-center text-rose-600 text-3xl mb-1 shadow-inner" },
                                    "🛡️"
                                ),
                                e("h2", { className: "font-heading font-black text-xl text-rose-600 uppercase tracking-tight" }, t.emergencyActive),
                                e("p", { className: "text-xs text-slate-500" }, t.emergencyActiveSub)
                            ),
                            e("div", { className: "card-modern p-5 flex flex-col gap-3 text-xs" },
                                e("span", { className: "text-[10px] font-black text-slate-400 uppercase tracking-wider font-mono-data" }, t.dispatchStatus),
                                e("div", { className: "flex items-center gap-2 font-bold text-slate-800" },
                                    e("span", { className: "text-slate-400" }, "⚡"),
                                    e("span", null, t.distressType),
                                    e("span", { className: "text-slate-900 font-extrabold" }, selectedCategory)
                                ),
                                e("div", { className: "flex items-center gap-2 font-bold text-slate-800" },
                                    e("span", { className: "text-slate-400" }, "📍"),
                                    e("span", null, t.location),
                                    e("span", { className: "text-slate-900 font-extrabold" }, "Near Gateway of India, Mumbai")
                                ),
                                e("div", { className: "flex items-center gap-2 font-bold text-emerald-700" },
                                    e("span", null, "✔️"),
                                    e("span", null, t.dispatched),
                                    e("span", { className: "font-extrabold text-emerald-800" }, sosLiveStatus === 'Resolved' ? (selectedLang === 'Hindi' ? 'मामला हल और बंद कर दिया गया है' : selectedLang === 'Marathi' ? 'प्रकरण सोडवले व बंद केले' : 'Incident Resolved & Closed') : sosLiveStatus === 'Pending' ? (selectedLang === 'Hindi' ? 'प्राथमिकता कतार (टीम सौंपी जा रही है)' : selectedLang === 'Marathi' ? 'प्राधान्य रांग (पथक नेमले जात आहे)' : 'Priority Queue (Assigning Unit)') : (selectedLang === 'Hindi' ? 'पुलिस दल + एम्बुलेंस रवाना' : selectedLang === 'Marathi' ? 'पोलीस पथक + रुग्णवाहिका रवाना' : 'Police Unit + Ambulance Dispatched'))
                                )
                            ),
                            e("div", { className: "bg-[#0f172a] rounded-3xl p-4 text-white relative overflow-hidden flex flex-col gap-2 shadow-xl" },
                                e("div", { className: "flex items-center justify-between text-[10px] font-mono-data" },
                                    e("span", { className: "text-emerald-400 font-bold" }, "RESPONDER ETA: ~4 MIN"),
                                    e("span", { className: "bg-emerald-950/90 text-emerald-400 border border-emerald-500/30 px-2.5 py-0.5 rounded-full font-bold" }, "SECURE GPS TELEMETRY")
                                ),
                                e("div", { className: "h-32 bg-[#1e293b] rounded-2xl border border-slate-700 relative flex items-center justify-center overflow-hidden" },
                                    e("div", { className: "absolute inset-0 opacity-20", style: { backgroundImage: 'radial-gradient(#38bdf8 1px, transparent 1px)', backgroundSize: '16px 16px' } }),
                                    e("div", { className: "radar-sweep-cone" }),
                                    e("div", { className: "w-4 h-4 rounded-full bg-rose-500 animate-ping absolute" }),
                                    e("div", { className: "w-3 h-3 rounded-full bg-rose-600 absolute border-2 border-white" }),
                                    e("span", { className: "absolute bottom-2 bg-slate-900/90 text-white text-[10px] font-bold px-3 py-1 rounded-full border border-slate-700" },
                                        "ETA: 4 MIN • EN ROUTE"
                                    )
                                )
                            ),
                            e("button", {
                                onClick: () => { window.location.href = "tel:112"; },
                                className: "w-full py-4 rounded-full bg-[#0f172a] hover:bg-slate-800 text-white font-heading font-black text-xs uppercase tracking-wider shadow-xl active:scale-98 text-center transition-all"
                            }, t.callEmergency),
                            e("button", {
                                onClick: handleCancelSos,
                                className: "w-full py-4 rounded-full bg-white border-2 border-rose-500 text-rose-600 hover:bg-rose-50 font-heading font-black text-xs uppercase tracking-wider active:scale-98 text-center transition-all shadow-sm"
                            }, t.cancelEmergency)
                        ) : 
                        e("div", { className: "flex flex-col gap-5" },
                            // 1. User Greeting & Profile Avatar Row (SafeZ Screen 1 Top)
                            e("div", { className: "flex items-center justify-between pt-1" },
                                e("div", null,
                                    e("h2", { className: "font-heading font-black text-2xl text-slate-900 tracking-tight" }, `Hi, ${profile.name ? profile.name.split(' ')[0] : 'George'}!`),
                                    e("p", { className: "text-xs text-slate-500 font-medium truncate max-w-[240px]" }, `${livePlaceName || 'Live GPS Locked'} • Safe Corridor`)
                                ),
                                e("div", { className: "relative cursor-pointer", onClick: () => setTouristTab("profile") },
                                    e("div", {
                                        className: "w-12 h-12 rounded-full bg-[#0f172a] text-white flex items-center justify-center font-heading font-black text-sm shadow-md ring-2 ring-slate-100 shrink-0 aspect-square",
                                        style: { width: '48px', height: '48px', minWidth: '48px', minHeight: '48px', borderRadius: '9999px', flexShrink: 0, aspectRatio: '1/1' }
                                    },
                                        profile.name ? profile.name.split(' ').map(n=>n[0]).join('').slice(0,2).toUpperCase() : "RG"
                                    ),
                                    e("span", { className: "absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-white" })
                                )
                            ),

                            // 2. Real Group Members Carousel (Only real connected members + Add Member button)
                            e("div", { className: "flex items-center gap-3 overflow-x-auto no-scrollbar py-1" },
                                // Real Group Members (populated when user creates or joins a group)
                                (groupMembers && groupMembers.length > 0) && groupMembers.map((member, mIdx) => {
                                    const isSelf = member.id === "M-YOU" || (profile.name && member.name && profile.name.toLowerCase() === member.name.toLowerCase());
                                    const isSosMember = member.isSos || (member.status && member.status.includes("SOS")) || (isSelf && isSosActive);
                                    const distText = isSosMember ? "🚨 SOS" : (isSelf ? "You (Host)" : (member.distanceMeters !== undefined ? `${member.distanceMeters}m` : "Active"));
                                    const initial = member.name ? member.name.trim()[0].toUpperCase() : "👤";
                                    return e("div", {
                                        key: member.id || mIdx,
                                        className: "flex flex-col items-center gap-1 shrink-0 cursor-pointer",
                                        onClick: () => setTouristTab("group"),
                                        title: `${member.name} (${distText})`
                                    },
                                        e("div", {
                                            className: `w-14 h-14 rounded-full flex items-center justify-center font-heading font-black text-base shadow-xs transition-transform active:scale-95 aspect-square relative border-2 ${
                                                isSosMember ? "bg-rose-600 text-white border-rose-400 animate-pulse ring-4 ring-rose-500/40" : "bg-[#0f172a] text-white border-slate-700"
                                            }`,
                                            style: { width: '56px', height: '56px', minWidth: '56px', minHeight: '56px', borderRadius: '9999px', flexShrink: 0, aspectRatio: '1/1' }
                                        },
                                            initial,
                                            e("span", { className: `absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full border-2 border-white ${isSosMember ? 'bg-rose-500 animate-ping' : 'bg-emerald-500'}` })
                                        ),
                                        e("span", { className: `text-[11px] font-bold text-center max-w-[68px] truncate ${isSosMember ? 'text-rose-600 font-black' : 'text-slate-800'}` }, member.name),
                                        e("span", { className: `text-[9px] font-mono-data font-semibold ${isSosMember ? 'text-rose-600 font-extrabold animate-pulse' : 'text-slate-400'}` }, distText)
                                    );
                                }),

                                // Add Member Button (Redirects to Group Section)
                                e("div", {
                                    className: "flex flex-col items-center gap-1 shrink-0 cursor-pointer",
                                    onClick: () => setTouristTab("group"),
                                    title: "Create or Join a Group"
                                },
                                    e("div", {
                                        className: "w-14 h-14 rounded-full bg-white hover:bg-slate-50 border-2 border-dashed border-slate-300 hover:border-slate-400 text-slate-600 flex items-center justify-center text-xl shadow-xs transition-all active:scale-95 aspect-square",
                                        style: { width: '56px', height: '56px', minWidth: '56px', minHeight: '56px', borderRadius: '9999px', flexShrink: 0, aspectRatio: '1/1' }
                                    }, "➕"),
                                    e("span", { className: "text-[11px] font-bold text-slate-800 text-center max-w-[68px] truncate" }, "Add Member"),
                                    e("span", { className: "text-[9px] text-slate-400 font-mono-data font-semibold" }, activeGroupCode ? "+ Code" : "+ Create")
                                ),

                                // Helpful banner when no members are joined yet
                                (!activeGroupCode || !groupMembers || groupMembers.length === 0) && e("div", {
                                    onClick: () => setTouristTab("group"),
                                    className: "flex items-center gap-2 bg-slate-50 hover:bg-slate-100 border border-slate-200/80 rounded-2xl px-3.5 py-2.5 cursor-pointer shrink-0 transition-colors shadow-2xs"
                                },
                                    e("span", { className: "text-base" }, "👥"),
                                    e("div", { className: "flex flex-col text-left" },
                                        e("span", { className: "text-xs font-heading font-black text-slate-800 leading-tight" }, "Create Tourist Group"),
                                        e("span", { className: "text-[10px] text-slate-500 font-medium" }, "Share code to live-track members")
                                    )
                                )
                            ),

                            // 3. Hero Centerpiece SOS Button Card (Direct Match to SafeZ Screen 1)
                            e("div", { className: "card-modern p-6 flex flex-col items-center justify-center text-center gap-4 relative overflow-hidden" },
                                // Glowing Concentric Rings Container
                                e("div", { className: "relative flex items-center justify-center my-3" },
                                    // Outer radiating ring
                                    e("div", { className: "absolute w-52 h-52 rounded-full bg-red-600/20 animate-ping opacity-35 pointer-events-none" }),
                                    // Middle soft glow ring
                                    e("div", { className: "absolute w-44 h-44 rounded-full bg-gradient-to-tr from-red-600/30 via-red-500/25 to-red-600/20 pointer-events-none" }),
                                    // Large Radiant Crimson Red Center SOS Button
                                    e("button", {
                                        onClick: handleTriggerSos,
                                        className: "w-36 h-36 rounded-full bg-gradient-to-tr from-[#991B1B] via-[#DC2626] to-[#EF4444] text-white shadow-2xl shadow-red-600/60 flex flex-col items-center justify-center cursor-pointer active:scale-95 transition-transform sos-radiant-glow z-10 relative border-2 border-red-400/40"
                                    },
                                        e("svg", { width: 22, height: 22, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.5", strokeLinecap: "round", strokeLinejoin: "round", className: "text-white/95 mb-1" },
                                            e("path", { d: "M2 12h2" }),
                                            e("path", { d: "M20 12h2" }),
                                            e("path", { d: "m4.93 4.93 1.41 1.41" }),
                                            e("path", { d: "m17.66 17.66 1.41 1.41" }),
                                            e("path", { d: "M12 2v2" }),
                                            e("path", { d: "M12 20v2" }),
                                            e("path", { d: "m4.93 19.07 1.41-1.41" }),
                                            e("path", { d: "m17.66 6.34 1.41-1.41" })
                                        ),
                                        e("span", { className: "font-heading font-black text-3xl tracking-wider uppercase text-white leading-none drop-shadow-md" }, "SOS"),
                                        e("span", { className: "text-[9px] font-extrabold uppercase tracking-widest text-white/95 mt-1" }, "PRESS TO TRIGGER")
                                    )
                                ),
                                // Overlapping Responders Avatars + Subtext
                                e("div", { className: "flex flex-col items-center gap-1.5" },
                                    e("div", { className: "flex items-center -space-x-2" },
                                        e("div", { className: "w-7 h-7 rounded-full bg-blue-600 border-2 border-white flex items-center justify-center text-[9px] text-white font-extrabold shadow-xs" }, "POL"),
                                        e("div", { className: "w-7 h-7 rounded-full bg-rose-600 border-2 border-white flex items-center justify-center text-[9px] text-white font-extrabold shadow-xs" }, "EMS"),
                                        e("div", { className: "w-7 h-7 rounded-full bg-indigo-600 border-2 border-white flex items-center justify-center text-[9px] text-white font-extrabold shadow-xs" }, "GRP"),
                                        e("div", { className: "w-7 h-7 rounded-full bg-emerald-600 border-2 border-white flex items-center justify-center text-[9px] text-white font-extrabold shadow-xs" }, "SEC"),
                                        e("div", { className: "w-7 h-7 rounded-full bg-slate-900 text-white text-[10px] font-black border-2 border-white flex items-center justify-center shadow-xs" }, "+4")
                                    ),
                                    e("p", { className: "text-xs font-semibold text-slate-500" },
                                        selectedLang === "Hindi" ? "आपका SOS 4 सुरक्षा इकाइयों और समूह को भेजा जाएगा" : selectedLang === "Marathi" ? "आपला SOS 4 आपत्कालीन युनिट्स व ग्रुपला पाठवला जाईल" : "Your SOS will be sent to 4 authorities & group"
                                    )
                                ),
                                // Distress category selector pill
                                e("div", { className: "w-full" },
                                    e("label", { className: "text-[10px] font-extrabold text-slate-400 block mb-1 uppercase tracking-wider text-left font-mono-data" }, t.selectDistress),
                                    e("select", {
                                        value: selectedCategory,
                                        onChange: (e) => setSelectedCategory(e.target.value),
                                        className: "w-full bg-slate-50 border border-slate-200 rounded-2xl p-3 text-xs font-bold text-slate-900 focus:outline-none focus:border-rose-500 cursor-pointer shadow-xs"
                                    },
                                        e("option", { value: "Medical Emergency" }, "⚡ Medical Emergency (Cardiac / Trauma / Heatstroke)"),
                                        e("option", { value: "Physical Threat / Assault" }, "🚨 Physical Threat / Assault / Stalking"),
                                        e("option", { value: "Harassment / Eve Teasing" }, "🛑 Harassment / Eve Teasing"),
                                        e("option", { value: "Theft / Robbery" }, "👜 Pickpocketing / Bag Snatching / Robbery"),
                                        e("option", { value: "Lost Tourist / Disoriented" }, "🧭 Completely Lost / Disoriented"),
                                        e("option", { value: "High Tide Water Hazard" }, "🌊 Stranded Near High Tide Wave Zone")
                                    )
                                ),
                                // Interactive Real Touch & Mouse Slide-to-Dispatch SOS Component
                                e(SlideToSosButton, {
                                    onTrigger: handleTriggerSos,
                                    selectedLang: selectedLang
                                })
                            ),

                            // 4. Safety Radar Map Card
                            e("div", { className: "card-modern p-5 flex flex-col gap-3" },
                                e("div", { className: "flex items-center justify-between" },
                                    e("div", null,
                                        e("h3", { className: "font-heading font-black text-base text-slate-900" }, t.southMumbaiMap),
                                        e("p", { className: "text-xs text-slate-500" }, t.liveShorelineHazard)
                                    ),
                                    e("span", { className: "text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-full font-mono-data" },
                                        t.liveGpsMap
                                    )
                                ),
                                e(WorkingSafetyMap, {
                                    touristLatLong: touristLatLong,
                                    setTouristLatLong: setTouristLatLong,
                                    isUsingRealGps: isUsingRealGps,
                                    setIsUsingRealGps: setIsUsingRealGps
                                })
                            )
                        )
                    ),

                    // -------------------------------------------------------------
                    // TAB: AI ASSIST
                    // -------------------------------------------------------------
                    touristTab === "ai" && e("div", { className: "flex flex-col h-full gap-3.5" },
                        e("div", { className: "flex items-center justify-between bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs" },
                            e("div", { className: "flex items-center gap-2.5" },
                                e("button", {
                                    onClick: () => setTouristTab("safety"),
                                    className: "w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 flex items-center justify-center font-bold text-sm"
                                }, "←"),
                                e("div", null,
                                    e("h2", { className: "font-heading font-black text-sm text-slate-900" }, t.aiTitle),
                                    e("span", { className: "text-[10px] text-emerald-600 font-bold block" }, t.aiOnline)
                                )
                            ),
                            e("button", {
                                onClick: () => setShowKeyModal(true),
                                className: "text-[10px] font-mono-data font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 px-2.5 py-1 rounded-lg"
                            }, "V2.0 PRO")
                        ),
                        e("div", { className: "overflow-x-auto no-scrollbar flex gap-2 pb-1" },
                            (selectedLang === "Hindi" ? [
                                "🏖️ क्या जुहू बीच रात 8 बजे सुरक्षित है?",
                                "🏥 नजदीकी आपातकालीन अस्पताल",
                                "🚨 सामान्य पर्यटक धोखाधड़ी",
                                "🚕 टैक्सी किराया और मीटर गाइड",
                                "🛂 खोए हुए पासपोर्ट के लिए क्या करें?"
                            ] : selectedLang === "Marathi" ? [
                                "🏖️ जुहू बीच रात्री 8 नंतर सुरक्षित आहे का?",
                                "🏥 सर्वात जवळचे आपत्कालीन रुग्णालय",
                                "🚨 पर्यटकांची फसवणूक टाळण्याचे उपाय",
                                "🚕 टॅक्सी भाडे व मीटर नियम",
                                "🛂 पासपोर्ट हरवला तर काय करावे?"
                            ] : [
                                "🏖️ Is Juhu Beach safe after 8 PM?",
                                "🏥 Nearest emergency hospital",
                                "🚨 Common tourist scams",
                                "🚕 Safe taxi fare guidelines",
                                "🛂 Lost passport instructions"
                            ]).map((promptText, idx) =>
                                e("button", {
                                    key: idx,
                                    onClick: () => handleSendAiQuery(null, promptText),
                                    className: "whitespace-nowrap bg-white border border-slate-200 hover:border-blue-400 text-slate-800 px-3 py-1.5 rounded-full text-xs font-bold shadow-xs active:scale-95 transition-all shrink-0"
                                }, promptText)
                            )
                        ),
                        e("div", { className: "flex flex-col gap-3.5 min-h-[380px]" },
                            chatMessages.map((msg, idx) => {
                                const isUser = msg.sender === "user";
                                if (isUser) {
                                    return e("div", { key: idx, className: "self-end max-w-[85%]" },
                                        e("div", { className: "bg-[#0b192c] text-white p-3.5 rounded-2xl rounded-tr-xs text-xs sm:text-sm font-semibold shadow-sm leading-relaxed" },
                                            msg.text
                                        ),
                                        e("span", { className: "text-[9px] text-slate-400 font-mono-data text-right block mt-1" }, msg.time)
                                    );
                                }
                                const s = msg.structured;
                                return e("div", { key: idx, className: "self-start max-w-[95%] w-full flex flex-col gap-2" },
                                    e("div", { className: "bg-white border border-slate-200 text-slate-800 p-3.5 rounded-2xl rounded-tl-xs text-xs sm:text-sm shadow-xs leading-relaxed" },
                                        s ? s.intro : msg.text
                                    ),
                                    s && e("div", { className: "bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col gap-3" },
                                        e("div", { className: "flex items-center justify-between pb-2 border-b border-slate-100" },
                                            e("span", { className: "text-[10px] font-extrabold text-slate-500 uppercase tracking-wider font-mono-data" }, t.safetyRating),
                                            e("span", { className: "bg-emerald-100 text-emerald-800 border border-emerald-300 text-[10px] font-extrabold px-2.5 py-0.5 rounded-full font-mono-data" },
                                                s.rating || "Generally Safe"
                                            )
                                        ),
                                        e("div", { className: "flex flex-col gap-2 text-xs text-slate-800 font-semibold" },
                                            (s.points || []).map((pt, pIdx) =>
                                                e("div", { key: pIdx, className: "flex items-start gap-2" },
                                                    e("span", { className: pt.color === "orange" ? "text-amber-500" : pt.color === "red" ? "text-red-500" : "text-emerald-500" }, "●"),
                                                    e("span", null, pt.text)
                                                )
                                            )
                                        ),
                                        s.summary && e("p", { className: "text-[11px] text-slate-500 bg-slate-50 p-2.5 rounded-xl border border-slate-100 leading-relaxed font-medium" },
                                            s.summary
                                        ),
                                        s.mapsLink && e("a", {
                                            href: s.mapsLink,
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            className: "w-full py-2.5 px-3.5 bg-blue-50 hover:bg-blue-100 border border-blue-200 text-blue-700 hover:text-blue-800 rounded-xl font-heading font-extrabold text-xs flex items-center justify-center gap-2 transition-all shadow-xs active:scale-98 text-center cursor-pointer select-none no-underline mt-1"
                                        },
                                            e("svg", { width: 16, height: 16, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.5", strokeLinecap: "round", strokeLinejoin: "round" },
                                                e("path", { d: "M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" }),
                                                e("circle", { cx: "12", cy: "10", r: "3" })
                                            ),
                                            e("span", null, s.mapsLabel || (selectedLang === "Hindi" ? "📍 गूगल मैप्स पर सटीक स्थान देखें" : selectedLang === "Marathi" ? "📍 गुगल मॅप्सवर अचूक स्थान पहा" : "📍 View Exact Location on Google Maps")),
                                            e("span", { className: "text-xs font-black" }, "↗")
                                        )
                                    ),
                                    e("span", { className: "text-[9px] text-slate-400 font-mono-data block" }, msg.time)
                                );
                            }),
                            isAiThinking && e("div", { className: "bg-white border border-slate-200 p-3 rounded-2xl w-20 flex items-center gap-1.5 shadow-xs" },
                                e("div", { className: "w-2 h-2 rounded-full bg-blue-600 typing-dot" }),
                                e("div", { className: "w-2 h-2 rounded-full bg-blue-600 typing-dot" }),
                                e("div", { className: "w-2 h-2 rounded-full bg-blue-600 typing-dot" })
                            )
                        ),
                        e("form", {
                            onSubmit: handleSendAiQuery,
                            className: "mt-auto bg-white p-2 rounded-full border border-slate-200 shadow-sm flex items-center gap-2"
                        },
                            e("input", {
                                type: "text",
                                value: chatInput,
                                onChange: (e) => setChatInput(e.target.value),
                                placeholder: t.askLocation,
                                className: "flex-1 bg-transparent px-4 py-2 text-xs sm:text-sm text-slate-900 focus:outline-none placeholder-slate-400"
                            }),
                            e("button", {
                                type: "submit",
                                className: "w-9 h-9 rounded-full bg-[#0b192c] hover:bg-slate-800 text-white flex items-center justify-center font-bold text-sm shadow-md active:scale-95 shrink-0"
                            }, "↑")
                        )
                    ),

                    // -------------------------------------------------------------
                    // TAB: TRANSLATE
                    // -------------------------------------------------------------
                    touristTab === "translate" && e(FullTouristTranslator, { geminiApiKey: geminiApiKey }),

                    // -------------------------------------------------------------
                    // TAB: GROUP
                    // -------------------------------------------------------------
                    touristTab === "group" && e("div", { className: "flex flex-col gap-4" },
                        activeGroupCode ? e("div", { className: "bg-white rounded-3xl p-5 shadow-sm border border-slate-200 flex flex-col gap-3.5" },
                            e("div", { className: "flex items-center justify-between" },
                                e("div", { className: "flex items-center gap-3" },
                                    e("div", { className: "p-3 bg-blue-50 border border-blue-200 rounded-2xl text-blue-600 shadow-xs text-xl" }, "👥"),
                                    e("div", null,
                                        e("h3", { className: "font-heading font-black text-base text-slate-900 leading-tight" }, activeGroupName || "Mumbai Tour Group"),
                                        e("span", { className: "text-xs text-slate-500 font-medium" }, `${groupMembers.length} Member${groupMembers.length > 1 ? 's' : ''} in Room • Live GPS Sync`)
                                    )
                                ),
                                e("button", {
                                    onClick: handleLeaveGroup,
                                    className: "text-xs text-red-600 hover:text-red-700 font-bold px-3 py-1.5 rounded-xl bg-red-50 border border-red-200 transition-all active:scale-95"
                                }, "Leave Room")
                            ),
                            e("div", { className: "bg-slate-50 border border-slate-200 rounded-2xl p-3.5 flex items-center justify-between shadow-xs" },
                                e("div", null,
                                    e("span", { className: "text-[10px] text-slate-500 uppercase font-extrabold tracking-wider block" }, "Group Invite Code"),
                                    e("p", { className: "font-mono-data font-black text-blue-600 text-lg tracking-widest" }, activeGroupCode)
                                ),
                                e("div", { className: "flex items-center gap-2" },
                                    e("button", {
                                        onClick: () => {
                                            navigator.clipboard.writeText(activeGroupCode);
                                            alert(`📋 Group Code "${activeGroupCode}" copied to clipboard!`);
                                        },
                                        className: "bg-white hover:bg-slate-100 text-slate-800 text-xs font-bold px-3 py-2 rounded-xl border border-slate-300 flex items-center gap-1.5 active:scale-95 shadow-xs"
                                    }, e("span", null, "📋"), e("span", null, "Copy Code")),
                                    e("a", {
                                        href: `https://wa.me/?text=${encodeURIComponent(`Join our RakshaGrid tourist group! Code: ${activeGroupCode}\\nLink: ${window.location.origin}/`)}`,
                                        target: "_blank",
                                        rel: "noreferrer",
                                        className: "bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black px-3.5 py-2 rounded-xl shadow-md flex items-center gap-1.5 active:scale-95 text-decoration-none"
                                    }, e("span", null, "📲"), e("span", null, "WhatsApp"))
                                )
                            ),
                            e("div", { className: "bg-slate-50 rounded-2xl border border-slate-200 p-4 flex flex-col gap-3" },
                                e("div", { className: "flex items-center justify-between" },
                                    e("span", { className: "text-xs font-black uppercase tracking-wider font-heading text-slate-900 block" }, `Connected Members (${groupMembers.length})`),
                                    e("span", { className: "text-[10px] text-slate-500 font-mono-data" }, "Live GPS Proximity")
                                ),
                                groupMembers.length === 0 ? e("div", { className: "text-center py-4 text-xs text-slate-500" }, "No members joined yet.") :
                                groupMembers.map((member) => {
                                    const isSelf = member.id === "M-YOU" || (profile.name && member.name && profile.name.toLowerCase() === member.name.toLowerCase());
                                    const dist = isSelf ? 0 : (member.distanceMeters !== undefined ? member.distanceMeters : 0);
                                    const isSosMember = member.isSos || (member.status && member.status.includes("SOS")) || (isSelf && isSosActive);
                                    const statusDisplay = isSosMember ? "🚨 EMERGENCY SOS ACTIVE" : (member.status || "Safe & Active");

                                    return e("div", {
                                        key: member.id,
                                        className: `p-3.5 rounded-2xl border flex flex-col gap-2 text-xs text-white shadow-md transition-all ${
                                            isSosMember 
                                                ? "bg-slate-900 border-2 border-rose-500 shadow-rose-900/40" 
                                                : "bg-slate-900 border-slate-700"
                                        }`
                                    },
                                        e("div", { className: "flex justify-between items-center" },
                                            e("div", { className: "flex items-center gap-2.5" },
                                                e("div", {
                                                    className: `w-8 h-8 rounded-xl flex items-center justify-center font-heading font-black text-xs ${
                                                        isSosMember ? "bg-rose-600 text-white animate-pulse" : "bg-blue-600 text-white"
                                                    }`
                                                },
                                                    member.name ? member.name[0] : "U"
                                                ),
                                                e("div", null,
                                                    e("div", { className: "flex items-center gap-1.5" },
                                                        e("span", { className: "font-bold text-white" }, member.name),
                                                        isSelf && e("span", { className: `text-[9px] px-1.5 py-0.2 rounded font-mono-data ${isSosMember ? 'bg-rose-600 text-white font-black' : 'bg-blue-500 text-white'}` }, "YOU")
                                                    ),
                                                    e("span", { className: "text-[10px] text-slate-400 font-mono-data block" }, member.latLong)
                                                )
                                            ),
                                            e("span", {
                                                className: `px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                                                    isSosMember ? "bg-rose-900 text-rose-200 border-rose-500 animate-pulse" : "bg-blue-900 text-white border-blue-500"
                                                }`
                                            }, isSosMember ? "🚨 SOS DISTRESS" : `${dist}m away`)
                                        ),
                                        e("div", {
                                            className: `flex items-center justify-between text-[10px] font-semibold p-2 rounded-lg border ${
                                                isSosMember 
                                                    ? "bg-rose-950/80 border-rose-600 text-rose-200" 
                                                    : "bg-slate-950 border-slate-800 text-slate-300"
                                            }`
                                        },
                                            e("span", {
                                                className: isSosMember ? "text-rose-400 font-black tracking-wide flex items-center gap-1" : "text-emerald-400 font-bold"
                                            }, `Status: ${statusDisplay}`),
                                            e("span", null, `🔋 ${member.battery || '100%'}`)
                                        )
                                    );
                                })
                            ),
                            e("div", { className: "flex flex-col gap-2 pt-2 border-t border-slate-100" },
                                e("span", { className: "text-[10px] font-bold text-slate-400 uppercase font-mono-data" }, "GROUP RADIO WALKIE-TALKIE"),
                                e("div", {
                                    ref: groupChatBoxRef,
                                    className: "max-h-48 overflow-y-auto flex flex-col gap-2 bg-slate-50 p-3 rounded-2xl border border-slate-200 scroll-smooth"
                                },
                                    groupChat.length === 0 ? e("div", { className: "text-center py-3 text-slate-400 text-xs" }, "No messages in this group yet.") :
                                    groupChat.map((gc, gcIdx) => {
                                        const isSosAlert = gc.isAlert || (gc.text && gc.text.includes("🚨 SOS"));
                                        return e("div", {
                                            key: gcIdx,
                                            className: isSosAlert 
                                                ? "bg-rose-50 border-2 border-rose-300 p-2.5 rounded-xl text-xs shadow-xs text-rose-950 font-bold" 
                                                : "bg-white p-2.5 rounded-xl border border-slate-200 text-xs shadow-xs"
                                        },
                                            e("div", { className: "flex justify-between font-extrabold text-[10px] text-slate-600 mb-0.5" },
                                                e("span", { className: isSosAlert ? "text-rose-700 font-black" : "" }, gc.sender),
                                                e("span", { className: "font-mono-data text-slate-400" }, gc.time)
                                            ),
                                            e("p", { className: `${isSosAlert ? "text-rose-900 font-black" : "text-slate-900 font-semibold"} leading-relaxed` }, gc.text)
                                        );
                                    })
                                ),
                                e("form", { onSubmit: handleSendGroupChat, className: "flex gap-2 mt-1" },
                                    e("input", {
                                        type: "text",
                                        value: groupChatInput,
                                        onChange: (e) => setGroupChatInput(e.target.value),
                                        placeholder: "Broadcast message to group...",
                                        className: "flex-1 bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-xs text-slate-900 focus:outline-none focus:border-blue-500"
                                    }),
                                    e("button", { type: "submit", className: "bg-blue-600 hover:bg-blue-700 text-white font-black text-xs px-4 py-2 rounded-xl shadow-md" }, "Send")
                                )
                            )
                        ) : e("div", { className: "bg-white rounded-3xl p-5 shadow-sm border border-slate-200 flex flex-col gap-4" },
                            e("div", { className: "flex items-center justify-between border-b border-slate-100 pb-3" },
                                e("div", { className: "flex items-center gap-2.5" },
                                    e("span", { className: "text-xl" }, "👥"),
                                    e("div", null,
                                        e("h3", { className: "font-heading font-black text-base text-slate-900" }, "Connect with Friends in a Group"),
                                        e("p", { className: "text-xs text-slate-500 font-medium" }, "Create a private group code or join your friend's room")
                                    )
                                ),
                                e("span", { className: "text-[10px] text-blue-700 font-mono-data font-extrabold bg-blue-50 border border-blue-200 px-2.5 py-0.5 rounded-full" }, "6-Digit Code")
                            ),
                            e("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3.5" },
                                e("div", { className: "bg-slate-50 border border-slate-200 rounded-2xl p-4 flex flex-col justify-between gap-3 shadow-xs" },
                                    e("div", null,
                                        e("h4", { className: "font-heading font-black text-sm text-slate-900 mb-1" }, "Create New Group"),
                                        e("p", { className: "text-xs text-slate-500 font-medium" }, "Generates a unique 6-digit code (e.g. BOM-821) to share.")
                                    ),
                                    isCreatingGroup ? e("form", { onSubmit: handleCreateGroup, className: "flex flex-col gap-2 mt-1" },
                                        e("input", {
                                            type: "text",
                                            value: newGroupNameInput,
                                            onChange: (e) => setNewGroupNameInput(e.target.value),
                                            placeholder: "Group Name (e.g. Goa Trip Gang)",
                                            className: "w-full bg-white border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 font-bold focus:outline-none"
                                        }),
                                        e("div", { className: "flex gap-2" },
                                            e("button", { type: "button", onClick: () => setIsCreatingGroup(false), className: "flex-1 bg-slate-200 text-slate-700 text-xs font-bold py-2 rounded-xl" }, "Cancel"),
                                            e("button", { type: "submit", className: "flex-1 bg-blue-600 hover:bg-blue-700 text-white text-xs font-black py-2 rounded-xl shadow-md" }, "Generate Code ➔")
                                        )
                                    ) : e("button", {
                                        onClick: () => setIsCreatingGroup(true),
                                        className: "w-full bg-blue-600 hover:bg-blue-700 text-white font-black text-xs uppercase py-2.5 rounded-xl shadow-md active:scale-95 transition-all"
                                    }, "+ Create Group & Get Code")
                                ),
                                e("div", { className: "bg-slate-50 border border-slate-200 rounded-2xl p-4 flex flex-col justify-between gap-3 shadow-xs" },
                                    e("div", null,
                                        e("h4", { className: "font-heading font-black text-sm text-slate-900 mb-1" }, "Join Friend's Group"),
                                        e("p", { className: "text-xs text-slate-500 font-medium" }, "Enter the 6-character code your friend shared.")
                                    ),
                                    e("form", { onSubmit: handleJoinGroup, className: "flex gap-2 mt-1" },
                                        e("input", {
                                            required: true,
                                            maxLength: 7,
                                            value: joinCodeInput,
                                            onChange: (e) => setJoinCodeInput(e.target.value.toUpperCase()),
                                            placeholder: "e.g. BOM-821",
                                            className: "flex-1 bg-white border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 font-mono-data font-black tracking-wider uppercase focus:outline-none"
                                        }),
                                        e("button", { type: "submit", className: "bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs uppercase px-4 py-2.5 rounded-xl shadow-md active:scale-95" }, "Join ➔")
                                    )
                                )
                            )
                        )
                    ),

                    // -------------------------------------------------------------
                    // TAB: LOST
                    // -------------------------------------------------------------
                    touristTab === "lost" && e(ReferenceLostSection, {
                        profile: profile,
                        lostReports: lostReports,
                        setLostReports: setLostReports,
                        myLocalLostIds: myLocalLostIds,
                        setMyLocalLostIds: setMyLocalLostIds,
                        handleLostFoundSubmit: handleLostFoundSubmit,
                        handleDismissMyReport: handleDismissMyReport,
                        handleClearAllMyReports: handleClearAllMyReports,
                        isFilingModalOpen: isFilingLostModalOpen,
                        setIsFilingModalOpen: setIsFilingLostModalOpen,
                        selectedLang: selectedLang
                    }),

                    // -------------------------------------------------------------
                    // TAB: PROFILE
                    // -------------------------------------------------------------
                    touristTab === "profile" && e(ReferenceProfileSection, {
                        profile: profile,
                        setProfile: setProfile,
                        isEditingProfile: isEditingProfile,
                        setIsEditingProfile: setIsEditingProfile,
                        livePlaceName: livePlaceName,
                        selectedLang: selectedLang
                    })
                ),

                // =================================================================
                // TRADITIONAL FIXED BOTTOM NAVIGATION BAR (Hidden during form entry/modal editing)
                // =================================================================
                (!showStartModal && !isEditingProfile && !showKeyModal && !isFilingLostModalOpen) && e("nav", {
                    className: "fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[440px] z-50 bg-white border-t border-slate-200/90 shadow-[0_-4px_24px_rgba(0,0,0,0.07)] pt-2 pb-3.5 px-2.5",
                    style: { backgroundColor: '#ffffff', opacity: 1 }
                },
                    e("div", { className: "w-full grid grid-cols-6 items-center text-center gap-1" },
                        [
                            { id: 'safety', label: t.tabSafety },
                            { id: 'ai', label: t.tabAi },
                            { id: 'translate', label: t.tabTranslate },
                            { id: 'group', label: t.tabGroup },
                            { id: 'lost', label: t.tabLost },
                            { id: 'profile', label: t.tabProfile }
                        ].map((item) => {
                            const isActive = touristTab === item.id;
                            return e("button", {
                                key: item.id,
                                onClick: () => setTouristTab(item.id),
                                className: `group relative py-1 px-0.5 min-h-[48px] rounded-xl active:bg-slate-100/80 transition-all flex flex-col items-center justify-center gap-1 ${
                                    isActive 
                                        ? "text-blue-600 font-black" 
                                        : "text-slate-500 hover:text-slate-900 font-bold"
                                }`
                            },
                                isActive && e("span", { className: "absolute -top-2 w-7 h-0.5 rounded-full bg-blue-600 shadow-xs" }),
                                e(NavTabIcon, { tab: item.id, isActive: isActive }),
                                e("span", {
                                    className: `text-[10.5px] font-heading tracking-tight leading-tight block ${isActive ? 'text-blue-600 font-black' : 'text-slate-500 font-bold'}`
                                }, item.label)
                            );
                        })
                    )
                ),

                // Starting Details Popup Modal (Asks for Name, Mobile, Nationality, Gender)
                showStartModal && e("div", { className: "fixed inset-0 bg-slate-950/70 backdrop-blur-md z-50 flex items-center justify-center p-4" },
                    e("div", { className: "bg-white rounded-3xl p-6 sm:p-7 shadow-2xl max-w-sm w-full border border-slate-100 flex flex-col gap-4 relative overflow-hidden" },
                        e("div", { className: "flex items-center gap-3" },
                            e("div", { className: "w-11 h-11 rounded-2xl bg-[#0f172a] text-white flex items-center justify-center text-xl font-bold shadow-md shrink-0" }, "🛡️"),
                            e("div", null,
                                e("h3", { className: "font-heading font-extrabold text-base text-slate-900 leading-tight" }, "Tourist Safety Pass"),
                                e("p", { className: "text-xs text-slate-500 font-medium" }, "Quick setup to link with emergency dispatch")
                            )
                        ),

                        e("form", {
                            onSubmit: (e) => {
                                e.preventDefault();
                                const form = e.target;
                                const updated = {
                                    ...profile,
                                    name: form.userName.value.trim(),
                                    contact: form.userMobile.value.trim(),
                                    nationality: form.userNationality.value,
                                    gender: form.userGender.value,
                                    isVerified: true
                                };
                                setProfile(updated);
                                try {
                                    localStorage.setItem("rg_profile_data_v2", JSON.stringify(updated));
                                    localStorage.setItem("rg_profile_completed_v2", "true");
                                } catch (err) {}
                                setShowStartModal(false);
                            },
                            className: "flex flex-col gap-3 text-xs"
                        },
                            e("div", null,
                                e("label", { className: "text-[11px] text-slate-700 font-bold block mb-1 uppercase tracking-wider font-mono-data" }, "1. Full Name *"),
                                e("input", {
                                    required: true,
                                    name: "userName",
                                    type: "text",
                                    defaultValue: profile.name || "",
                                    placeholder: "Enter your full name",
                                    className: "w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-900 font-bold placeholder-slate-400 focus:outline-none focus:border-rose-500 shadow-xs"
                                })
                            ),

                            e("div", null,
                                e("label", { className: "text-[11px] text-slate-700 font-bold block mb-1 uppercase tracking-wider font-mono-data" }, "2. Mobile Number *"),
                                e("input", {
                                    required: true,
                                    name: "userMobile",
                                    type: "tel",
                                    defaultValue: profile.contact || "",
                                    placeholder: "Enter 10-digit mobile number",
                                    className: "w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-900 font-mono-data font-bold placeholder-slate-400 focus:outline-none focus:border-rose-500 shadow-xs"
                                })
                            ),

                            e("div", { className: "grid grid-cols-2 gap-2.5" },
                                e("div", null,
                                    e("label", { className: "text-[11px] text-slate-700 font-bold block mb-1 uppercase tracking-wider font-mono-data" }, "3. Nationality *"),
                                    e("select", {
                                        name: "userNationality",
                                        defaultValue: profile.nationality || "India",
                                        className: "w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-900 font-bold focus:outline-none focus:border-rose-500 cursor-pointer shadow-xs"
                                    },
                                        COUNTRIES_LIST.map(country => e("option", { key: country, value: country }, country))
                                    )
                                ),
                                e("div", null,
                                    e("label", { className: "text-[11px] text-slate-700 font-bold block mb-1 uppercase tracking-wider font-mono-data" }, "4. Gender *"),
                                    e("select", {
                                        name: "userGender",
                                        defaultValue: profile.gender || "Prefer not to say",
                                        className: "w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-900 font-bold focus:outline-none focus:border-rose-500 cursor-pointer shadow-xs"
                                    },
                                        e("option", { value: "Prefer not to say" }, "Prefer not to say"),
                                        e("option", { value: "Male" }, "Male"),
                                        e("option", { value: "Female" }, "Female"),
                                        e("option", { value: "Non-Binary" }, "Non-Binary")
                                    )
                                )
                            ),

                            e("button", {
                                type: "submit",
                                className: "w-full mt-2 py-3 rounded-full bg-[#0f172a] hover:bg-slate-800 text-white font-heading font-black text-xs tracking-wider uppercase shadow-md transition-all active:scale-98 text-center"
                            }, "SAVE & START ➔")
                        )
                    )
                ),

                // Gemini Key Modal
                showKeyModal && e("div", { className: "fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4" },
                    e("div", { className: "bg-white p-5 rounded-3xl max-w-sm w-full flex flex-col gap-3 shadow-2xl" },
                        e("h3", { className: "font-heading font-black text-sm text-slate-900" }, "Google Gemini AI API Key"),
                        e("p", { className: "text-xs text-slate-500" }, "Enter your API key to connect directly with Gemini 2.0."),
                        e("input", {
                            type: "password",
                            value: geminiApiKey,
                            onChange: (e) => setGeminiApiKey(e.target.value),
                            placeholder: "Enter AIzaSy... Key",
                            className: "bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs font-mono-data text-slate-900 focus:outline-none"
                        }),
                        e("div", { className: "flex justify-end gap-2 mt-1" },
                            e("button", { onClick: () => setShowKeyModal(false), className: "bg-slate-900 text-white px-4 py-2 rounded-xl text-xs font-bold" }, "Save Key")
                        )
                    )
                )
            )
        );
    }

    // --- DOM MOUNT ---
    function mount() {
        const rootEl = document.getElementById('root');
        if (!rootEl) { setTimeout(mount, 20); return; }
        if (ReactDOM.createRoot) {
            const root = ReactDOM.createRoot(rootEl);
            root.render(React.createElement(TouristApp, null));
        } else if (ReactDOM.render) {
            ReactDOM.render(React.createElement(TouristApp, null), rootEl);
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', mount);
    } else {
        mount();
    }
})();
