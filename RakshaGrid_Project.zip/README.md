# 🛡️ RakshaGrid 2.0 - Smart Tourist Safety Platform 🇮🇳

A real-time tourist safety, emergency dispatch, live coastal radar, multilingual AI translator, and group proximity tracking platform designed for tourists visiting India.

---

## 🚀 How to Run

### Option 1: One-Click Offline Run (No Node.js Required)
Simply double-click:
👉 **`Tourist_Mobile_App.html`** (or **`RakshaGrid_Standalone.html`**)
* Opens immediately in any web browser (Chrome, Edge, Firefox, Safari, Mobile).
* All modern UI, multilingual speech translator, coastal safety radar, lost & found claims, and identity pass run self-contained!

---

### Option 2: Live Full-Stack Server (Multi-device Real-Time Sync)
To run with real-time multi-device group syncing and the Police/Authority Command Center:

1. Make sure **Node.js** is installed on your PC (from [nodejs.org](https://nodejs.org/)).
2. Double-click **`start.bat`** (or open a terminal in this folder and run `node server.js`).
3. Open your browser:
   * **Tourist App:** [http://localhost:5000](http://localhost:5000)
   * **Authority / Police Command Center:** [http://localhost:5000/authority](http://localhost:5000/authority)

---

## 🌟 Key Features
- **🚨 1-Tap SOS Emergency Dispatch:** Real-time emergency beacon with sound, distress categorization, and authority notification.
- **👥 Live Group Tracking & Radio Walkie-Talkie:** Share group invite codes, track member proximity live, and chat in real-time.
- **🗣️ AI Multilingual Speech & Text Translator:** Everyday conversational Hindi and Marathi translator with one-tap spoken voice playback and phonetic guides.
- **🌊 Coastal Safety & Hazard Radar:** Real-time sea state alerts, tide hazard warnings, and safe perimeter corridors.
- **📦 Lost & Found Claims Management:** Log lost items and track police recovery status.
- **🔒 Police / Authority Live Console:** Dedicated dashboard for emergency officers to monitor incidents, dispatch responders, and broadcast safety alerts.
