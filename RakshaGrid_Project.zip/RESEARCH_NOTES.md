﻿# 🔬 RakshaGrid Research & Development Environment

A duplicate environment of the **RakshaGrid** tourist safety, dialect translation, and emergency dispatch ecosystem prepared for research, experimentation, and analysis.

---

## 📁 Project Structure & Core Assets

- **Frontend & App Logic:**
  - `tourist.html` / `index.html` — Tourist App Web Shell (React 18 + Tailwind CSS + Lucide Icons).
  - `tourist_app.js` / `app.js` / `src/TouristApp.jsx` — Complete Tourist App with:
    - Tactical Coastal Radar & Shoreline Hazard HUD
    - Live Conversational Hindi & Marathi Translator with Audio Synthesizer
    - Group Radio, Battery Telemetry & Distance Tracking
    - SOS Emergency Dispatch & Lost Item Reporting
  - `authority.html` / `authority_app.js` / `src/AuthorityApp.js` — Law Enforcement & Hospital Command Center Dashboard.
  - `RakshaGrid_Standalone.html` / `Tourist_Mobile_App.html` / `Authority_Command_Center.html` — Self-contained zero-install single-file offline bundles.

- **Backend & Network:**
  - `server.js` — Node.js REST & Event Server (Port 5000) for real-time dispatch, group sync, and emergency broadcast queues.
  - `start.bat` & `RUN_RAKSHAGRID.bat` — Single-click startup scripts.

- **Visual Architecture & Media:**
  - `architecture_slide.html` — Interactive presentation slide for project architecture and research deck.
  - `architecture_chart.jpg` — System architecture and workflow diagram.
  - `flow_chart.jpg` — Operational flow diagram.

---

## 🚀 Running for Research

1. **Start Backend Server:**
   cd C:\Users\VEDANT\.gemini\antigravity\scratch\raksha-research
   node server.js
2. **Access Interfaces:**
   - Tourist Interface: http://localhost:5000
   - Command Center: http://localhost:5000/authority.html
   - Architecture Slides: http://localhost:5000/architecture_slide.html
