@echo off
echo ==============================================
echo       Starting RakshaGrid Tourist Safety
echo ==============================================
echo Opening in your browser at http://localhost:5000/
start http://localhost:5000/
node server.js
pause
